/**
 * Depth selector module for mod_depthcontent.
 *
 * Handles depth-level switching without page reload: updates the button
 * bar, shows/hides content sections with a smooth transition, and
 * persists the choice via the set_depth AJAX service.
 *
 * @module     mod_depthcontent/depth_selector
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define(['jquery', 'core/ajax', 'core/notification'], function($, Ajax, Notification) {

    /** @type {string} Currently active depth. */
    var currentDepth = 'standard';

    /** @type {boolean} Whether to persist globally. */
    var rememberPref = true;

    /** @type {number} Activity instance id. */
    var instanceId = 0;

    /** @type {string[]} Ordered list of all depth levels. */
    var depthOrder = [];

    /** @type {string[]} Levels that have content in this point. */
    var availableLevels = [];

    /**
     * Get the index of a depth level in the ordered list.
     * @param {string} depth
     * @return {number}
     */
    function depthIndex(depth) {
        return depthOrder.indexOf(depth);
    }

    /**
     * Determine which sections should be visible for the given depth.
     *
     * A depth level shows all content from 'short' up to and including
     * the selected level (cumulative).
     *
     * @param {string} depth
     * @return {string[]}
     */
    function visibleLevels(depth) {
        var maxIdx = depthIndex(depth);
        var visible = [];
        for (var i = 0; i <= maxIdx; i++) {
            if (availableLevels.indexOf(depthOrder[i]) !== -1) {
                visible.push(depthOrder[i]);
            }
        }
        return visible;
    }

    /**
     * Update the button bar to reflect the new active depth.
     * @param {string} depth
     */
    function updateButtons(depth) {
        $('.dc-depth-btn').each(function() {
            var $btn = $(this);
            var btnDepth = $btn.data('depth');
            var isActive = (btnDepth === depth);
            $btn.toggleClass('active', isActive)
                .attr('aria-checked', isActive ? 'true' : 'false');
        });
    }

    /**
     * Show/hide content sections with a smooth animation.
     * @param {string} depth
     */
    function updateContent(depth) {
        var visible = visibleLevels(depth);
        var $wrapper = $('#dc-content-wrapper');

        $wrapper.find('.dc-depth-section').each(function() {
            var $section = $(this);
            var sectionDepth = $section.data('depth-level');
            var shouldShow = visible.indexOf(sectionDepth) !== -1;

            if (shouldShow && $section.hasClass('dc-depth-hidden')) {
                $section.removeClass('dc-depth-hidden')
                        .addClass('dc-depth-entering');
                // Force reflow before removing the entering class.
                $section[0].offsetHeight; // eslint-disable-line no-unused-expressions
                setTimeout(function() {
                    $section.removeClass('dc-depth-entering');
                }, 20);
            } else if (!shouldShow && !$section.hasClass('dc-depth-hidden')) {
                $section.addClass('dc-depth-exiting');
                setTimeout(function() {
                    $section.removeClass('dc-depth-exiting')
                            .addClass('dc-depth-hidden');
                }, 300);
            }
        });
    }

    /**
     * Persist the depth choice via AJAX.
     * @param {string} depth
     */
    function saveDepth(depth) {
        Ajax.call([{
            methodname: 'mod_depthcontent_set_depth',
            args: {
                depth: depth,
                remember: rememberPref,
                depthcontentid: instanceId
            },
            fail: function(err) {
                Notification.exception(err);
            }
        }]);
    }

    return {
        /**
         * Initialise the depth selector.
         *
         * @param {number} cmid          Course module id.
         * @param {number} depthcontentid Activity instance id.
         * @param {string} initialDepth  Currently active depth.
         * @param {boolean} remember     Current remember preference.
         * @param {string[]} allLevels   Ordered depth level names.
         * @param {string[]} available   Levels that have content for this point.
         */
        init: function(cmid, depthcontentid, initialDepth, remember, allLevels, available) {
            currentDepth = initialDepth;
            rememberPref = remember;
            instanceId = depthcontentid;
            depthOrder = allLevels;
            availableLevels = available;

            // Depth button click.
            $(document).on('click', '.dc-depth-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);

                // Ignore disabled buttons.
                if ($btn.hasClass('disabled') || $btn.attr('aria-disabled') === 'true') {
                    return;
                }

                var newDepth = $btn.data('depth');
                if (newDepth === currentDepth) {
                    return;
                }

                currentDepth = newDepth;
                updateButtons(newDepth);
                updateContent(newDepth);
                saveDepth(newDepth);
            });

            // Remember checkbox toggle.
            $(document).on('change', '#dc-remember-pref', function() {
                rememberPref = $(this).is(':checked');
                // Persist the preference immediately.
                Ajax.call([{
                    methodname: 'mod_depthcontent_set_depth',
                    args: {
                        depth: currentDepth,
                        remember: rememberPref,
                        depthcontentid: instanceId
                    },
                    fail: function(err) {
                        Notification.exception(err);
                    }
                }]);
            });

            // Keyboard navigation for the radio group.
            $(document).on('keydown', '.dc-depth-btn', function(e) {
                var $btn = $(this);
                var idx = depthOrder.indexOf($btn.data('depth'));
                var newIdx = -1;

                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    newIdx = idx + 1;
                    while (newIdx < depthOrder.length && availableLevels.indexOf(depthOrder[newIdx]) === -1) {
                        newIdx++;
                    }
                } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    newIdx = idx - 1;
                    while (newIdx >= 0 && availableLevels.indexOf(depthOrder[newIdx]) === -1) {
                        newIdx--;
                    }
                }

                if (newIdx >= 0 && newIdx < depthOrder.length) {
                    var $target = $('.dc-depth-btn[data-depth="' + depthOrder[newIdx] + '"]');
                    if ($target.length && !$target.hasClass('disabled')) {
                        $target.trigger('focus').trigger('click');
                    }
                }
            });
        }
    };
});
