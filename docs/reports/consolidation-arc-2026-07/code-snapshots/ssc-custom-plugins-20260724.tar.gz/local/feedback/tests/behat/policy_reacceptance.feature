@local @tool_policy @reacceptance
Feature: SS Moodle tool_policy forces re-acceptance after currentversion bump
  In order to keep user consent legally current across the federation
  As the SS Moodle site
  I require every user to re-accept any tool_policy document whose currentversion has been bumped

  Background:
    Given the following config values are set as admin:
      | key | value | plugin |
      | tool_policy_enabled       | 1                                                                 | tool_policy |
      | local_avc_copyright_sync_token | test-bearer-token-for-behat                                  | local_avc_copyright_sync |
    And the following tool_policy documents are published at version 1:
      | name              | type                  | title                              |
      | site_terms        | site                  | Site Terms of Use                  |
      | privacy_policy    | privacy               | Privacy Policy                     |
      | aup               | other                 | Acceptable Use Policy              |
      | copyright_notice  | other                 | Copyright Notice                   |
    And the following "users" exist:
      | username  | firstname | lastname  | email             |
      | alice     | Alice     | Tester    | alice@example.com |
      | bob       | Bob       | Newbie    | bob@example.com   |
    And alice has accepted Site Terms v1, Privacy Policy v1, AUP v1, Copyright Notice v1

  Scenario: A user who has accepted all current policies can use the site normally
    Given I log in as "alice"
    When I follow "Dashboard"
    Then I should see "My courses"
    And I should not be on the policy acceptance page

  @javascript
  Scenario: Bumping Site Terms from AVC forces re-acceptance on next login
    Given the AVC site POSTs a v2 update of "site_terms" to local/avc_copyright_sync/policy_set.php with token "test-bearer-token-for-behat"
    Then the response is 200 with body containing "ss_version_id"
    And tool_policy reports site_terms is at version 2
    When alice logs out
    And alice logs in
    Then alice is redirected to "/admin/tool/policy/index.php"
    And the page shows "Site Terms of Use" with "Updated" markers
    And alice cannot access "/my/" until she accepts the new version
    When alice accepts the new Site Terms version
    Then alice is taken to "/my/"
    And tool_policy shows alice has accepted site_terms v2

  Scenario: A user who has not accepted any policy is gated at first login
    Given I log in as "bob" who has no acceptances
    Then I am redirected to "/admin/tool/policy/index.php"
    And I see Site Terms of Use, Privacy Policy, AUP, and Copyright Notice
    And the Submit button is disabled until all are accepted

  Scenario: Invalid bearer token on the AVC sync endpoint is rejected
    Given the AVC site POSTs to local/avc_copyright_sync/policy_set.php with token "wrong-token"
    Then the response is 401
    And tool_policy reports site_terms is still at version 1

  Scenario: An admin can verify policy versions via Moodle admin UI
    Given I log in as "admin"
    When I follow "Site administration > Users > Privacy and policies > Manage policies"
    Then I see Site Terms of Use at version 1
    And I see Privacy Policy at version 1
    And I see AUP at version 1
    And I see Copyright Notice at version 1
