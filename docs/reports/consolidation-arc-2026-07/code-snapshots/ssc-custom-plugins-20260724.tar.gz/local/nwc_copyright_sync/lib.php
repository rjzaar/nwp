<?php
/**
 * local_nwc_copyright_sync — library hooks.
 *
 * The receiver entry point is policy_set.php (not a Moodle web
 * service — a plain PHP endpoint guarded by a Bearer token). Keep this
 * file minimal so plugin scanning works.
 */
defined('MOODLE_INTERNAL') || die();
