<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Pure state engine for the Application/Practice plane (N9 Plan-of-Love).
 *
 * PURE, unit-testable PHP. Every method takes plain arrays (engagement-log rows
 * + the checkpoint definition) and returns a plain array of derived state. There
 * are NO Moodle DB calls and NO Moodle globals here, so it runs without a Moodle
 * runtime and is table-driven testable (mirrors mod_depthcontent's mastery
 * evaluator). The impure adapter — engaged(): append log -> recompute -> upsert
 * state — lives in lib.php.
 *
 * TWO load-bearing rules are enforced HERE (and again at the lib.php write
 * boundary, belt-and-braces):
 *
 *   MF-2 FIREWALL (hard). A HABIT, RULE or CHALLENGE checkpoint can ONLY be
 *   engaged by an explicit member tick (source=manual). A view/scroll-sourced
 *   event on such a checkpoint is DROPPED — viewing a guide NEVER auto-marks a
 *   prayer/discipline done. (task/skill may auto-engage only when their def opts
 *   into an auto source via `autotick`.)
 *
 *   TICK-NOT-CALENDAR. For self-directed practice (pacing=tick, the default) a
 *   MISS IS A BLANK, NEVER A BROKEN STREAK: the streak is a cumulative count of
 *   engaged days and a gap does not reset it. Only calendar-paced checkpoints
 *   (the group-book-study flag, pacing=calendar) reset the streak on a gap.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_practice;

defined('MOODLE_INTERNAL') || die();

/**
 * Pure practice-state engine.
 *
 * An engagement-log row is an associative array with keys:
 *   ts        int    unix timestamp of the event (required)
 *   localdate int    YYYYMMDD in the member's timezone (required; the day bucket)
 *   source    string manual | view | scroll | cleared (required)
 *
 * A checkpoint definition is an associative array with keys:
 *   type              string task | challenge | habit | rule | skill | suggested (required)
 *   pacing            string tick | calendar (default tick)
 *   cadence           string once | daily | weekly | monthly | situational (optional)
 *   adopts_as         string (suggested only) the effective type after a tap-adopt
 *   on_consolidate    string (habit only) retire | promote | keep
 *   review_after_days int    (challenge only) review-gate window
 *   season            array  {window, completes_at} (optional; completes, never breaks)
 *
 * v3.3 (FORMATION-MASTER-DESIGN §1/§6) extends the type model from
 * task/skill/habit to the reconciled SIX member types + season windows. The two
 * load-bearing rules (MF-2, tick-not-calendar) are preserved verbatim and the
 * ENCOURAGEMENT invariants are baked in here: monotonic lifetime counts, NEVER
 * resettable streaks (a miss is a blank), season-window items COMPLETE (not
 * break) at window end. All numbers are INJECTED (practice_defaults), never
 * hardcoded at a call site.
 */
class engine {

    /** Confirmed content-consumption sources that MAY auto-engage a non-manual-only type. */
    const AUTO_SOURCES = ['view', 'scroll'];

    /**
     * Types on the MANUAL-ONLY side of the MF-2 firewall: a view/scroll can NEVER
     * engage these — only an explicit member tick. Prayer/discipline/devotion.
     */
    const MANUAL_ONLY_TYPES = ['habit', 'rule', 'challenge'];

    /**
     * Threshold defaults (injectable; nothing hardcoded at a call site). Mirrors
     * the schema.yaml `practice_defaults` block; a cadence-keyed value is resolved
     * per the def's cadence (see resolve_threshold()).
     *
     * @return array
     */
    public static function defaults(): array {
        return [
            // Distinct engaged days before a SKILL is "consolidated".
            'skill_consolidate_days' => 3,
            // Engaged days before a HABIT may consolidate (by cadence).
            'habit_form_count'       => ['daily' => 21, 'weekly' => 8, 'situational' => 5],
            // MIN first->last span (days) before a HABIT consolidates (anti-cramming).
            'habit_span_floor_days'  => ['daily' => 30, 'weekly' => 60, 'situational' => 21],
            // Default CHALLENGE review-gate window when the def sets no review_after_days.
            'challenge_window_days'  => ['daily' => 30, 'weekly' => 56, 'situational' => 21],
            // Optional YYYYMMDD "as of" date for season-window completion (else no auto-complete).
            'as_of_date'             => 0,
        ];
    }

    /**
     * Resolve a threshold value that may be a scalar OR a cadence-keyed map.
     *
     * @param mixed  $val     scalar, or ['daily'=>..,'weekly'=>..,...]
     * @param string $cadence the def's cadence
     * @param int    $fallback
     * @return int
     */
    public static function resolve_threshold($val, string $cadence, int $fallback): int {
        if (is_array($val)) {
            return (int) ($val[$cadence] ?? $val['daily'] ?? $fallback);
        }
        return (int) $val;
    }

    /**
     * The default CADENCE for a type when a def sets none.
     *
     * @param string $type
     * @return string
     */
    public static function default_cadence(string $type): string {
        switch ($type) {
            case 'task':      return 'once';
            case 'challenge': return 'daily';
            case 'habit':     return 'daily';
            case 'rule':      return 'daily';
            default:          return 'situational'; // skill | suggested
        }
    }

    /**
     * Merge injected thresholds over the defaults.
     *
     * @param array $injected
     * @return array
     */
    public static function thresholds(array $injected = []): array {
        return array_merge(self::defaults(), $injected);
    }

    /**
     * MF-2 firewall: may this event source engage this checkpoint type?
     *
     * A habit/rule/challenge is engageable ONLY by an explicit manual tick.
     * view/scroll (and any other auto source — adopt/paused/resumed included) are
     * rejected for them. task/skill may auto-engage only when their def opts into
     * an auto source (checked by the caller via the def's `autotick`); here we gate
     * purely on type-vs-source so the firewall holds even if a def is mis-typed.
     *
     * For a `suggested` checkpoint the caller passes its EFFECTIVE type (adopts_as)
     * once adopted; pre-adoption nothing engages it at all (see derive()).
     *
     * @param string $type   effective checkpoint type
     * @param string $source manual | view | scroll | cleared | adopt | paused | resumed
     * @return bool true iff the event may count as an engagement
     */
    public static function source_permitted(string $type, string $source): bool {
        if ($source === 'manual') {
            return true; // An explicit member tick always counts.
        }
        if ($source === 'cleared') {
            return false; // A clear is never itself an engagement.
        }
        // Auto sources (view|scroll): NEVER for a manual-only type (MF-2). Allowed otherwise.
        if (in_array($type, self::MANUAL_ONLY_TYPES, true)) {
            return false;
        }
        return in_array($source, self::AUTO_SOURCES, true);
    }

    /**
     * Resolve the winning mark for each engaged day.
     *
     * Per (localdate) precedence:  manual  >  cleared  >  auto(view|scroll).
     *  - a manual tick that day       => day is ENGAGED (done_manual)
     *  - else a cleared that day      => day is BLANK (untick-to-stay suppresses auto)
     *  - else an MF-2-permitted auto  => day is ENGAGED (done_auto)
     *
     * @param array  $log  Engagement-log rows.
     * @param string $type Checkpoint type (drives the MF-2 firewall).
     * @return array Map localdate(int) => ['engaged'=>bool, 'ts'=>int]
     */
    protected static function resolve_days(array $log, string $type): array {
        $byday = [];
        foreach ($log as $row) {
            $day = (int) ($row['localdate'] ?? 0);
            $ts  = (int) ($row['ts'] ?? 0);
            $src = (string) ($row['source'] ?? 'manual');
            if ($day <= 0) {
                continue;
            }
            if (!isset($byday[$day])) {
                $byday[$day] = ['manual' => null, 'cleared' => false, 'auto' => null];
            }
            if ($src === 'manual') {
                // Keep the latest manual ts that day.
                $byday[$day]['manual'] = max($byday[$day]['manual'] ?? 0, $ts);
            } else if ($src === 'cleared') {
                $byday[$day]['cleared'] = true;
            } else if (self::source_permitted($type, $src)) {
                // MF-2 permitted auto source (never reached for habits).
                $byday[$day]['auto'] = max($byday[$day]['auto'] ?? 0, $ts);
            }
            // A non-permitted auto source (e.g. view on a habit) is silently dropped.
        }

        $days = [];
        foreach ($byday as $day => $marks) {
            if ($marks['manual'] !== null) {
                $days[$day] = ['engaged' => true, 'ts' => $marks['manual']];
            } else if ($marks['cleared']) {
                $days[$day] = ['engaged' => false, 'ts' => 0]; // blank (suppressed).
            } else if ($marks['auto'] !== null) {
                $days[$day] = ['engaged' => true, 'ts' => $marks['auto']];
            }
        }
        ksort($days);
        return $days;
    }

    /**
     * Convert a YYYYMMDD int to a day-number (days since the Unix epoch, UTC).
     *
     * Used only to detect calendar adjacency for calendar-paced checkpoints.
     * Pure PHP (gmmktime); no Moodle runtime needed.
     *
     * @param int $ymd e.g. 20260720
     * @return int day number
     */
    public static function ymd_to_daynum(int $ymd): int {
        $y = intdiv($ymd, 10000);
        $m = intdiv($ymd % 10000, 100);
        $d = $ymd % 100;
        return (int) floor(gmmktime(0, 0, 0, $m, $d, $y) / 86400);
    }

    /**
     * Derive the full checkpoint state for one (member, checkpoint) from its log.
     *
     * @param array $log      Engagement-log rows for this (userid, checkpoint_uid).
     * @param array $def      Checkpoint def: {type, pacing, cadence, adopts_as,
     *                        on_consolidate, review_after_days, season}.
     * @param array $injected Injected thresholds (practice_defaults + as_of_date).
     * @return array {
     *     status             string  todo|offered|active|consolidated|done|paused|review|completed|started
     *     streak             int     tick: cumulative engaged days; calendar: trailing run (monotonic; a miss is a blank)
     *     engaged_days       int     distinct engaged days (monotonic lifetime count)
     *     last_engaged_at    int     unix ts of last engagement (0 = never)
     *     last_engaged_date  int     YYYYMMDD of last engagement (0 = never)
     *     first_engaged_date int     YYYYMMDD of first engagement (0 = never)
     *     effective_type     string  the type the engine evaluated (adopts_as for an adopted suggested)
     *     adopted            bool     a suggested checkpoint has been tap-adopted
     *     adopted_as         string|null
     *     review_due         bool     a challenge has reached its review gate
     *     on_consolidate     string|null  the fired outcome when a habit consolidates (retire|promote|keep)
     *     season_completed   bool     a season window has closed (item COMPLETED, not broken)
     * }
     */
    public static function derive(array $log, array $def, array $injected = []): array {
        $t       = self::thresholds($injected);
        $type    = (string) ($def['type'] ?? 'task');
        $pacing  = (string) ($def['pacing'] ?? 'tick');
        $cadence = (string) ($def['cadence'] ?? self::default_cadence($type));

        // --- SUGGESTED: adoption is an explicit TAP (never scroll-accept) ------
        // Pre-adoption a suggestion is STATELESS ("offered") — zero pressure. The
        // effective type after adoption is its adopts_as; only rows at/after the
        // adopt event count. A 'view' NEVER adopts (mirrors N9 tap-accept).
        $adopted   = false;
        $adoptedas = null;
        $adoptts   = 0;
        if ($type === 'suggested') {
            $adoptedas = (string) ($def['adopts_as'] ?? 'task');
            foreach ($log as $row) {
                if ((string) ($row['source'] ?? '') === 'adopt') {
                    $adopted = true;
                    $adoptts = (int) ($row['ts'] ?? 0);
                    break; // the first adopt wins.
                }
            }
            if (!$adopted) {
                return self::blank_state('offered', 'suggested', false, $adoptedas);
            }
        }
        $efftype = ($type === 'suggested') ? $adoptedas : $type;

        // For an adopted suggestion, engagement only counts from the adopt event on.
        $engagelog = $log;
        if ($type === 'suggested') {
            $engagelog = array_filter($log, static function ($r) use ($adoptts) {
                return (int) ($r['ts'] ?? 0) >= $adoptts;
            });
        }

        $days = self::resolve_days($engagelog, $efftype);

        // Distinct ENGAGED days, in ascending order.
        $engageddays = [];
        foreach ($days as $day => $d) {
            if ($d['engaged']) {
                $engageddays[$day] = $d['ts'];
            }
        }
        $engagedcount = count($engageddays);

        $lastat = $lastdate = $firstdate = 0;
        if ($engagedcount > 0) {
            $firstdate = (int) array_key_first($engageddays);
            $lastdate  = (int) array_key_last($engageddays);
            $lastat    = (int) $engageddays[$lastdate];
        }

        // --- Streak (monotonic — a miss is a BLANK, never a broken streak) ----
        if ($pacing === 'calendar') {
            $streak = 0;
            $prev = null;
            foreach (array_keys($engageddays) as $day) {
                $dn = self::ymd_to_daynum((int) $day);
                if ($prev !== null && ($dn - $prev) === 1) {
                    $streak++;
                } else {
                    $streak = 1; // start (or restart after a gap) a new run.
                }
                $prev = $dn;
            }
        } else {
            $streak = $engagedcount; // tick-not-calendar: cumulative, never resets.
        }

        // --- Inclusive first->last span in days (for consolidation / review) --
        $spandays = 0;
        if ($engagedcount > 0) {
            $spandays = self::ymd_to_daynum($lastdate) - self::ymd_to_daynum($firstdate) + 1;
        }

        // --- Status + lifecycle signals per effective type --------------------
        $reviewdue    = false;
        $onconsolid   = null;
        $status = self::compute_status($efftype, $cadence, $engagedcount, $spandays, $def, $t, $reviewdue, $onconsolid);

        // --- Shame-free PAUSE (rule/habit): a trailing pause overrides status --
        if (self::is_paused($log, $lastat)) {
            $status = 'paused';
        }

        // --- SEASON WINDOW: completes (never breaks) at completes_at ----------
        // The window CLOSING marks the item COMPLETED — its counts/streak stand
        // (monotonic); it is never rendered as a broken streak at Easter.
        $seasoncompleted = false;
        $completesat = self::season_completes_at($def);
        $asof = (int) ($t['as_of_date'] ?? 0);
        if ($completesat > 0 && $asof > 0 && $asof >= $completesat) {
            $seasoncompleted = true;
            $status = 'completed';
        }

        return [
            'status'             => $status,
            'streak'             => $streak,
            'engaged_days'       => $engagedcount,
            'last_engaged_at'    => $lastat,
            'last_engaged_date'  => $lastdate,
            'first_engaged_date' => $firstdate,
            'effective_type'     => $efftype,
            'adopted'            => ($type === 'suggested') ? $adopted : false,
            'adopted_as'         => $adoptedas,
            'review_due'         => $reviewdue,
            'on_consolidate'     => $onconsolid,
            'season_completed'   => $seasoncompleted,
        ];
    }

    /**
     * A zeroed state row (used for an un-adopted suggestion / empty cases).
     */
    protected static function blank_state(string $status, string $efftype, bool $adopted, ?string $adoptedas): array {
        return [
            'status'             => $status,
            'streak'             => 0,
            'engaged_days'       => 0,
            'last_engaged_at'    => 0,
            'last_engaged_date'  => 0,
            'first_engaged_date' => 0,
            'effective_type'     => $efftype,
            'adopted'            => $adopted,
            'adopted_as'         => $adoptedas,
            'review_due'         => false,
            'on_consolidate'     => null,
            'season_completed'   => false,
        ];
    }

    /**
     * Map engagement to a lifecycle status for a checkpoint (effective) type.
     *
     *   task      : todo -> done (completes on first engagement; re-openable via a clear)
     *   skill     : todo -> started (>=1) -> consolidated (>= skill_consolidate_days) -> toolkit
     *   habit     : todo -> active (>=1) -> consolidated (engaged >= form_count AND span >= span_floor);
     *               at consolidation, fires `on_consolidate` (retire|promote|keep, default keep)
     *   rule      : todo -> active (>=1); NEVER completes, NEVER consolidates, NEVER retires
     *   challenge : todo -> active (within window) -> review (engaged >= window OR span >= window)
     *
     * @param string $type        effective type
     * @param string $cadence
     * @param int    $engagedcount
     * @param int    $spandays     inclusive first->last span in days
     * @param array  $def
     * @param array  $t            thresholds
     * @param bool   $reviewdue    OUT: set true when a challenge hits its review gate
     * @param string|null $onconsolid OUT: the fired on_consolidate outcome for a consolidated habit
     * @return string
     */
    protected static function compute_status(string $type, string $cadence, int $engagedcount, int $spandays,
            array $def, array $t, bool &$reviewdue, ?string &$onconsolid): string {
        if ($engagedcount <= 0) {
            return 'todo';
        }
        switch ($type) {
            case 'task':
                return 'done';

            case 'skill':
                return ($engagedcount >= (int) $t['skill_consolidate_days']) ? 'consolidated' : 'started';

            case 'challenge':
                $window = (int) ($def['review_after_days']
                    ?? self::resolve_threshold($t['challenge_window_days'] ?? 30, $cadence, 30));
                if ($window > 0 && ($engagedcount >= $window || $spandays >= $window)) {
                    $reviewdue = true;
                    return 'review';
                }
                return 'active';

            case 'rule':
                return 'active'; // permanent essential — never consolidates, never done.

            case 'habit':
            default:
                $formcount = self::resolve_threshold($t['habit_form_count'] ?? 21, $cadence, 21);
                $spanfloor = self::resolve_threshold($t['habit_span_floor_days'] ?? 30, $cadence, 30);
                if ($engagedcount >= $formcount && $spandays >= $spanfloor) {
                    // At the automaticity plateau. Fire the authored on_consolidate
                    // (default keep — the member is the only honest sensor; never
                    // auto-retire an unformed habit).
                    $onconsolid = (string) ($def['on_consolidate'] ?? 'keep');
                    return 'consolidated';
                }
                return 'active';
        }
    }

    /**
     * A shame-free PAUSE is a trailing `paused` marker not followed by any later
     * engagement or `resumed`. Applies to rule/habit; harmless elsewhere.
     *
     * @param array $log        the full log (unfiltered)
     * @param int   $lastengagedat ts of the last counted engagement
     * @return bool
     */
    protected static function is_paused(array $log, int $lastengagedat): bool {
        $lastpause = 0;
        $lastresume = 0;
        foreach ($log as $row) {
            $src = (string) ($row['source'] ?? '');
            $ts  = (int) ($row['ts'] ?? 0);
            if ($src === 'paused') {
                $lastpause = max($lastpause, $ts);
            } else if ($src === 'resumed') {
                $lastresume = max($lastresume, $ts);
            }
        }
        if ($lastpause <= 0) {
            return false;
        }
        // Paused iff the pause is the most recent state-affecting event.
        return $lastpause >= $lastengagedat && $lastpause >= $lastresume;
    }

    /**
     * Resolve a def's season.completes_at to a YYYYMMDD int, if it is a date.
     * An event-slug completes_at (e.g. "easter") is resolved upstream by the
     * caller (liturgical calendar) before injection; here we only handle a date.
     *
     * @param array $def
     * @return int YYYYMMDD, or 0 if none / not a date
     */
    protected static function season_completes_at(array $def): int {
        $season = $def['season'] ?? null;
        if (!is_array($season)) {
            return 0;
        }
        $c = $season['completes_at'] ?? null;
        if (is_int($c)) {
            return $c;
        }
        if (is_string($c) && ctype_digit($c) && strlen($c) === 8) {
            return (int) $c;
        }
        return 0; // an event slug — resolved by the caller, not here.
    }
}
