<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Pure PROGRESSION-DISPLAY layer for the Plan-of-Love practice plane.
 *
 * This is the DISPLAY/PREFERENCE layer sitting ON TOP OF the pure state engine
 * (classes/engine.php). It NEVER records, mutates, or gates any state — it maps
 * an already-recorded state array to what should render, governed by the member's
 * `progression_view` preference (full | gentle | quiet).
 *
 * THE LOAD-BEARING INVARIANT (FORMATION-progression-visibility.md): hiding is
 * NEVER a data operation. All progression data is ALWAYS recorded regardless of
 * the mode — `quiet` suppresses the *view*, never the recording. Every method
 * here is a pure read over an engine-state array; none of them touch the log or
 * the state store. (The Moodle adapters — get/set the pref, load the state row —
 * live in lib.php.)
 *
 * ENCOURAGEMENT INVARIANTS baked in here (FORMATION-MASTER-DESIGN §3):
 *   - States, not scores: —/forming/held/formed (never a fragile resettable chain).
 *   - Fidelity LIFETIME count only (monotonic engaged_days), never a resettable streak.
 *   - Grace framing on every rendered payload ("practice disposes; God gives"),
 *     never performance/achievement framing.
 *   - NO comparison-to-others field, EVER — no leaderboards, no rankings, no
 *     percentiles. Structurally impossible: view() emits only from a fixed
 *     allowlist, and contains_comparison() proves the guard in tests.
 *   - Never-miss-twice is the ONLY lapse nudge, and it is self-compassionate.
 *
 * PURE PHP: runs WITHOUT a Moodle runtime and is table-driven testable
 * (tests/progression_test.php), mirroring engine.php + def_sync.php.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_practice;

defined('MOODLE_INTERNAL') || die();

/**
 * Pure progression-display helper.
 */
class progression {

    /** The three progression-view display modes. */
    const MODES = ['full', 'gentle', 'quiet'];

    /** Default mode — Gentle (honours encouragement AND the anti-scrupulosity concern). */
    const DEFAULT_MODE = 'gentle';

    /**
     * The member-facing progression STATES (—/forming/held/formed). A monotonic
     * ladder derived from the recorded engine status; NOT a score.
     */
    const STATE_NONE    = 'none';
    const STATE_FORMING = 'forming';
    const STATE_HELD    = 'held';
    const STATE_FORMED  = 'formed';

    /**
     * Days a held/formed item may lapse before it renders "due for renewal"
     * (an INVITATION, never a demotion). Injectable; Pedagogy-owned in a later phase.
     */
    const RENEWAL_AFTER_DAYS = 30;

    /**
     * Substrings that may NEVER appear as a key in a rendered payload. This is the
     * anti-comparison / anti-leaderboard guard, proved in tests via
     * contains_comparison(). "The pride risk is comparison" (progression-visibility
     * §Guardrails) — one's OWN growth is legitimate; a ranking never is.
     */
    const FORBIDDEN_KEY_TOKENS = [
        'rank', 'leaderboard', 'compare', 'comparison', 'versus', 'vs',
        'others', 'percentile', 'position', 'place', 'peer', 'cohort', 'top',
    ];

    /**
     * Normalise an arbitrary preference value to a valid mode (default Gentle).
     *
     * @param string|null $mode
     * @return string one of self::MODES
     */
    public static function normalise_mode(?string $mode): string {
        $mode = is_string($mode) ? strtolower(trim($mode)) : '';
        return in_array($mode, self::MODES, true) ? $mode : self::DEFAULT_MODE;
    }

    /**
     * The default progression-view mode.
     *
     * @return string
     */
    public static function default_mode(): string {
        return self::DEFAULT_MODE;
    }

    /**
     * Map a recorded engine-state array to the member-facing progression STATE.
     *
     * The four states are a display rendering of the engine's lifecycle status —
     * they read nothing but the already-recorded state (pure).
     *
     *   none    (—) : nothing engaged yet (todo | offered)
     *   forming (◐) : engaged, below the automaticity plateau (started|active|review)
     *   held    (●) : reached the plateau / completed the arc (consolidated|done|completed)
     *   formed  (★) : a consolidated item designated to become a permanent Rule
     *                 (on_consolidate=promote) — "formed into character"
     *
     * NOTE (assumption, flagged): the practice-plane "formed"/CHARACTER durability
     * threshold is Pedagogy-owned and not yet numerically specified, so `formed`
     * currently triggers on the explicit promote designation (a consolidated habit
     * on its way to a permanent Rule). A durability-span rule can slot in later
     * without changing this contract.
     *
     * @param array $state Engine-state array (see engine::derive()).
     * @return string one of STATE_*
     */
    public static function progression_state(array $state): string {
        $engaged = (int) ($state['engaged_days'] ?? 0);
        $status  = (string) ($state['status'] ?? 'todo');
        if ($engaged <= 0 || in_array($status, ['todo', 'offered'], true)) {
            return self::STATE_NONE;
        }
        switch ($status) {
            case 'consolidated':
                return ((string) ($state['on_consolidate'] ?? '') === 'promote')
                    ? self::STATE_FORMED : self::STATE_HELD;
            case 'done':
            case 'completed':
                return self::STATE_HELD;
            case 'started':
            case 'active':
            case 'review':
            case 'paused':
            default:
                return self::STATE_FORMING;
        }
    }

    /**
     * The practice-plane growth marker (ACT -> HABIT -> CHARACTER analog), derived
     * PURELY from the recorded practice state.
     *
     * FIREWALL NOTE: this is the DOING-plane analog only. The doctrinal KNOWING
     * ledger's ACT/HABIT/CHARACTER (mod_depthcontent) is a separate, firewalled
     * plane and is NEVER cross-read here (two characters, firewalled — MASTERY
     * §A.8.4). Full mode surfaces this practice-plane growth; the knowing ledger
     * surfaces its own, elsewhere, in the member's private view.
     *
     * @param array $state
     * @return string|null ACT | HABIT | CHARACTER, or null when nothing engaged.
     */
    public static function growth(array $state): ?string {
        switch (self::progression_state($state)) {
            case self::STATE_FORMING: return 'ACT';
            case self::STATE_HELD:    return 'HABIT';
            case self::STATE_FORMED:  return 'CHARACTER';
            default:                  return null;
        }
    }

    /**
     * Gentle milestones reached — SPARINGLY, at real thresholds only (first
     * begun; consolidated; completed; formed). Never "started daily", never a
     * per-tick event.
     *
     * @param array $state
     * @return string[] milestone slugs, in ladder order.
     */
    public static function milestones(array $state): array {
        $engaged = (int) ($state['engaged_days'] ?? 0);
        $status  = (string) ($state['status'] ?? 'todo');
        $ms = [];
        if ($engaged >= 1) {
            $ms[] = 'begun';                 // first adoption / first real act.
        }
        if ($status === 'consolidated') {
            $ms[] = 'consolidated';          // "kept for a month" — the unit of celebration.
        }
        if (in_array($status, ['done', 'completed'], true)) {
            $ms[] = 'completed';             // an arc completed (a season completes, never breaks).
        }
        if (self::progression_state($state) === self::STATE_FORMED) {
            $ms[] = 'formed';
        }
        return $ms;
    }

    /**
     * The state's display symbol (—/◐/●/★).
     *
     * @param string $state STATE_*
     * @return string
     */
    public static function state_symbol(string $state): string {
        switch ($state) {
            case self::STATE_FORMING: return '◐';
            case self::STATE_HELD:    return '●';
            case self::STATE_FORMED:  return '★';
            default:                  return '—';
        }
    }

    /**
     * Is a held/formed item lapsed past its renewal window? Renders as an
     * INVITATION ("due for renewal"), NEVER a demotion (never-demote invariant).
     *
     * @param array $state
     * @param int   $asof   YYYYMMDD "today" (0 => unknown => never due).
     * @param int   $window renewal window in days (default RENEWAL_AFTER_DAYS).
     * @return bool
     */
    public static function renewal_due(array $state, int $asof = 0, int $window = self::RENEWAL_AFTER_DAYS): bool {
        $ps = self::progression_state($state);
        if ($ps !== self::STATE_HELD && $ps !== self::STATE_FORMED) {
            return false;
        }
        $last = (int) ($state['last_engaged_date'] ?? 0);
        if ($asof <= 0 || $last <= 0) {
            return false;
        }
        $lapsed = engine::ymd_to_daynum($asof) - engine::ymd_to_daynum($last);
        return $lapsed >= $window;
    }

    /**
     * The grace/gratitude FRAMING string for a mode — oriented to God's grace
     * working, never performance/achievement ("practice disposes; God gives").
     * Present on EVERY rendered payload, including the suppressed quiet payload.
     *
     * @param string $mode
     * @return string
     */
    public static function grace_framing(string $mode): string {
        switch (self::normalise_mode($mode)) {
            case 'full':
                return 'Growth in fidelity — by grace. Practice disposes; God gives.';
            case 'quiet':
                return 'Quietly kept, held in grace. Practice disposes; God gives.';
            case 'gentle':
            default:
                return 'Held in grace — practice disposes; God gives.';
        }
    }

    /**
     * Build the member's progression-view PAYLOAD for one checkpoint, governed by
     * the member's mode. DISPLAY ONLY — reads the recorded state, never mutates it.
     *
     * Field granularity by mode:
     *   quiet  : {mode, suppressed:true, framing}                    (no progression data)
     *   gentle : + {state, state_symbol, state_label_key, milestones,
     *               renewal_due, paused, anchor}                     (states + milestones only)
     *   full   : gentle + {growth, lifetime_count}                   (+ mastery growth + fidelity count)
     *
     * NEVER emitted at any granularity: any comparison/ranking/leaderboard field
     * (contains_comparison() proves it), any resettable-streak field.
     *
     * @param array  $state Engine-state array (see engine::derive()) + optional
     *                      'anchor_plan' (the member's if-then implementation intention).
     * @param string $mode  full | gentle | quiet.
     * @param int    $asof  YYYYMMDD "today" for renewal detection (0 => none).
     * @return array The render payload.
     */
    public static function view(array $state, string $mode, int $asof = 0): array {
        $mode = self::normalise_mode($mode);
        $framing = self::grace_framing($mode);

        // QUIET — suppress the whole progression view; the member just does the
        // next thing. Data is STILL recorded (this function never touches it).
        if ($mode === 'quiet') {
            return [
                'mode'       => 'quiet',
                'suppressed' => true,
                'framing'    => $framing,
            ];
        }

        $ps = self::progression_state($state);
        $payload = [
            'mode'             => $mode,
            'suppressed'       => false,
            'framing'          => $framing,
            'state'            => $ps,
            'state_symbol'     => self::state_symbol($ps),
            'state_label_key'  => 'pstate_' . $ps,
            'milestones'       => self::milestones($state),
            'renewal_due'      => self::renewal_due($state, $asof),
            'paused'           => ((string) ($state['status'] ?? '') === 'paused'),
            'anchor'           => self::sanitise_anchor($state['anchor_plan'] ?? null),
        ];

        // FULL — add the mastery growth marker + the fidelity LIFETIME count
        // (monotonic engaged_days; NEVER a resettable streak).
        if ($mode === 'full') {
            $payload['growth']         = self::growth($state);
            $payload['lifetime_count'] = (int) ($state['engaged_days'] ?? 0);
        }

        return $payload;
    }

    /**
     * Guard predicate: does any key in this (possibly nested) payload look like a
     * comparison-to-others field? Used by tests to PROVE no leaderboard/ranking
     * field can ever be emitted.
     *
     * @param array $payload
     * @return bool true iff a forbidden comparison-shaped key is present.
     */
    public static function contains_comparison(array $payload): bool {
        foreach ($payload as $key => $value) {
            $k = strtolower((string) $key);
            foreach (self::FORBIDDEN_KEY_TOKENS as $tok) {
                if (strpos($k, $tok) !== false) {
                    return true;
                }
            }
            if (is_array($value) && self::contains_comparison($value)) {
                return true;
            }
        }
        return false;
    }

    // ========================================================================
    // NEVER-MISS-TWICE — the ONLY lapse nudge (gentle, self-compassionate).
    // ========================================================================

    /**
     * Period length in days for a cadence (for the never-miss-twice arithmetic).
     * Non-periodic cadences (once/situational) return 0 => no miss concept => no nudge.
     *
     * @param string $cadence
     * @return int days, or 0 if not periodic.
     */
    public static function cadence_period_days(string $cadence): int {
        switch ($cadence) {
            case 'daily':   return 1;
            case 'weekly':  return 7;
            case 'monthly': return 30;
            default:        return 0; // once | situational — no calendar miss.
        }
    }

    /**
     * NEVER-MISS-TWICE nudge. A single miss is a BLANK, not a broken streak — so
     * this fires ONLY when the member has already missed ONE expected period and
     * the CURRENT period is still open (the "don't let it become two" moment). It
     * NEVER fires on a single fresh miss, and (deliberately) stops firing once two
     * or more periods have already lapsed — that is human re-engagement territory,
     * not this nudge.
     *
     *   elapsed_missed = floor((asof - last_engaged) / period) - 1   (current period open)
     *     0  -> on track / single fresh blank        -> NO nudge
     *     1  -> missed once, second at risk           -> FIRE
     *    >=2 -> already missed twice+                 -> NO nudge (out of scope)
     *
     * The copy is gentle and self-compassionate (Wohl; Breines & Chen: self-
     * compassion after a lapse improves adherence), never corrective.
     *
     * @param int    $lastengageddate YYYYMMDD of the last engagement (0 => never engaged => no nudge).
     * @param int    $asof            YYYYMMDD "today".
     * @param string $cadence         once | daily | weekly | monthly | situational.
     * @return array|null {fires:true, level:'never_miss_twice', message_key, message} or null.
     */
    public static function never_miss_twice_nudge(int $lastengageddate, int $asof, string $cadence) {
        $period = self::cadence_period_days($cadence);
        if ($period <= 0 || $lastengageddate <= 0 || $asof <= 0) {
            return null; // no periodic-miss concept, or never engaged.
        }
        $gap = engine::ymd_to_daynum($asof) - engine::ymd_to_daynum($lastengageddate);
        if ($gap <= 0) {
            return null; // engaged today (or a future-dated last engagement) — nothing missed.
        }
        $elapsedmissed = intdiv($gap, $period) - 1;
        if ($elapsedmissed !== 1) {
            return null; // 0 = single blank / on track; >=2 = beyond the never-miss-twice window.
        }
        return [
            'fires'       => true,
            'level'       => 'never_miss_twice',
            'message_key' => 'nudge_never_miss_twice',
            // Gentle, self-compassionate, never corrective. Grace-framed.
            'message'     => 'A blank day is just a blank — not a broken streak. '
                . 'Come back today; the practice is glad to have you.',
        ];
    }

    /**
     * Sanitise a member-supplied anchor plan (if-then implementation intention).
     * Trims, collapses to null when empty, caps length (stored in a CHAR(255) col).
     *
     * @param mixed $anchor
     * @return string|null
     */
    public static function sanitise_anchor($anchor): ?string {
        if (!is_string($anchor)) {
            return null;
        }
        $anchor = trim($anchor);
        if ($anchor === '') {
            return null;
        }
        // Cap to the column width; multibyte-safe.
        if (function_exists('mb_substr')) {
            return mb_substr($anchor, 0, 255);
        }
        return substr($anchor, 0, 255);
    }
}
