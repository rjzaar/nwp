<?php
defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot . '/course/format/topics/lib.php');

class format_tabbed extends format_topics {

    public function get_default_section_name($section) {
        if ($section->section == 0) {
            return get_string('section0name', 'format_tabbed');
        }
        return get_string('sectionname', 'format_tabbed') . ' ' . $section->section;
    }

    public function course_format_options($foreditform = false) {
        return parent::course_format_options($foreditform);
    }

    public function get_view_url($section, $options = []) {
        return parent::get_view_url($section, $options);
    }
}
