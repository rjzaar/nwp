<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname']       = 'Feedback widget';
$string['feedback']         = 'Feedback';
$string['feedback:submit']  = 'Submit feedback';
$string['feedback:review']  = 'Review and approve feedback';
$string['feedback:viewboard'] = 'View the suggestion board';

// Settings.
$string['settings_general']        = 'General';
$string['settings_enabled']        = 'Widget enabled';
$string['settings_enabled_desc']   = 'When enabled, every page on the site shows the floating feedback button.';
$string['settings_logged_in_only'] = 'Logged-in users only';
$string['settings_logged_in_only_desc'] = 'When enabled, anonymous visitors will not see the widget.';
$string['settings_gitlab']         = 'GitLab forwarding';
$string['settings_gitlab_url']     = 'GitLab API base';
$string['settings_gitlab_url_desc'] = 'e.g. https://git.nwpcode.org/api/v4 — leave blank to disable GitLab forwarding';
$string['settings_gitlab_project'] = 'GitLab project (urlencoded path or numeric id)';
$string['settings_gitlab_project_desc'] = 'e.g. nwp%2Fcourses or 42 — the project where issues are created';
$string['settings_gitlab_token']   = 'GitLab API token';
$string['settings_gitlab_token_desc'] = 'Token with `api` scope. Stored in config_plugins.';
$string['settings_avc']            = 'NWC Trialing Guild logging';
$string['settings_avc_url']        = 'NWC feedback log (legacy AVC also supported) endpoint';
$string['settings_avc_url_desc']   = 'e.g. https://nwc.nwpcode.org/api/feedback/log — leave blank to disable. The endpoint should accept POSTed JSON {oauth_sub, title, body, type, target_url, ss_feedback_id, status, timecreated}.';
$string['settings_avc_token']      = 'NWC API token (legacy AVC also supported)';
$string['settings_avc_token_desc'] = 'Shared secret presented as Authorization: Bearer <token>.';
$string['settings_avc_score_default'] = 'Default approval score';
$string['settings_avc_score_default_desc'] = 'Points awarded to the submitter on NWC when a mentor approves their feedback. Default 10.';

// Widget UI.
$string['widget_title']            = 'Quick Feedback';
$string['widget_type_suggestion']  = 'Suggestion';
$string['widget_type_question']    = 'Question';
$string['widget_type_issue']       = 'Issue';
$string['widget_type_praise']      = 'Praise';
$string['widget_title_placeholder'] = 'Brief title...';
$string['widget_body_placeholder'] = 'Details (optional)...';
$string['widget_submit']           = 'Submit';
$string['widget_submitting']       = 'Submitting...';
$string['widget_thanks']           = 'Thank you for your feedback!';
$string['widget_error']            = 'Something went wrong. Please try again.';
$string['widget_view_board']       = 'View suggestion board';
$string['widget_login_required']   = 'Please log in to send feedback.';

// Admin views.
$string['index_title']             = 'Saint School Feedback';
$string['index_intro']             = 'Every submission from the floating feedback widget. Mentors of the Tester Guild can approve or reject — approved items credit the submitter with score points on NWC.';
$string['status_pending']          = 'Pending';
$string['status_approved']         = 'Approved';
$string['status_rejected']         = 'Rejected';
$string['status_implemented']      = 'Implemented';
$string['status_duplicate']        = 'Duplicate';
$string['action_approve']          = 'Approve';
$string['action_reject']           = 'Reject';
$string['action_implement']        = 'Mark implemented';
$string['action_dup']              = 'Mark duplicate';
$string['action_review_comment']   = 'Review comment (optional)';
$string['view_title']               = 'Feedback #{$a}';

// Events.
$string['event_feedback_submitted'] = 'Feedback submitted';
$string['event_feedback_reviewed']  = 'Feedback reviewed';
