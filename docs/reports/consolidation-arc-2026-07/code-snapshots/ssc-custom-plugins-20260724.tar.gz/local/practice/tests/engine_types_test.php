<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Table-driven unit tests for the v3.3 FORMATION per-type lifecycles.
 *
 * Runs WITHOUT a Moodle runtime:  php tests/engine_types_test.php
 *
 * Proves the six-type model + the ENCOURAGEMENT invariants:
 *   - CHALLENGE review-gate (window elapsed OR window-many engaged days -> review).
 *   - RULE manual-only (MF-2) + NEVER completes/consolidates (permanent essential).
 *   - SUGGESTED tap-adopt (offered until an explicit 'adopt'; then effective type;
 *     a view NEVER adopts).
 *   - HABIT consolidate -> on_consolidate (retire | promote | keep).
 *   - MONOTONIC, NEVER-resettable streaks (a miss is a blank) for a rule.
 *   - SEASON WINDOW COMPLETES (never breaks) at completes_at; counts preserved.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
require_once(__DIR__ . '/../classes/engine.php');

use local_practice\engine;

$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
$GLOBALS['__fails'] = [];

function check(string $name, $expected, $actual): void {
    if ($expected === $actual) {
        $GLOBALS['__pass']++;
    } else {
        $GLOBALS['__fail']++;
        $GLOBALS['__fails'][] = sprintf("  FAIL: %s\n        expected=%s got=%s",
            $name, var_export($expected, true), var_export($actual, true));
    }
}

const BASE = 1700000000;
const DAY = 86400;

/** Engagement-log row. $dayoffset sets the ts so 'adopt' precedes later engagement. */
function e(int $ymd, string $source = 'manual', int $dayoffset = 0): array {
    return ['ts' => BASE + $dayoffset * DAY, 'localdate' => $ymd, 'source' => $source];
}

// Fast thresholds so consolidation is reachable in a tiny table.
$fast = ['habit_form_count' => ['daily' => 3], 'habit_span_floor_days' => ['daily' => 3]];

// ===========================================================================
// CHALLENGE — a REVIEW GATE (run a window -> surface a review -> decide)
// ===========================================================================

$challenge = ['type' => 'challenge', 'cadence' => 'daily', 'review_after_days' => 7];

// Within the window (3 engaged days, span 3) -> active, no review yet.
$s = engine::derive([e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260703, 'manual', 2)], $challenge);
check('CHAL.active_within_window', 'active', $s['status']);
check('CHAL.no_review_yet', false, $s['review_due']);

// Span reaches the window (d0..d6 = span 7) -> REVIEW gate surfaces.
$s = engine::derive([e(20260701, 'manual', 0), e(20260707, 'manual', 6)], $challenge);
check('CHAL.review_on_window_span', 'review', $s['status']);
check('CHAL.review_due_true', true, $s['review_due']);

// Window from injected challenge_window_days when the def sets no review_after_days.
$chalnowin = ['type' => 'challenge', 'cadence' => 'daily'];
$log5 = [];
for ($i = 0; $i < 5; $i++) { $log5[] = e(20260701 + $i, 'manual', $i); }
$s = engine::derive($log5, $chalnowin, ['challenge_window_days' => ['daily' => 5]]);
check('CHAL.default_window_review', 'review', $s['status']);

// MF-2: a view never ticks a challenge.
check('CHAL.mf2_view_blocked', false, engine::source_permitted('challenge', 'view'));

// ===========================================================================
// RULE — permanent essential: manual-only (MF-2), NEVER completes/consolidates
// ===========================================================================

$rule = ['type' => 'rule', 'cadence' => 'daily'];

// A view/scroll never engages a rule.
$s = engine::derive([e(20260701, 'view'), e(20260702, 'scroll')], $rule);
check('RULE.mf2_view_no_engage', 0, $s['engaged_days']);
check('RULE.mf2_view_todo', 'todo', $s['status']);
check('RULE.pred_view', false, engine::source_permitted('rule', 'view'));
check('RULE.pred_manual', true, engine::source_permitted('rule', 'manual'));

// A manual tick makes it active.
$s = engine::derive([e(20260701, 'manual')], $rule);
check('RULE.manual_active', 'active', $s['status']);

// Even 40 engaged days over a 40-day span NEVER consolidates — a rule is permanent.
$rulelog = [];
for ($i = 0; $i < 40; $i++) { $rulelog[] = e(20260701 + $i, 'manual', $i); }
$s = engine::derive($rulelog, $rule, $fast); // fast thresholds would consolidate a HABIT.
check('RULE.never_consolidates', 'active', $s['status']);
check('RULE.no_on_consolidate', null, $s['on_consolidate']);

// MONOTONIC, NEVER-resettable streak: a gap is a blank, the count only grows.
$s = engine::derive([e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260710, 'manual', 9)], $rule);
check('RULE.streak_monotonic', 3, $s['streak']);
check('RULE.engaged_days', 3, $s['engaged_days']);

// Shame-free PAUSE: a trailing 'paused' overrides status (no shame, re-activatable).
$s = engine::derive([e(20260701, 'manual', 0), e(20260702, 'paused', 1)], $rule);
check('RULE.paused', 'paused', $s['status']);
// A later manual tick un-pauses.
$s = engine::derive([e(20260701, 'manual', 0), e(20260702, 'paused', 1), e(20260703, 'manual', 2)], $rule);
check('RULE.resumed_by_tick', 'active', $s['status']);

// ===========================================================================
// SUGGESTED — stateless until an explicit TAP-ADOPT (never scroll-accept)
// ===========================================================================

$suggested = ['type' => 'suggested', 'cadence' => 'situational', 'adopts_as' => 'habit'];

// No adopt event -> OFFERED, zero state pressure (even a stray view does nothing).
$s = engine::derive([e(20260701, 'view')], $suggested);
check('SUG.offered_until_adopt', 'offered', $s['status']);
check('SUG.offered_no_engaged', 0, $s['engaged_days']);
check('SUG.offered_not_adopted', false, $s['adopted']);
check('SUG.effective_type_suggested', 'suggested', $s['effective_type']);

// A view NEVER adopts (only an explicit 'adopt' tap does).
$s = engine::derive([e(20260701, 'view'), e(20260702, 'scroll')], $suggested);
check('SUG.view_never_adopts', false, $s['adopted']);

// After a tap-adopt it behaves as its adopts_as (habit): first tick -> active.
$s = engine::derive([e(20260701, 'adopt', 0), e(20260701, 'manual', 0)], $suggested);
check('SUG.adopted', true, $s['adopted']);
check('SUG.effective_type_after_adopt', 'habit', $s['effective_type']);
check('SUG.adopted_active', 'active', $s['status']);

// Adopted-as-habit consolidates per the effective type's thresholds.
$adoptlog = [e(20260701, 'adopt', 0), e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260703, 'manual', 2)];
$s = engine::derive($adoptlog, $suggested, $fast);
check('SUG.adopted_consolidates', 'consolidated', $s['status']);

// ===========================================================================
// HABIT — consolidate -> on_consolidate (retire | promote | keep)
// ===========================================================================

$log3 = [e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260703, 'manual', 2)];

// Below threshold -> active (still forming).
$s = engine::derive([e(20260701, 'manual')], ['type' => 'habit', 'cadence' => 'daily'], $fast);
check('HABIT.active_forming', 'active', $s['status']);

// At the plateau -> consolidated; fires on_consolidate: retire.
$s = engine::derive($log3, ['type' => 'habit', 'cadence' => 'daily', 'on_consolidate' => 'retire'], $fast);
check('HABIT.consolidated', 'consolidated', $s['status']);
check('HABIT.on_consolidate_retire', 'retire', $s['on_consolidate']);

// on_consolidate: promote (into a rule).
$s = engine::derive($log3, ['type' => 'habit', 'cadence' => 'daily', 'on_consolidate' => 'promote'], $fast);
check('HABIT.on_consolidate_promote', 'promote', $s['on_consolidate']);

// Default (unset) on_consolidate is KEEP — never auto-retire an unformed habit.
$s = engine::derive($log3, ['type' => 'habit', 'cadence' => 'daily'], $fast);
check('HABIT.on_consolidate_default_keep', 'keep', $s['on_consolidate']);

// SPAN FLOOR (anti-cramming): 3 engaged days in ONE day's span does NOT consolidate.
// (Here all three ticks fall on the same localdate -> engaged_days 1 -> active.)
$sameday = [e(20260701, 'manual', 0), e(20260701, 'manual', 0), e(20260701, 'manual', 0)];
$s = engine::derive($sameday, ['type' => 'habit', 'cadence' => 'daily'], $fast);
check('HABIT.span_floor_blocks_cramming', 'active', $s['status']);
check('HABIT.span_floor_one_day', 1, $s['engaged_days']);

// ===========================================================================
// SEASON WINDOW — COMPLETES (never breaks) at completes_at; counts preserved
// ===========================================================================

$lenten = ['type' => 'habit', 'cadence' => 'daily', 'season' => ['window' => 'lent', 'completes_at' => 20260405]];
$seasonlog = [e(20260301, 'manual', 0), e(20260302, 'manual', 1)];

// Before Easter: normal active, streak intact.
$s = engine::derive($seasonlog, $lenten, ['as_of_date' => 20260301]);
check('SEASON.before_end_active', 'active', $s['status']);
check('SEASON.before_end_not_completed', false, $s['season_completed']);

// At/after the window end: the item COMPLETES (not breaks); counts stand.
$s = engine::derive($seasonlog, $lenten, ['as_of_date' => 20260406]);
check('SEASON.window_completes', 'completed', $s['status']);
check('SEASON.completed_flag', true, $s['season_completed']);
check('SEASON.counts_preserved', 2, $s['engaged_days']);
check('SEASON.streak_not_broken', 2, $s['streak']);

// ---- Report ----------------------------------------------------------------
$total = $GLOBALS['__pass'] + $GLOBALS['__fail'];
echo "\nlocal_practice FORMATION per-type lifecycle tests\n";
echo str_repeat('-', 48) . "\n";
if ($GLOBALS['__fail'] > 0) {
    echo implode("\n", $GLOBALS['__fails']) . "\n";
}
printf("%d/%d checks passed (%d failed)\n", $GLOBALS['__pass'], $total, $GLOBALS['__fail']);
exit($GLOBALS['__fail'] === 0 ? 0 : 1);
