<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Credit by examination — review mode.
 *
 * Phase 1: Show all learning points at "short" depth with checkboxes.
 * Phase 2: Generate quiz (2+ questions per ticked point) from quiz_items.
 * Phase 3: Show results — 80%+ per point = mastered.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');
require_once($CFG->dirroot . '/mod/depthcontent/lib.php');

$courseid = required_param('course', PARAM_INT);

$course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
require_course_login($course);
$context = context_course::instance($courseid);

$PAGE->set_context($context);
$PAGE->set_course($course);
$PAGE->set_url('/mod/depthcontent/review.php', ['course' => $courseid]);
$PAGE->set_title($course->shortname . ': ' . get_string('reviewmode', 'depthcontent'));
$PAGE->set_heading($course->fullname);
$PAGE->set_pagelayout('standard');
$PAGE->requires->css('/mod/depthcontent/styles.css');

$userid = $USER->id;

// Gather all depthcontent instances in this course with their course module ids.
$sql = "SELECT dc.id, dc.name, dc.pointid, dc.content_json, cm.id AS cmid
          FROM {depthcontent} dc
          JOIN {course_modules} cm ON cm.instance = dc.id
          JOIN {modules} m ON m.id = cm.module AND m.name = 'depthcontent'
         WHERE dc.course = :courseid
      ORDER BY dc.pointid ASC";
$points = $DB->get_records_sql($sql, ['courseid' => $courseid]);

// Build template data: each point with its short summary and available quiz items.
$pointsdata = [];
foreach ($points as $point) {
    $content = json_decode($point->content_json, true);
    if (!$content) {
        continue;
    }

    $depths = $content['depths'] ?? [];
    $quizitems = $content['quiz_items'] ?? [];

    // Must have quiz items to be examinable.
    if (empty($quizitems)) {
        continue;
    }

    // Get the short summary.
    $shortsummary = '';
    if (isset($depths['short']['summary'])) {
        $shortsummary = $depths['short']['summary'];
    } else if (isset($depths['short']['text'])) {
        $shortsummary = $depths['short']['text'];
    }

    // Check if already mastered via examination.
    $progress = $DB->get_record('depthcontent_progress', [
        'userid' => $userid,
        'depthcontentid' => $point->id,
    ]);
    $alreadymastered = ($progress && $progress->status === 'mastered'
        && $progress->mastered_via === 'examination');

    $pointsdata[] = [
        'id' => (int) $point->id,
        'cmid' => (int) $point->cmid,
        'pointid' => $point->pointid,
        'name' => $point->name,
        'shortsummary' => $shortsummary,
        'quizitems' => $quizitems,
        'quizcount' => count($quizitems),
        'alreadymastered' => $alreadymastered,
    ];
}

// Pass data to AMD module.
$PAGE->requires->js_call_amd('mod_depthcontent/review', 'init', [
    $courseid,
    $pointsdata,
]);

echo $OUTPUT->header();

// Render the review mode container — JS handles phases.
$templatedata = [
    'courseid' => $courseid,
    'points' => $pointsdata,
    'haspoints' => !empty($pointsdata),
    'dashboardurl' => (new moodle_url('/mod/depthcontent/dashboard.php', ['course' => $courseid]))->out(false),
    'selfassess' => get_string('selfassess', 'depthcontent'),
    'testme' => get_string('testme', 'depthcontent'),
    'reviewmode' => get_string('reviewmode', 'depthcontent'),
    'reviewmode_desc' => get_string('reviewmode_desc', 'depthcontent'),
    'noexaminablepoints' => get_string('noexaminablepoints', 'depthcontent'),
    'passed' => get_string('passed', 'depthcontent'),
    'failed' => get_string('failed', 'depthcontent'),
    'mastered' => get_string('mastered', 'depthcontent'),
];

echo $OUTPUT->render_from_template('mod_depthcontent/review', $templatedata);

echo $OUTPUT->footer();
