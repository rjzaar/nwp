<?php
/**
 * local_feedback\forwarder — sends accepted feedback to GitLab issues and
 * the AVC tester-guild logging endpoint.
 *
 * Both forwards are best-effort — failure is logged but does not fail the
 * user-facing submission. The DB is the source of truth.
 */
namespace local_feedback;

defined('MOODLE_INTERNAL') || die();

// The \curl class lives in /lib/filelib.php. Both submit.php (which loads
// filelib) and view.php (which doesn't) call our forwarder, so we
// require_once here defensively. No-op if already loaded.
global $CFG;
require_once($CFG->libdir . '/filelib.php');

class forwarder {

    /**
     * Forward a freshly-inserted feedback record to the configured
     * downstream endpoints. Updates the DB row with the results.
     *
     * @param \stdClass $record A populated local_feedback row (must have ->id).
     */
    public static function forward_submission(\stdClass $record): void {
        global $DB;

        $updates = [];

        // ── GitLab forward ───────────────────────────────────────────
        $gitlab_result = self::post_to_gitlab($record);
        if ($gitlab_result !== null) {
            $updates['gitlab_issue_url'] = $gitlab_result['web_url'] ?? null;
            $updates['gitlab_issue_iid'] = $gitlab_result['iid'] ?? null;
        }

        // ── AVC tester-guild log ─────────────────────────────────────
        $avc_ok = self::post_to_avc($record, 'submitted');
        if ($avc_ok) {
            $updates['avc_logged_at'] = time();
        }

        if ($updates) {
            $updates['id'] = $record->id;
            $updates['timemodified'] = time();
            $DB->update_record('local_feedback', (object)$updates);
        }
    }

    /**
     * Forward an approval/rejection event to AVC so the tester guild
     * scoring can credit the submitter.
     *
     * @param \stdClass $record  The local_feedback row.
     * @param int       $score   Points to credit on AVC (0 to clear).
     * @param string    $status  'approved' | 'rejected' | 'implemented'
     */
    public static function forward_review(\stdClass $record, int $score, string $status): void {
        global $DB;
        $ok = self::post_to_avc($record, $status, $score);
        if ($ok) {
            $DB->set_field('local_feedback', 'avc_score_awarded', $score, ['id' => $record->id]);
            $DB->set_field('local_feedback', 'avc_logged_at', time(), ['id' => $record->id]);
        }
    }

    /**
     * POST a feedback row to a GitLab project as a new issue.
     * Returns the GitLab API response array or null on failure / disabled.
     */
    private static function post_to_gitlab(\stdClass $record): ?array {
        $api  = trim((string)get_config('local_feedback', 'gitlab_url'));
        $proj = trim((string)get_config('local_feedback', 'gitlab_project'));
        $tok  = trim((string)get_config('local_feedback', 'gitlab_token'));
        if (!$api || !$proj || !$tok) {
            return null;
        }

        $url = rtrim($api, '/') . '/projects/' . urlencode($proj) . '/issues';

        // The GitLab project may need its path url-encoded (e.g. "nwp/courses" → "nwp%2Fcourses").
        // If the operator already encoded it in the settings, this rewrap is a no-op.

        $type_label = 'feedback::' . $record->type;
        $url_label = 'ss::' . preg_replace('/[^a-z0-9]+/i', '-', strtok($record->target_url ?? '', '?'));
        $url_label = trim($url_label, '-');

        $title = sprintf('[%s] %s', strtoupper($record->type), $record->title);
        $description = sprintf(
            "**Submitter:** %s (Moodle user id %d, %s)\n" .
            "**Source page:** %s\n" .
            "**Submitted at:** %s UTC\n" .
            "**SS feedback id:** %d\n\n" .
            "---\n\n%s",
            $record->username ?? 'unknown',
            (int)$record->userid,
            $record->email ?? '',
            $record->target_url ?? '(unknown)',
            gmdate('Y-m-d H:i:s', $record->timecreated),
            (int)$record->id,
            $record->body ?: '(no body provided)'
        );

        $payload = [
            'title'       => $title,
            'description' => $description,
            'labels'      => $type_label . ',' . $url_label . ',saint-school',
        ];

        $curl = new \curl();
        $curl->setHeader([
            'PRIVATE-TOKEN: ' . $tok,
            'Content-Type: application/json',
            'Accept: application/json',
        ]);
        $resp = $curl->post($url, json_encode($payload));
        $info = $curl->get_info();

        if (($info['http_code'] ?? 0) >= 200 && ($info['http_code'] ?? 0) < 300) {
            $decoded = json_decode($resp, true);
            return is_array($decoded) ? $decoded : null;
        }

        debugging('local_feedback GitLab POST failed: http=' . ($info['http_code'] ?? '?') . ' body=' . substr((string)$resp, 0, 500), DEBUG_DEVELOPER);
        return null;
    }

    /**
     * POST a feedback event to the AVC tester-guild log endpoint.
     * Returns true on HTTP 2xx, false otherwise.
     */
    private static function post_to_avc(\stdClass $record, string $status, ?int $score = null): bool {
        $url = trim((string)get_config('local_feedback', 'avc_url'));
        $tok = trim((string)get_config('local_feedback', 'avc_token'));
        if (!$url || !$tok) {
            return false;
        }

        // Try to enrich with the user's AVC OAuth identifier if available.
        $oauth_sub = self::oauth2_sub_for_user((int)$record->userid);

        $payload = [
            'ss_feedback_id'  => (int)$record->id,
            'ss_userid'       => (int)$record->userid,
            'username'        => $record->username,
            'email'           => $record->email,
            'oauth_sub'       => $oauth_sub,
            'type'            => $record->type,
            'title'           => $record->title,
            'body'            => $record->body,
            'target_url'      => $record->target_url,
            'status'          => $status,
            'score'           => $score,
            'timecreated'     => (int)$record->timecreated,
            'gitlab_issue_url'=> $record->gitlab_issue_url ?? null,
        ];

        $curl = new \curl();
        $curl->setHeader([
            // simple_oauth on the AVC side intercepts Authorization: Bearer
            // requests site-wide. Send X-Cross-Site-Token as the primary auth
            // header; AVC's CrossSiteFeedbackController prefers it over
            // Authorization. Keep Authorization for clients/middleboxes that
            // expect it; the controller's fallback is harmless.
            'X-Cross-Site-Token: ' . $tok,
            'Authorization: Bearer ' . $tok,
            'Content-Type: application/json',
            'Accept: application/json',
        ]);
        $resp = $curl->post($url, json_encode($payload));
        $info = $curl->get_info();

        $code = $info['http_code'] ?? 0;
        if ($code >= 200 && $code < 300) {
            return true;
        }

        debugging('local_feedback AVC POST failed: http=' . $code . ' body=' . substr((string)$resp, 0, 500), DEBUG_DEVELOPER);
        return false;
    }

    /**
     * Look up the user's auth_avc_oauth2 'sub' (subject) identifier if
     * they've signed in via AVC SSO. Used by AVC to map an SS feedback
     * submission back to the right AVC user account.
     */
    private static function oauth2_sub_for_user(int $userid): ?string {
        global $DB;
        if (!$userid) return null;
        // Convention: auth_avc_oauth2 stores the OAuth `sub` claim in
        // user_preferences under name 'auth_avc_oauth2_sub'.
        $val = $DB->get_field('user_preferences', 'value', [
            'userid' => $userid,
            'name'   => 'auth_avc_oauth2_sub',
        ]);
        return $val ?: null;
    }
}
