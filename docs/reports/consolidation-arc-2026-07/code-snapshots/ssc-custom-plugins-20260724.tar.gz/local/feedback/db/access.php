<?php
defined('MOODLE_INTERNAL') || die();

$capabilities = [
    // Anyone authenticated may submit (guest blocked by default).
    'local/feedback:submit' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'user'                => CAP_ALLOW,
            'editingteacher'      => CAP_ALLOW,
            'teacher'             => CAP_ALLOW,
            'manager'             => CAP_ALLOW,
        ],
    ],
    // Mentors of the Tester Guild can approve/reject and award score.
    'local/feedback:review' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'manager' => CAP_ALLOW,
        ],
    ],
    // View the community suggestion board (set to user; sites can lock down).
    'local/feedback:viewboard' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'user'    => CAP_ALLOW,
            'manager' => CAP_ALLOW,
        ],
    ],
];
