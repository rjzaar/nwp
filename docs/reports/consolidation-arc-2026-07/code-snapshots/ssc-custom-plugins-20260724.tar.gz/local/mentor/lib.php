<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Moodle adapters (the impure boundary) for local_mentor.
 *
 * The pure firewall logic lives in classes/mentor.php. This file is the thin DB
 * boundary. The LOAD-BEARING RULE lives here as much as in the pure class:
 *
 *   THE MENTOR READ PATH TOUCHES ONLY local_mentor_share.
 *   local_mentor_render_dashboard() reads local_mentor_relationship (to know the
 *   grant is active) and local_mentor_share (the pushed snapshots) — and NOTHING
 *   else. It NEVER queries local_practice_state, local_practice_log,
 *   local_practice_reflection, or any mod_depthcontent table. There is no code path
 *   from the mentor dashboard to live member state: accompaniment is push, not pull.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use local_mentor\mentor;

/**
 * Render one mentor's dashboard view of one mentee — the PUSH-ONLY read path.
 *
 * Reads ONLY the relationship row + this pair's pushed shares, then delegates to
 * the pure choke point mentor::assemble_mentor_view(). No live member state is ever
 * touched.
 *
 * @param int $mentorid
 * @param int $menteeid
 * @param int $asof YYYYMMDD "today" (expiry/renewal).
 * @return array the mentor-visible view (see mentor::assemble_mentor_view()).
 */
function local_mentor_render_dashboard(int $mentorid, int $menteeid, int $asof = 0): array {
    global $DB;

    $rel = $DB->get_record('local_mentor_relationship',
        ['mentorid' => $mentorid, 'menteeid' => $menteeid]);
    if (!$rel) {
        return ['access' => false];
    }
    $relationship = (array) $rel;
    $relationship['item_overrides'] = local_mentor_decode_overrides($rel->item_overrides ?? null);

    // The ONLY member-data read on the mentor side: the pushed snapshots. Never a
    // live pull of local_practice_state / the log / reflections / doctrine data.
    $shares = [];
    foreach ($DB->get_records('local_mentor_share',
            ['mentorid' => $mentorid, 'menteeid' => $menteeid], 'shared_on ASC') as $row) {
        $shares[] = [
            'menteeid'  => (int) $row->menteeid,
            'mentorid'  => (int) $row->mentorid,
            'tier'      => $row->tier,
            'shared_on' => (int) $row->shared_on,
            'payload'   => local_mentor_decode_payload($row->payload ?? null),
        ];
    }

    return mentor::assemble_mentor_view($relationship, $shares, $asof);
}

/**
 * PUSH a fresh coarse snapshot from the member to a companion. Builds the payload
 * via the pure builder (which strips every forbidden field), then stores it. This
 * is the ONLY writer to local_mentor_share, and it is member-initiated.
 *
 * @param int    $menteeid
 * @param int    $mentorid
 * @param array  $items member checkpoint entries (see mentor::build_share_payload).
 * @param int    $today YYYYMMDD.
 * @return int the new share id (0 if the grant is not active).
 */
function local_mentor_push_share(int $menteeid, int $mentorid, array $items, int $today): int {
    global $DB;

    $rel = $DB->get_record('local_mentor_relationship',
        ['mentorid' => $mentorid, 'menteeid' => $menteeid]);
    if (!$rel) {
        return 0;
    }
    $relationship = (array) $rel;
    if (!mentor::is_active($relationship, $today)) {
        return 0; // only an active grant can receive a push.
    }
    $overrides = local_mentor_decode_overrides($rel->item_overrides ?? null);
    $payload = mentor::build_share_payload($items, $rel->tier, $overrides, $today);

    return (int) $DB->insert_record('local_mentor_share', (object) [
        'menteeid'    => $menteeid,
        'mentorid'    => $mentorid,
        'tier'        => mentor::normalise_tier($rel->tier),
        'payload'     => json_encode($payload),
        'shared_on'   => $today,
        'timecreated' => time(),
    ]);
}

/**
 * REVOKE a grant instantly AND retroactively: end the relationship and PURGE every
 * pushed snapshot for the pair (DELETE — "nothing was ever copied").
 *
 * @param int    $menteeid
 * @param int    $mentorid
 * @param string $endedby member | mentor | expiry
 * @return bool
 */
function local_mentor_revoke(int $menteeid, int $mentorid, string $endedby = 'member'): bool {
    global $DB;

    $rel = $DB->get_record('local_mentor_relationship',
        ['mentorid' => $mentorid, 'menteeid' => $menteeid]);
    if ($rel) {
        $rel->status = mentor::STATUS_REVOKED;
        $rel->ended_by = $endedby;
        $rel->timemodified = time();
        $DB->update_record('local_mentor_relationship', $rel);
    }
    // Retroactive: delete the pushed snapshots outright.
    $DB->delete_records('local_mentor_share', ['menteeid' => $menteeid, 'mentorid' => $mentorid]);
    return true;
}

/**
 * Decode a stored JSON payload to an array (safe default []).
 *
 * @param string|null $json
 * @return array
 */
function local_mentor_decode_payload($json): array {
    if (!is_string($json) || $json === '') {
        return [];
    }
    $out = json_decode($json, true);
    return is_array($out) ? $out : [];
}

/**
 * Decode the stored per-item overrides JSON to a {uid => show|hide} map.
 *
 * @param string|null $json
 * @return array
 */
function local_mentor_decode_overrides($json): array {
    if (!is_string($json) || $json === '') {
        return [];
    }
    $out = json_decode($json, true);
    return is_array($out) ? mentor::normalise_overrides($out) : [];
}
