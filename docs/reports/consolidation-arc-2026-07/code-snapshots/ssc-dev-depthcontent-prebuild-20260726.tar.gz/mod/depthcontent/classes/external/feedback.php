<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External service endpoints for S13 feedback and lock-in.
 *
 * Three endpoints:
 *  - submit_level_a(fb_state_id, chosen_vote_key, why_text)
 *  - submit_level_b(fb_state_id, thumbs, teaching_verdict, why_text)
 *  - get_state(fb_state_id)
 *
 * Lock-in rules:
 *  - Level A: ≥ 3 distinct users picked the same candidate AND < 20 % of
 *    voters picked alternatives → status becomes 'locked'.
 *  - Level B: ≥ 5 thumbs_up AND thumbs_down_ratio ≤ 0.15 AND no verdict_no
 *    events at level C/D → status becomes 'locked'.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP / Sacred Sources (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace mod_depthcontent\external;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/externallib.php');

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;

/**
 * Feedback external service.
 */
class feedback extends external_api {

    /** Minimum Level A votes (distinct users) on the winning candidate. */
    const LEVEL_A_MIN_VOTES = 3;

    /** Maximum Level A alternative share to lock. */
    const LEVEL_A_MAX_ALT_RATIO = 0.20;

    /** Minimum Level B thumbs_up count to lock. */
    const LEVEL_B_MIN_THUMBS_UP = 5;

    /** Maximum Level B thumbs_down ratio to lock. */
    const LEVEL_B_MAX_DOWN_RATIO = 0.15;

    // ──────────────────────────────────────────────────────────────
    // Level A — candidate pick.
    // ──────────────────────────────────────────────────────────────

    /**
     * Level A parameter definition.
     *
     * @return external_function_parameters
     */
    public static function submit_level_a_parameters(): external_function_parameters {
        return new external_function_parameters([
            'fb_state_id'     => new external_value(PARAM_INT, 'Feedback state row id'),
            'chosen_vote_key' => new external_value(PARAM_TEXT, 'Candidate identifier chosen by the user'),
            'why_text'        => new external_value(PARAM_TEXT, 'Optional freeform "why" text', VALUE_DEFAULT, ''),
        ]);
    }

    /**
     * Level A execution.
     *
     * @param int $fbstateid
     * @param string $chosenvotekey
     * @param string $whytext
     * @return array
     */
    public static function submit_level_a(int $fbstateid, string $chosenvotekey, string $whytext = ''): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::submit_level_a_parameters(), [
            'fb_state_id'     => $fbstateid,
            'chosen_vote_key' => $chosenvotekey,
            'why_text'        => $whytext,
        ]);

        $state = self::load_state_or_throw((int) $params['fb_state_id']);
        self::validate_feedback_capability((int) $state->courseid);

        $now = time();

        // Append event.
        self::append_event((int) $state->id, $USER->id, 'a', [
            'chosen_vote_key' => $params['chosen_vote_key'],
            'why_text'        => $params['why_text'],
        ], $now);

        // Increment vote tally for chosen candidate.
        self::increment_vote((int) $state->id, (string) $params['chosen_vote_key'], $now);

        // Evaluate Level A lock-in.
        self::maybe_lock_level_a($state, (string) $params['chosen_vote_key'], $now);

        // Return fresh state.
        return self::build_state_payload((int) $state->id);
    }

    /**
     * Level A returns.
     *
     * @return external_single_structure
     */
    public static function submit_level_a_returns(): external_single_structure {
        return self::state_payload_structure();
    }

    // ──────────────────────────────────────────────────────────────
    // Level B — thumbs + teaching verdict.
    // ──────────────────────────────────────────────────────────────

    /**
     * Level B parameter definition.
     *
     * @return external_function_parameters
     */
    public static function submit_level_b_parameters(): external_function_parameters {
        return new external_function_parameters([
            'fb_state_id'       => new external_value(PARAM_INT, 'Feedback state row id'),
            'thumbs'            => new external_value(PARAM_ALPHA, '"up" or "down"'),
            'teaching_verdict'  => new external_value(PARAM_ALPHA, '"yes", "partially" or "no"'),
            'why_text'          => new external_value(PARAM_TEXT, 'Optional freeform "why" text', VALUE_DEFAULT, ''),
        ]);
    }

    /**
     * Level B execution.
     *
     * @param int $fbstateid
     * @param string $thumbs
     * @param string $teachingverdict
     * @param string $whytext
     * @return array
     */
    public static function submit_level_b(
        int $fbstateid,
        string $thumbs,
        string $teachingverdict,
        string $whytext = ''
    ): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::submit_level_b_parameters(), [
            'fb_state_id'      => $fbstateid,
            'thumbs'           => $thumbs,
            'teaching_verdict' => $teachingverdict,
            'why_text'         => $whytext,
        ]);

        $thumbs = strtolower((string) $params['thumbs']);
        $verdict = strtolower((string) $params['teaching_verdict']);
        if (!in_array($thumbs, ['up', 'down'], true)) {
            throw new \invalid_parameter_exception('thumbs must be "up" or "down"');
        }
        if (!in_array($verdict, ['yes', 'partially', 'no'], true)) {
            throw new \invalid_parameter_exception('teaching_verdict must be yes|partially|no');
        }

        $state = self::load_state_or_throw((int) $params['fb_state_id']);
        self::validate_feedback_capability((int) $state->courseid);

        $now = time();

        // Append event.
        self::append_event((int) $state->id, $USER->id, 'b', [
            'thumbs'           => $thumbs,
            'teaching_verdict' => $verdict,
            'why_text'         => $params['why_text'],
        ], $now);

        // Increment tallies.
        self::increment_vote((int) $state->id, 'thumbs_' . $thumbs, $now);
        self::increment_vote((int) $state->id, 'verdict_' . $verdict, $now);

        // Evaluate Level B lock-in.
        self::maybe_lock_level_b($state, $now);

        return self::build_state_payload((int) $state->id);
    }

    /**
     * Level B returns.
     *
     * @return external_single_structure
     */
    public static function submit_level_b_returns(): external_single_structure {
        return self::state_payload_structure();
    }

    // ──────────────────────────────────────────────────────────────
    // Get state.
    // ──────────────────────────────────────────────────────────────

    /**
     * Get state parameters.
     *
     * @return external_function_parameters
     */
    public static function get_state_parameters(): external_function_parameters {
        return new external_function_parameters([
            'fb_state_id' => new external_value(PARAM_INT, 'Feedback state row id'),
        ]);
    }

    /**
     * Return the current feedback state for a slot.
     *
     * @param int $fbstateid
     * @return array
     */
    public static function get_state(int $fbstateid): array {
        $params = self::validate_parameters(self::get_state_parameters(), [
            'fb_state_id' => $fbstateid,
        ]);

        $state = self::load_state_or_throw((int) $params['fb_state_id']);
        self::validate_feedback_capability((int) $state->courseid);

        return self::build_state_payload((int) $state->id);
    }

    /**
     * Get state returns.
     *
     * @return external_single_structure
     */
    public static function get_state_returns(): external_single_structure {
        return self::state_payload_structure();
    }

    // ──────────────────────────────────────────────────────────────
    // Internal helpers.
    // ──────────────────────────────────────────────────────────────

    /**
     * Load an fb_state row or throw.
     *
     * @param int $id
     * @return \stdClass
     */
    private static function load_state_or_throw(int $id): \stdClass {
        global $DB;
        $state = $DB->get_record('depthcontent_fb_state', ['id' => $id]);
        if (!$state) {
            throw new \invalid_parameter_exception('Unknown fb_state_id');
        }
        return $state;
    }

    /**
     * Validate course context and capability for the current user.
     *
     * @param int $courseid
     * @return void
     */
    private static function validate_feedback_capability(int $courseid): void {
        $context = \context_course::instance($courseid);
        self::validate_context($context);
        require_capability('mod/depthcontent:submitfeedback', $context);
    }

    /**
     * Append an event to the log.
     *
     * (ops#118) ART. 9 GATE — depthcontent_fb_events is a userid-keyed row that
     * links a NAMED member to a doctrine-level judgement about a specific
     * learning point, and mod_depthcontent's own core_privacy provider
     * classifies it as a LEDGER_TABLE alongside _mastery and _retrieval_log.
     * It is therefore special-category data and must obey the same fail-closed
     * write gate as every other formation write. A Trialing member's feedback
     * is NOT persisted; the aggregate vote tally (depthcontent_fb_votes, which
     * carries no userid) is unaffected, so content governance still works.
     *
     * @param int $fbstateid
     * @param int $userid
     * @param string $level
     * @param array $payload
     * @param int $now
     * @return int Row id, or 0 when the write was skipped for want of consent.
     */
    private static function append_event(int $fbstateid, int $userid, string $level, array $payload, int $now): int {
        global $DB;

        require_once($GLOBALS['CFG']->dirroot . '/mod/depthcontent/lib.php');
        if (!depthcontent_may_keep_formation($userid)) {
            return 0;
        }

        $event = new \stdClass();
        $event->userid = $userid;
        $event->fb_state_id = $fbstateid;
        $event->level = $level;
        $event->payload_json = json_encode($payload, JSON_UNESCAPED_UNICODE);
        $event->created_at = $now;
        return (int) $DB->insert_record('depthcontent_fb_events', $event);
    }

    /**
     * Increment (or create) a vote tally row.
     *
     * @param int $fbstateid
     * @param string $votekey
     * @param int $now
     * @return void
     */
    private static function increment_vote(int $fbstateid, string $votekey, int $now): void {
        global $DB;

        $existing = $DB->get_record('depthcontent_fb_votes', [
            'fb_state_id' => $fbstateid,
            'vote_key'    => $votekey,
        ]);

        if ($existing) {
            $existing->count = ((int) $existing->count) + 1;
            $existing->updated_at = $now;
            $DB->update_record('depthcontent_fb_votes', $existing);
        } else {
            $record = new \stdClass();
            $record->fb_state_id = $fbstateid;
            $record->vote_key = $votekey;
            $record->count = 1;
            $record->updated_at = $now;
            $DB->insert_record('depthcontent_fb_votes', $record);
        }
    }

    /**
     * Evaluate Level A lock-in rule.
     *
     * Rule: ≥ 3 distinct users picked the same candidate (chosen_vote_key)
     * AND alternatives received < 20 % of the vote.
     *
     * @param \stdClass $state
     * @param string $chosenkey
     * @param int $now
     * @return void
     */
    private static function maybe_lock_level_a(\stdClass $state, string $chosenkey, int $now): void {
        global $DB;

        if ($state->status === 'locked') {
            return;
        }

        // Distinct users who voted for $chosenkey at level A.
        $sql = "SELECT COUNT(DISTINCT userid) AS cnt
                  FROM {depthcontent_fb_events}
                 WHERE fb_state_id = :sid
                   AND level = 'a'
                   AND " . $DB->sql_like('payload_json', ':pattern');
        $pattern = '%"chosen_vote_key":"' . $chosenkey . '"%';
        $distinct = (int) $DB->get_field_sql($sql, ['sid' => $state->id, 'pattern' => $pattern]);

        if ($distinct < self::LEVEL_A_MIN_VOTES) {
            return;
        }

        // Totals: vote for chosen vs alternatives.
        $votes = $DB->get_records('depthcontent_fb_votes', ['fb_state_id' => $state->id]);
        $chosenvotes = 0;
        $altvotes = 0;

        // Identify alternative vote_keys from candidates_json if present.
        $candidatekeys = self::extract_candidate_keys($state);

        foreach ($votes as $v) {
            if ($v->vote_key === $chosenkey) {
                $chosenvotes = (int) $v->count;
            } else if (!empty($candidatekeys) && in_array($v->vote_key, $candidatekeys, true)) {
                $altvotes += (int) $v->count;
            }
        }

        $total = $chosenvotes + $altvotes;
        if ($total <= 0) {
            return;
        }
        $altratio = $altvotes / $total;
        if ($altratio >= self::LEVEL_A_MAX_ALT_RATIO) {
            return;
        }

        // Lock.
        self::lock_state($state, 'auto_level_a', $chosenkey, $now);
    }

    /**
     * Evaluate Level B lock-in rule.
     *
     * Rule: ≥ 5 thumbs_up, thumbs_down_ratio ≤ 0.15, no C/D verdict_no.
     *
     * @param \stdClass $state
     * @param int $now
     * @return void
     */
    private static function maybe_lock_level_b(\stdClass $state, int $now): void {
        global $DB;

        if ($state->status === 'locked') {
            return;
        }

        $up = (int) $DB->get_field('depthcontent_fb_votes', 'count', [
            'fb_state_id' => $state->id,
            'vote_key'    => 'thumbs_up',
        ]);
        $down = (int) $DB->get_field('depthcontent_fb_votes', 'count', [
            'fb_state_id' => $state->id,
            'vote_key'    => 'thumbs_down',
        ]);

        if ($up < self::LEVEL_B_MIN_THUMBS_UP) {
            return;
        }
        $total = $up + $down;
        if ($total <= 0) {
            return;
        }
        if (($down / $total) > self::LEVEL_B_MAX_DOWN_RATIO) {
            return;
        }

        // Check for any C/D event with a "no" verdict.
        $sql = "SELECT COUNT(1)
                  FROM {depthcontent_fb_events}
                 WHERE fb_state_id = :sid
                   AND level IN ('c', 'd')
                   AND " . $DB->sql_like('payload_json', ':pattern');
        $veto = (int) $DB->count_records_sql($sql, [
            'sid'     => $state->id,
            'pattern' => '%"verdict":"no"%',
        ]);
        if ($veto > 0) {
            return;
        }

        self::lock_state($state, 'auto_level_b', null, $now);
    }

    /**
     * Mark a state as locked.
     *
     * @param \stdClass $state
     * @param string $lockedby
     * @param string|null $chosenkey Optional — when locking via Level A, record which candidate won.
     * @param int $now
     * @return void
     */
    private static function lock_state(\stdClass $state, string $lockedby, ?string $chosenkey, int $now): void {
        global $DB;

        $state->status = 'locked';
        $state->locked_by = $lockedby;
        $state->locked_at = $now;
        $state->updated_at = $now;

        // When level A locks and we know which candidate won, promote it into current_clip_json.
        if ($chosenkey !== null) {
            $candidates = [];
            if (!empty($state->candidates_json)) {
                $decoded = json_decode($state->candidates_json, true);
                if (is_array($decoded)) {
                    $candidates = $decoded;
                }
            }
            foreach ($candidates as $cand) {
                $candkey = $cand['vote_key'] ?? ($cand['id'] ?? null);
                if ($candkey === $chosenkey) {
                    $state->current_clip_json = json_encode($cand, JSON_UNESCAPED_UNICODE);
                    break;
                }
            }
        }

        $DB->update_record('depthcontent_fb_state', $state);
    }

    /**
     * Extract candidate vote_keys from the candidates_json blob.
     *
     * @param \stdClass $state
     * @return string[]
     */
    private static function extract_candidate_keys(\stdClass $state): array {
        $keys = [];
        if (empty($state->candidates_json)) {
            return $keys;
        }
        $decoded = json_decode($state->candidates_json, true);
        if (!is_array($decoded)) {
            return $keys;
        }
        foreach ($decoded as $cand) {
            if (isset($cand['vote_key'])) {
                $keys[] = (string) $cand['vote_key'];
            } else if (isset($cand['id'])) {
                $keys[] = (string) $cand['id'];
            }
        }
        return $keys;
    }

    /**
     * Build the state payload returned to callers.
     *
     * @param int $stateid
     * @return array
     */
    private static function build_state_payload(int $stateid): array {
        global $DB;

        $state = $DB->get_record('depthcontent_fb_state', ['id' => $stateid], '*', MUST_EXIST);

        $currentclip = [];
        if (!empty($state->current_clip_json)) {
            $decoded = json_decode($state->current_clip_json, true);
            if (is_array($decoded)) {
                $currentclip = $decoded;
            }
        }

        $candidates = [];
        if (!empty($state->candidates_json)) {
            $decoded = json_decode($state->candidates_json, true);
            if (is_array($decoded)) {
                $candidates = $decoded;
            }
        }

        $votes = $DB->get_records('depthcontent_fb_votes', ['fb_state_id' => $state->id]);
        $votepayload = [];
        foreach ($votes as $v) {
            $votepayload[] = [
                'vote_key' => (string) $v->vote_key,
                'count'    => (int) $v->count,
            ];
        }

        return [
            'fb_state_id'  => (int) $state->id,
            'status'       => (string) $state->status,
            'current_clip' => json_encode($currentclip, JSON_UNESCAPED_UNICODE),
            'candidates'   => json_encode($candidates, JSON_UNESCAPED_UNICODE),
            'votes'        => $votepayload,
            'locked_by'    => $state->locked_by !== null ? (string) $state->locked_by : '',
            'locked_at'    => (int) ($state->locked_at ?? 0),
            'updated_at'   => (int) $state->updated_at,
        ];
    }

    /**
     * The response structure shared by all three endpoints.
     *
     * @return external_single_structure
     */
    private static function state_payload_structure(): external_single_structure {
        return new external_single_structure([
            'fb_state_id'  => new external_value(PARAM_INT, 'Feedback state row id'),
            'status'       => new external_value(PARAM_ALPHA, 'locked|candidates|open'),
            'current_clip' => new external_value(PARAM_RAW, 'JSON-encoded current clip'),
            'candidates'   => new external_value(PARAM_RAW, 'JSON-encoded candidates array'),
            'votes'        => new external_multiple_structure(
                new external_single_structure([
                    'vote_key' => new external_value(PARAM_TEXT, 'Vote key'),
                    'count'    => new external_value(PARAM_INT, 'Vote count'),
                ])
            ),
            'locked_by'    => new external_value(PARAM_TEXT, 'Who/what locked the slot'),
            'locked_at'    => new external_value(PARAM_INT, 'Unix ts of lock'),
            'updated_at'   => new external_value(PARAM_INT, 'Unix ts of last update'),
        ]);
    }
}
