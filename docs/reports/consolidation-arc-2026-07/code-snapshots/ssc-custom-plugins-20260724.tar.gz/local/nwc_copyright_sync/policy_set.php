<?php
/**
 * POST endpoint for NWC's nwc_copyright module to publish a new
 * tool_policy version on this Moodle.
 *
 * Auth: Authorization: Bearer <local_nwc_copyright_sync/admin_token>
 * Body: JSON
 *   {
 *     "policy_name": "site_terms" | "privacy_policy" | "aup" | "copyright_notice",
 *     "title":       "Site Terms of Use",
 *     "type":        "site" | "privacy" | "third_party" | "other",  // optional
 *     "version":     <int>,
 *     "effective_date": "2026-05-17" | null,
 *     "change_summary": "...",
 *     "body_md":     "..."
 *   }
 *
 * Response:
 *   200 {"ok": true, "ss_version_id": <int>}
 *   401 {"ok": false, "error": "unauthorized"}
 *   400 {"ok": false, "error": "...", "details": ...}
 *   500 {"ok": false, "error": "server error"}
 *
 * Intentionally NOT a Moodle web service — we want a plain HTTPS POST
 * with Bearer auth, same shape as NWC's CrossSiteFeedbackController.
 */

define('AJAX_SCRIPT', true);
define('NO_MOODLE_COOKIES', true);

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/clilib.php');
require_once(__DIR__ . '/classes/policy_writer.php');

header('Content-Type: application/json; charset=utf-8');

function respond_json(int $status, array $payload): never {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_json(405, ['ok' => false, 'error' => 'POST required']);
}

if (!get_config('local_nwc_copyright_sync', 'enabled')) {
    respond_json(503, ['ok' => false, 'error' => 'sync disabled on this site']);
}

// IP allowlist (optional).
$allowed_ips_raw = (string) get_config('local_nwc_copyright_sync', 'allowed_ips');
if ($allowed_ips_raw !== '') {
    $allowed = array_filter(array_map('trim', explode(',', $allowed_ips_raw)));
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!in_array($remote, $allowed, true)) {
        respond_json(403, ['ok' => false, 'error' => 'source IP not allowed']);
    }
}

// Bearer auth.
$expected = (string) get_config('local_nwc_copyright_sync', 'admin_token');
$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!$expected || strpos($auth, 'Bearer ') !== 0) {
    respond_json(401, ['ok' => false, 'error' => 'unauthorized']);
}
$provided = substr($auth, strlen('Bearer '));
if (!hash_equals($expected, $provided)) {
    respond_json(401, ['ok' => false, 'error' => 'unauthorized']);
}

// Parse JSON body.
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
    respond_json(400, ['ok' => false, 'error' => 'invalid json']);
}

// Validate.
$errors = [];
$required = ['policy_name', 'title', 'version', 'body_md'];
foreach ($required as $f) {
    if (!array_key_exists($f, $body)) {
        $errors[] = "missing: $f";
    }
}
$allowed_policy_names = ['site_terms', 'privacy_policy', 'aup', 'copyright_notice', 'beta_cc0'];
if (isset($body['policy_name']) && !in_array($body['policy_name'], $allowed_policy_names, true)) {
    $errors[] = 'invalid policy_name (allowed: ' . implode(', ', $allowed_policy_names) . ')';
}
if (!empty($errors)) {
    respond_json(400, ['ok' => false, 'error' => 'bad payload', 'details' => $errors]);
}

try {
    $policy_type_map = [
        'site_terms'        => 'site',
        'privacy_policy'    => 'privacy',
        'aup'               => 'other',
        'copyright_notice'  => 'other',
        'beta_cc0'          => 'other',
    ];
    $type = $body['type'] ?? ($policy_type_map[$body['policy_name']] ?? 'other');

    $result = \local_nwc_copyright_sync\policy_writer::publish(
        $body['policy_name'],
        $body['title'],
        $type,
        $body['body_md'],
        $body['effective_date'] ?? null,
        $body['change_summary'] ?? null,
    );

    respond_json(200, $result);
}
catch (\Throwable $e) {
    error_log('local_nwc_copyright_sync policy_set: ' . $e->getMessage());
    respond_json(500, ['ok' => false, 'error' => 'server error', 'detail' => $e->getMessage()]);
}
