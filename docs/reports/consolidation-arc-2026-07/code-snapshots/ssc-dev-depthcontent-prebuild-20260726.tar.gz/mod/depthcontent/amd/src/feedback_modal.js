/**
 * S13 feedback modal for mod_depthcontent.
 *
 * Wires "Help improve this" buttons to open a modal containing either
 * the Level A candidate picker or the Level B thumbs/verdict form, based
 * on the state carried on the button's data attributes. Submissions go
 * via core/ajax to the mod_depthcontent_feedback_submit_level_{a,b}
 * external services.
 *
 * @module     mod_depthcontent/feedback_modal
 * @copyright  2026 NWP / Sacred Sources (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define([
    'jquery',
    'core/ajax',
    'core/notification',
    'core/str',
    'core/modal_factory',
    'core/modal_events',
    'core/templates'
], function($, Ajax, Notification, Str, ModalFactory, ModalEvents, Templates) {

    /**
     * Safely JSON-decode a string, returning a fallback on failure.
     *
     * @param {string} raw
     * @param {*} fallback
     * @return {*}
     */
    function safeParse(raw, fallback) {
        if (!raw) {
            return fallback;
        }
        try {
            return JSON.parse(raw);
        } catch (e) {
            return fallback;
        }
    }

    /**
     * Render the modal body for a given state.
     *
     * @param {Object} ctx Context: { mode: 'candidates'|'basic', ...data }
     * @return {Promise<string>}
     */
    function renderBody(ctx) {
        return Templates.render('mod_depthcontent/feedback_modal', ctx);
    }

    /**
     * Build the template context from a button's data attributes.
     *
     * @param {jQuery} $btn
     * @return {Object}
     */
    function buildContextFromButton($btn) {
        var fbStateId = parseInt($btn.attr('data-fb-state-id'), 10);
        var status = $btn.attr('data-fb-status') || 'open';
        var candidates = safeParse($btn.attr('data-fb-candidates'), []);
        var currentClip = safeParse($btn.attr('data-fb-current-clip'), {});

        var ctx = {
            fb_state_id: fbStateId,
            status: status,
            candidates: null,
            basic: null
        };

        if (status === 'candidates' && candidates.length > 0) {
            ctx.candidates = candidates.map(function(c, idx) {
                return {
                    idx: idx,
                    vote_key: c.vote_key || c.id || ('candidate_' + idx),
                    title: c.title || ('Candidate ' + (idx + 1)),
                    video_url: c.video_url || '',
                    notes: c.analyser_notes || '',
                    slot_fit: (typeof c.slot_fit_consensus === 'number')
                        ? c.slot_fit_consensus.toFixed(2) : ''
                };
            });
        } else {
            ctx.basic = {
                current_title: currentClip.title || '',
                current_video_url: currentClip.video_url || ''
            };
        }

        return ctx;
    }

    /**
     * Read the selected Level A inputs from the modal.
     *
     * @param {jQuery} $body
     * @return {Object|null}
     */
    function readLevelASelection($body) {
        var $chosen = $body.find('input[name="dc-fb-candidate"]:checked');
        if ($chosen.length === 0) {
            return null;
        }
        return {
            chosen_vote_key: $chosen.val(),
            why_text: ($body.find('.dc-fb-why').val() || '').toString()
        };
    }

    /**
     * Read the Level B inputs from the modal.
     *
     * @param {jQuery} $body
     * @return {Object|null}
     */
    function readLevelBSelection($body) {
        var $thumbs = $body.find('input[name="dc-fb-thumbs"]:checked');
        var $verdict = $body.find('input[name="dc-fb-verdict"]:checked');
        if ($thumbs.length === 0 || $verdict.length === 0) {
            return null;
        }
        return {
            thumbs: $thumbs.val(),
            teaching_verdict: $verdict.val(),
            why_text: ($body.find('.dc-fb-why').val() || '').toString()
        };
    }

    /**
     * Submit Level A via webservice.
     *
     * @param {number} fbStateId
     * @param {Object} payload
     * @return {Promise}
     */
    function submitLevelA(fbStateId, payload) {
        return Ajax.call([{
            methodname: 'mod_depthcontent_feedback_submit_level_a',
            args: {
                fb_state_id: fbStateId,
                chosen_vote_key: payload.chosen_vote_key,
                why_text: payload.why_text
            }
        }])[0];
    }

    /**
     * Submit Level B via webservice.
     *
     * @param {number} fbStateId
     * @param {Object} payload
     * @return {Promise}
     */
    function submitLevelB(fbStateId, payload) {
        return Ajax.call([{
            methodname: 'mod_depthcontent_feedback_submit_level_b',
            args: {
                fb_state_id: fbStateId,
                thumbs: payload.thumbs,
                teaching_verdict: payload.teaching_verdict,
                why_text: payload.why_text
            }
        }])[0];
    }

    /**
     * Show a transient "thanks" message near a button.
     *
     * @param {jQuery} $btn
     * @param {string} text
     */
    function showThanks($btn, text) {
        var $wrap = $btn.parent();
        var $existing = $wrap.find('.dc-fb-toast');
        if ($existing.length === 0) {
            $existing = $('<span class="dc-fb-toast"></span>').appendTo($wrap);
        }
        $existing.text(text).show();
        setTimeout(function() {
            $existing.fadeOut(300);
        }, 2500);
    }

    /**
     * Refresh the button's data attributes and label after a submission.
     *
     * @param {jQuery} $btn
     * @param {Object} freshState
     * @param {Object} strings
     */
    function refreshButton($btn, freshState, strings) {
        $btn.attr('data-fb-status', freshState.status);
        $btn.attr('data-fb-current-clip', freshState.current_clip || '');
        $btn.attr('data-fb-candidates', freshState.candidates || '');

        if (freshState.status === 'locked') {
            $btn.text(strings.report_problem);
            $btn.addClass('dc-fb-btn-locked');
        }
    }

    /**
     * Open the modal for a given button.
     *
     * @param {jQuery} $btn
     * @param {Object} strings
     */
    function openModalForButton($btn, strings) {
        var ctx = buildContextFromButton($btn);
        var fbStateId = ctx.fb_state_id;
        var mode = (ctx.status === 'candidates') ? 'a' : 'b';
        var title = (mode === 'a') ? strings.level_a_title : strings.level_b_title;

        ModalFactory.create({
            type: ModalFactory.types.SAVE_CANCEL,
            title: title,
            body: renderBody(ctx)
        }).then(function(modal) {
            modal.setSaveButtonText(strings.submit);
            modal.getRoot().on(ModalEvents.save, function(e) {
                e.preventDefault();
                var $body = modal.getBody();
                var payload;
                var promise;

                if (mode === 'a') {
                    payload = readLevelASelection($body);
                    if (!payload) {
                        return;
                    }
                    promise = submitLevelA(fbStateId, payload);
                } else {
                    payload = readLevelBSelection($body);
                    if (!payload) {
                        return;
                    }
                    promise = submitLevelB(fbStateId, payload);
                }

                promise.then(function(freshState) {
                    refreshButton($btn, freshState, strings);
                    modal.hide();
                    showThanks($btn, strings.thanks);
                    return freshState;
                }).catch(Notification.exception);
            });

            modal.getRoot().on(ModalEvents.hidden, function() {
                modal.destroy();
            });

            modal.show();
            return modal;
        }).catch(Notification.exception);
    }

    return {
        /**
         * Initialise handlers.
         *
         * @param {string} selector Root selector for "Help improve this" buttons.
         */
        init: function(selector) {
            var rootSelector = selector || '.dc-fb-btn';

            // Pre-load i18n strings.
            Str.get_strings([
                { key: 'feedback:level_a_title', component: 'mod_depthcontent' },
                { key: 'feedback:level_b_title', component: 'mod_depthcontent' },
                { key: 'feedback:submit',        component: 'mod_depthcontent' },
                { key: 'feedback:thanks',        component: 'mod_depthcontent' },
                { key: 'feedback:report_problem', component: 'mod_depthcontent' }
            ]).then(function(s) {
                var strings = {
                    level_a_title:   s[0],
                    level_b_title:   s[1],
                    submit:          s[2],
                    thanks:          s[3],
                    report_problem:  s[4]
                };

                $(document).on('click', rootSelector, function(ev) {
                    ev.preventDefault();
                    var $btn = $(this);

                    // Level D flagging (locked + report-problem) goes to Phase 3.
                    // For Phase 2, we only open the modal on candidates|open.
                    var status = $btn.attr('data-fb-status') || 'open';
                    if (status === 'locked') {
                        // Placeholder: Phase 3 Level D modal.
                        showThanks($btn, strings.report_problem);
                        return;
                    }

                    openModalForButton($btn, strings);
                });

                return strings;
            }).catch(Notification.exception);
        }
    };
});
