<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for local_practice.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade the local_practice plugin.
 *
 * @param int $oldversion the version we are upgrading from
 * @return bool
 */
function xmldb_local_practice_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    // v3.3 (2026-07-20): the 6-type FORMATION checkpoint model. Additive columns
    // on local_practice_def (challenge/rule/suggested + cadence + gateway link +
    // season window) and local_practice_state (adoption + consolidation markers).
    // Member tables stay FK-free (GDPR). Upgrade-safe: all new columns are
    // NULLable or carry a DEFAULT, so existing rows migrate untouched.
    if ($oldversion < 2026072001) {
        $deffields = [
            new xmldb_field('cadence', XMLDB_TYPE_CHAR, '16', null, XMLDB_NOTNULL, null, 'once', 'pacing'),
            new xmldb_field('adopts_as', XMLDB_TYPE_CHAR, '16', null, null, null, null, 'cadence'),
            new xmldb_field('on_consolidate', XMLDB_TYPE_CHAR, '16', null, null, null, null, 'adopts_as'),
            new xmldb_field('contributes_to', XMLDB_TYPE_CHAR, '64', null, null, null, null, 'on_consolidate'),
            new xmldb_field('review_after_days', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'contributes_to'),
            new xmldb_field('season_window', XMLDB_TYPE_CHAR, '32', null, null, null, null, 'review_after_days'),
            new xmldb_field('season_completes_at', XMLDB_TYPE_CHAR, '32', null, null, null, null, 'season_window'),
            new xmldb_field('condition_text', XMLDB_TYPE_CHAR, '255', null, null, null, null, 'season_completes_at'),
        ];
        $deftable = new xmldb_table('local_practice_def');
        foreach ($deffields as $field) {
            if (!$dbman->field_exists($deftable, $field)) {
                $dbman->add_field($deftable, $field);
            }
        }

        $statefields = [
            new xmldb_field('first_engaged_date', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'last_engaged_date'),
            new xmldb_field('adopted_at', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'first_engaged_date'),
            new xmldb_field('adopted_as', XMLDB_TYPE_CHAR, '16', null, null, null, null, 'adopted_at'),
            new xmldb_field('consolidated_at', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'adopted_as'),
            new xmldb_field('retired_by_member', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'consolidated_at'),
        ];
        $statetable = new xmldb_table('local_practice_state');
        foreach ($statefields as $field) {
            if (!$dbman->field_exists($statetable, $field)) {
                $dbman->add_field($statetable, $field);
            }
        }

        upgrade_plugin_savepoint(true, 2026072001, 'local', 'practice');
    }

    // v3.4 (2026-07-20): the progression-visibility DISPLAY layer (N9 build #4/#6).
    // Adds one additive, NULLable member column: anchor_plan (the if-then
    // implementation intention captured at adoption). The 3-mode progression_view
    // is a Moodle user preference (no schema). Member table stays FK-free (GDPR);
    // upgrade-safe (the column is NULLable, existing rows migrate untouched).
    if ($oldversion < 2026072002) {
        $statetable = new xmldb_table('local_practice_state');
        $anchor = new xmldb_field('anchor_plan', XMLDB_TYPE_CHAR, '255', null, null, null, null, 'retired_by_member');
        if (!$dbman->field_exists($statetable, $anchor)) {
            $dbman->add_field($statetable, $anchor);
        }
        upgrade_plugin_savepoint(true, 2026072002, 'local', 'practice');
    }

    return true;
}
