# local_feedback — Saint School floating feedback widget

A Moodle local plugin that renders a green circular **feedback button** in the
bottom-right corner of every page. Click → popup form with Suggestion /
Question / Issue / Praise + title + body + submit. Mirrors the
`nwc_feedback` Drupal module's UX on the NWC side.

## What it does

1. **Renders** the floating button + popup on every page via Moodle 4.4+
   hook callbacks (`before_standard_head_html_generation` for CSS,
   `before_footer_html_generation` for HTML).
2. **Persists** every submission to the `local_feedback` DB table.
3. **Forwards** (if configured) to GitLab as a new issue in `nwp/courses`.
4. **Logs** (if configured) to the NWC Tester Guild endpoint so a
   mentor's approval credits the submitter with score points on NWC.

## File map

```
local/feedback/
├── version.php                       Moodle plugin metadata
├── lib.php                            Empty (kept for Moodle convention)
├── settings.php                       Admin → Plugins → Local plugins → Feedback widget
├── styles.css                         Widget styles (loaded via head hook)
├── submit.php                         AJAX endpoint the widget POSTs to
├── index.php                          Admin/mentor list of all submissions
├── view.php                           Single-submission view + approve/reject form
├── README.md                          This file
├── db/
│   ├── install.xml                    `local_feedback` + `local_feedback_vote` tables
│   ├── access.php                     `submit`, `review`, `viewboard` capabilities
│   └── hooks.php                      Registers the two Moodle 4.4 hook callbacks
├── lang/en/local_feedback.php         Language strings
├── amd/src/widget.js                  Floating button + popup (AMD module)
├── pix/                               (icon, currently empty)
└── classes/
    ├── hook_callbacks.php             before_head + before_footer
    └── forwarder.php                  POSTs to GitLab + NWC (or legacy AVC) log endpoint
```

## DB schema (`local_feedback` table, 20 columns)

| Column | Purpose |
|--------|---------|
| `id` | primary key |
| `type` | `suggestion` / `question` / `issue` / `praise` |
| `title`, `body` | what the user typed |
| `target_url` | page the user was on |
| `userid`, `username`, `email` | submitter identity |
| `user_agent`, `ipaddress` | submission context |
| `status` | `pending` / `approved` / `rejected` / `implemented` / `duplicate` |
| `reviewer_userid`, `reviewer_comment`, `reviewed_at` | mentor review |
| `gitlab_issue_url`, `gitlab_issue_iid` | GitLab forward result |
| `avc_logged_at`, `avc_score_awarded` | NWC log + Trialing Guild score (legacy AVC also supported) |
| `timecreated`, `timemodified` | timestamps |

Plus `local_feedback_vote` table for community upvotes.

## Capabilities

| Capability | Default | What it gates |
|-----------|---------|---------------|
| `local/feedback:submit` | authenticated users | Whether the widget is rendered on the page; whether submit.php accepts a POST |
| `local/feedback:review` | manager role | Whether the user sees approve/reject buttons in view.php and gets all submissions in index.php |
| `local/feedback:viewboard` | guest + all | Whether index.php is accessible |

## Configuration (Site admin → Plugins → Local plugins → Feedback widget)

| Setting | Default | Purpose |
|--------|---------|---------|
| `enabled` | yes | Render the widget on every page |
| `logged_in_only` | no | If yes, anonymous visitors don't see the widget |
| `gitlab_url` | (empty) | e.g. `https://git.nwpcode.org/api/v4` |
| `gitlab_project` | (empty) | e.g. `nwp%2Fcourses` |
| `gitlab_token` | (empty) | Personal access token with `api` scope |
| `avc_url` | (empty) | e.g. `https://nwc.nwpcode.org/api/feedback/log` |
| `avc_token` | (empty) | Bearer token for the NWC endpoint |
| `avc_score_default` | 10 | Points awarded on approval (implementation gets 1.5×) |

## Cross-site contract: SS → NWC

When `avc_url` is set, every submission and every mentor review POSTs JSON to
the NWC endpoint:

**POST** `https://nwc.nwpcode.org/api/feedback/log`
**Headers:** `Authorization: Bearer <avc_token>`, `Content-Type: application/json`

```json
{
  "ss_feedback_id": 42,
  "ss_userid": 17,
  "username": "Rob Zaar",
  "email": "rjzaar@gmail.com",
  "oauth_sub": "abc123...",      // OAuth `sub` claim from auth_nwc_oauth2 (nullable)
  "type": "suggestion",
  "title": "Better progress markers on the J series",
  "body": "...",
  "target_url": "/course/view.php?id=47",
  "status": "submitted",          // or "approved" / "rejected" / "implemented"
  "score": null,                  // null on submission; integer on review
  "timecreated": 1715900000,
  "gitlab_issue_url": "https://git.nwpcode.org/nwp/courses/-/issues/123"
}
```

**NWC-side expected behaviour** (to be built in nwc_feedback or a sibling
Drupal module):

1. **On submission** (`status=submitted`): create a `feedback_log` row
   on NWC, linked to the submitter via `oauth_sub` → NWC user mapping.
2. **On approval/implementation** (`status=approved|implemented`,
   `score>0`): credit the user with `score` points on their Tester
   Guild scoring record. (Bonus for `implemented` is already baked into
   the score value the SS side sends — 1.5×.)
3. **On rejection** (`status=rejected`): no score; just log.

## Testing

1. Open https://ss-dev.ddev.site/ in a browser; the green floating button
   should be in the bottom-right corner.
2. Click → popup; fill in title; submit; see "Thank you" toast.
3. Open https://ss-dev.ddev.site/local/feedback/index.php (admin or mentor
   role); see the submission listed.
4. Click into a submission → review form. Approve/reject. The score field
   defaults to 10 (or whatever `avc_score_default` is set to).

## Preservation

This plugin lives at `~/dir/courses_v3/plugins/local/feedback/` (canonical).
The Saint School v3 install pipeline (`~/dir/courses_v3/build/install_plugins.sh`)
copies it into any target Moodle install. Adding new fields or features:

1. Edit files here at the canonical location
2. Bump `version.php` `$plugin->version` (and `manifest.yaml` accordingly)
3. If you added DB schema, also write a `db/upgrade.php`
4. Run `~/dir/courses_v3/build/install_plugins.sh <target-moodle> --via-ddev`
5. `verify_plugins.sh` catches drift
