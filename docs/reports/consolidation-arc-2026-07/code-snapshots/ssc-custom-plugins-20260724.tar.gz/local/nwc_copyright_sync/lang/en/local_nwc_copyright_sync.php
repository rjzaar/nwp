<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'NWC Copyright Sync';
$string['setting_enabled'] = 'Enable NWC → SS sync';
$string['setting_enabled_desc'] = 'When enabled, accept POSTs from NWC on /local/nwc_copyright_sync/policy_set.php and publish new tool_policy revisions accordingly.';
$string['setting_admin_token'] = 'Shared bearer token';
$string['setting_admin_token_desc'] = 'Bearer token required in the Authorization header. Must match the value configured at NWC (nwc_copyright.settings:moodle:admin_token).';
$string['setting_allowed_ips'] = 'Allowed source IPs (optional)';
$string['setting_allowed_ips_desc'] = 'Comma-separated list. If set, requests from any other IP are rejected.';
