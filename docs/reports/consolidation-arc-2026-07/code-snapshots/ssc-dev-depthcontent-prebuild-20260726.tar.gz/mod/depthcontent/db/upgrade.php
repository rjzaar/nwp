<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for mod_depthcontent.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP / Sacred Sources (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Execute mod_depthcontent upgrade steps.
 *
 * @param int $oldversion Previous plugin version.
 * @return bool
 */
function xmldb_depthcontent_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    // S13 Phase 1: feedback data model.
    if ($oldversion < 2026041500) {

        // depthcontent_fb_state.
        $table = new xmldb_table('depthcontent_fb_state');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('pointid', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
            $table->add_field('depth', XMLDB_TYPE_CHAR, '32', null, XMLDB_NOTNULL, null, null);
            $table->add_field('slot', XMLDB_TYPE_CHAR, '32', null, XMLDB_NOTNULL, null, null);
            $table->add_field('status', XMLDB_TYPE_CHAR, '16', null, XMLDB_NOTNULL, null, 'open');
            $table->add_field('current_clip_json', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('candidates_json', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('locked_by', XMLDB_TYPE_CHAR, '128', null, null, null, null);
            $table->add_field('locked_at', XMLDB_TYPE_INTEGER, '10', null, null, null, '0');
            $table->add_field('updated_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('slot_unique', XMLDB_INDEX_UNIQUE, ['courseid', 'pointid', 'depth', 'slot']);
            $table->add_index('status_idx', XMLDB_INDEX_NOTUNIQUE, ['status']);

            $dbman->create_table($table);
        }

        // depthcontent_fb_events.
        $table = new xmldb_table('depthcontent_fb_events');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('fb_state_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('level', XMLDB_TYPE_CHAR, '2', null, XMLDB_NOTNULL, null, null);
            $table->add_field('payload_json', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('created_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('fk_user', XMLDB_KEY_FOREIGN, ['userid'], 'user', ['id']);
            $table->add_key('fk_fb_state', XMLDB_KEY_FOREIGN, ['fb_state_id'], 'depthcontent_fb_state', ['id']);
            $table->add_index('state_level', XMLDB_INDEX_NOTUNIQUE, ['fb_state_id', 'level']);
            $table->add_index('user_state', XMLDB_INDEX_NOTUNIQUE, ['userid', 'fb_state_id']);

            $dbman->create_table($table);
        }

        // depthcontent_fb_votes.
        $table = new xmldb_table('depthcontent_fb_votes');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('fb_state_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('vote_key', XMLDB_TYPE_CHAR, '128', null, XMLDB_NOTNULL, null, null);
            $table->add_field('count', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('updated_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('fk_fb_state', XMLDB_KEY_FOREIGN, ['fb_state_id'], 'depthcontent_fb_state', ['id']);
            $table->add_index('state_votekey', XMLDB_INDEX_UNIQUE, ['fb_state_id', 'vote_key']);

            $dbman->create_table($table);
        }

        upgrade_mod_savepoint(true, 2026041500, 'depthcontent');
    }

    // Phase 6: mastery ledger (ACT/HABIT/CHARACTER) + append-only retrieval log.
    // GDPR: both tables are FK-free and have no delete callbacks so a data-subject
    // erasure is a trivial DELETE WHERE userid=? via a core_privacy provider
    // (see lib.php). This is NOT run against a live Moodle as part of this build.
    if ($oldversion < 2026072000) {

        // depthcontent_mastery — UNIQUE(userid, pointid); pointid = permanent LP id.
        $table = new xmldb_table('depthcontent_mastery');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('pointid', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
            $table->add_field('ease_factor', XMLDB_TYPE_NUMBER, '5, 2', null, XMLDB_NOTNULL, null, '2.50');
            $table->add_field('interval_days', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '1');
            $table->add_field('repetitions', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('lapses', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('stability_days', XMLDB_TYPE_NUMBER, '8, 2', null, null, null, null);
            $table->add_field('difficulty_fsrs', XMLDB_TYPE_NUMBER, '5, 2', null, null, null, null);
            $table->add_field('next_review', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('next_probe', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('last_reviewed', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('act_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('act_via', XMLDB_TYPE_CHAR, '20', null, null, null, null);
            $table->add_field('act_confirmed', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('habit_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('habit_streak', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('first_success_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('last_success_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('character_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('char_window_start', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('probes_answered', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('distinct_items_correct', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('last_transfer_ok', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('status', XMLDB_TYPE_CHAR, '16', null, XMLDB_NOTNULL, null, 'none');
            $table->add_field('lapsed', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('recent_item_ids', XMLDB_TYPE_CHAR, '255', null, null, null, null);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            // No foreign keys by design (GDPR erasure = explicit DELETE, no cascade).
            $table->add_index('user_point', XMLDB_INDEX_UNIQUE, ['userid', 'pointid']);
            $table->add_index('next_review', XMLDB_INDEX_NOTUNIQUE, ['userid', 'next_review']);
            $table->add_index('next_probe', XMLDB_INDEX_NOTUNIQUE, ['userid', 'next_probe']);

            $dbman->create_table($table);
        }

        // depthcontent_retrieval_log — append-only; FSRS training set + evaluator input.
        $table = new xmldb_table('depthcontent_retrieval_log');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('pointid', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
            $table->add_field('ts', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('outcome', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('grade', XMLDB_TYPE_INTEGER, '2', null, null, null, null);
            $table->add_field('item_id', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
            $table->add_field('item_type', XMLDB_TYPE_CHAR, '16', null, null, null, null);
            $table->add_field('cognition', XMLDB_TYPE_CHAR, '16', null, null, null, null);
            $table->add_field('core_accountable', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1');
            $table->add_field('single_tag', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1');
            // confidence: TRANSIENT signal only (anti-guess/queue). NOT a per-doctrine stored flag; retention-pruned.
            $table->add_field('confidence', XMLDB_TYPE_INTEGER, '1', null, null, null, null);
            $table->add_field('latency_ms', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('mode', XMLDB_TYPE_CHAR, '16', null, null, null, null);
            $table->add_field('context', XMLDB_TYPE_CHAR, '64', null, null, null, null);

            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            // No foreign keys by design (GDPR erasure = explicit DELETE, no cascade).
            $table->add_index('user_point_ts', XMLDB_INDEX_NOTUNIQUE, ['userid', 'pointid', 'ts']);
            $table->add_index('user_ts', XMLDB_INDEX_NOTUNIQUE, ['userid', 'ts']);

            $dbman->create_table($table);
        }

        upgrade_mod_savepoint(true, 2026072000, 'depthcontent');
    }

    return true;
}
