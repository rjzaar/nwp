<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy (GDPR) provider for mod_depthcontent.
 *
 * WHAT IS STORED, AND IN WHICH CONTEXT (ops#93). mod_depthcontent records
 * Art. 9 special-category religious-formation data (which Catholic doctrines a
 * named member holds/misses) in two shapes:
 *
 *  A. Activity-instance data — keyed on depthcontentid (a course module), so it
 *     lives in that MODULE context:
 *       {depthcontent_progress}   mastery status per learning point in an instance.
 *       {depthcontent_responses}  inline quiz responses.
 *       {depthcontent_sr}         legacy SM-2 spaced-repetition state.
 *
 *  B. Course-agnostic per-member ledgers — keyed on (userid, permanent catalog
 *     pointid) with DELIBERATELY NO foreign keys and no course/module link (see
 *     db/install.xml). These are the member's formation record, so they are
 *     reported and erased in the member's own USER context:
 *       {depthcontent_mastery}        ACT/HABIT/CHARACTER attainment ledger.
 *       {depthcontent_retrieval_log}  append-only per-retrieval training log.
 *       {depthcontent_fb_events}      the member's content-feedback event log.
 *
 * WHY ERASURE IS A TRIVIAL EXPLICIT DELETE. The ledger tables were built FK-free
 * and string-keyed on the canonical pointid precisely so a data-subject erasure
 * is a single `DELETE WHERE userid = ?` per table — no Moodle cascade to unwind,
 * and NOT the same as a `--clear` render rebuild (which deliberately PRESERVES
 * member state). This provider is that explicit erasure path and joins the
 * ops#93 nwc<->ssc round-trip.
 *
 * NOT personal data (untouched): {depthcontent} (instance config),
 * {depthcontent_fb_state} (aggregate content-governance slot state) and
 * {depthcontent_fb_votes} (aggregate vote tallies, no userid).
 *
 * NO-AI-ACCESS: nothing here (including export) may be routed to any AI/LLM
 * system. Export is for the data subject's own Subject-Access Request only.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_depthcontent\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use context;
use context_module;
use context_user;

defined('MOODLE_INTERNAL') || die();

/**
 * Privacy provider: describes, exports and erases mod_depthcontent formation data.
 */
class provider implements
        \core_privacy\local\metadata\provider,
        \core_privacy\local\request\core_userlist_provider,
        \core_privacy\local\request\plugin\provider {

    /** Instance-scoped per-user tables (live in the module context). */
    const INSTANCE_TABLES = ['depthcontent_progress', 'depthcontent_responses', 'depthcontent_sr'];

    /** Course-agnostic per-member ledgers (live in the user context). */
    const LEDGER_TABLES = ['depthcontent_mastery', 'depthcontent_retrieval_log', 'depthcontent_fb_events'];

    /**
     * Describe the personal data this module stores.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('depthcontent_progress', [
            'userid'         => 'privacy:metadata:depthcontent_progress:userid',
            'depthcontentid' => 'privacy:metadata:depthcontent_progress:depthcontentid',
            'status'         => 'privacy:metadata:depthcontent_progress:status',
            'depth_viewed'   => 'privacy:metadata:depthcontent_progress:depth_viewed',
            'mastered_via'   => 'privacy:metadata:depthcontent_progress:mastered_via',
        ], 'privacy:metadata:depthcontent_progress');

        $collection->add_database_table('depthcontent_responses', [
            'userid'         => 'privacy:metadata:depthcontent_responses:userid',
            'depthcontentid' => 'privacy:metadata:depthcontent_responses:depthcontentid',
            'quizitemid'     => 'privacy:metadata:depthcontent_responses:quizitemid',
            'response'       => 'privacy:metadata:depthcontent_responses:response',
            'correct'        => 'privacy:metadata:depthcontent_responses:correct',
        ], 'privacy:metadata:depthcontent_responses');

        $collection->add_database_table('depthcontent_sr', [
            'userid'         => 'privacy:metadata:depthcontent_sr:userid',
            'depthcontentid' => 'privacy:metadata:depthcontent_sr:depthcontentid',
            'ease_factor'    => 'privacy:metadata:depthcontent_sr:ease_factor',
            'interval_days'  => 'privacy:metadata:depthcontent_sr:interval_days',
            'repetitions'    => 'privacy:metadata:depthcontent_sr:repetitions',
            'next_review'    => 'privacy:metadata:depthcontent_sr:next_review',
        ], 'privacy:metadata:depthcontent_sr');

        $collection->add_database_table('depthcontent_mastery', [
            'userid'       => 'privacy:metadata:depthcontent_mastery:userid',
            'pointid'      => 'privacy:metadata:depthcontent_mastery:pointid',
            'status'       => 'privacy:metadata:depthcontent_mastery:status',
            'act_at'       => 'privacy:metadata:depthcontent_mastery:act_at',
            'habit_at'     => 'privacy:metadata:depthcontent_mastery:habit_at',
            'character_at' => 'privacy:metadata:depthcontent_mastery:character_at',
        ], 'privacy:metadata:depthcontent_mastery');

        $collection->add_database_table('depthcontent_retrieval_log', [
            'userid'     => 'privacy:metadata:depthcontent_retrieval_log:userid',
            'pointid'    => 'privacy:metadata:depthcontent_retrieval_log:pointid',
            'ts'         => 'privacy:metadata:depthcontent_retrieval_log:ts',
            'outcome'    => 'privacy:metadata:depthcontent_retrieval_log:outcome',
            'item_id'    => 'privacy:metadata:depthcontent_retrieval_log:item_id',
            'confidence' => 'privacy:metadata:depthcontent_retrieval_log:confidence',
            'latency_ms' => 'privacy:metadata:depthcontent_retrieval_log:latency_ms',
        ], 'privacy:metadata:depthcontent_retrieval_log');

        $collection->add_database_table('depthcontent_fb_events', [
            'userid'       => 'privacy:metadata:depthcontent_fb_events:userid',
            'fb_state_id'  => 'privacy:metadata:depthcontent_fb_events:fb_state_id',
            'level'        => 'privacy:metadata:depthcontent_fb_events:level',
            'payload_json' => 'privacy:metadata:depthcontent_fb_events:payload_json',
            'created_at'   => 'privacy:metadata:depthcontent_fb_events:created_at',
        ], 'privacy:metadata:depthcontent_fb_events');

        return $collection;
    }

    /**
     * Where does this user have data? Module contexts for the instance tables,
     * plus the user's own context for the course-agnostic ledgers.
     *
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        // (A) Module contexts, one per depthcontent instance the user has data in.
        foreach (self::INSTANCE_TABLES as $table) {
            $sql = "SELECT ctx.id
                      FROM {context} ctx
                      JOIN {course_modules} cm ON cm.id = ctx.instanceid
                      JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                      JOIN {depthcontent} d ON d.id = cm.instance
                      JOIN {" . $table . "} t ON t.depthcontentid = d.id
                     WHERE ctx.contextlevel = :modlevel AND t.userid = :userid";
            $contextlist->add_from_sql($sql, [
                'modname'  => 'depthcontent',
                'modlevel' => CONTEXT_MODULE,
                'userid'   => $userid,
            ]);
        }

        // (B) User context for the FK-free course-agnostic member ledgers.
        if (self::user_has_ledger_data($userid)) {
            $contextlist->add_user_context($userid);
        }

        return $contextlist;
    }

    /**
     * Find users with data in the given context.
     *
     * @param userlist $userlist
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();

        if ($context instanceof context_module) {
            foreach (self::INSTANCE_TABLES as $table) {
                $sql = "SELECT t.userid
                          FROM {" . $table . "} t
                          JOIN {depthcontent} d ON d.id = t.depthcontentid
                          JOIN {course_modules} cm ON cm.instance = d.id
                          JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                         WHERE cm.id = :cmid";
                $userlist->add_from_sql('userid', $sql, [
                    'modname' => 'depthcontent',
                    'cmid'    => $context->instanceid,
                ]);
            }
            return;
        }

        if ($context instanceof context_user) {
            if (self::user_has_ledger_data($context->instanceid)) {
                $userlist->add_user($context->instanceid);
            }
        }
    }

    /**
     * Export the user's data for each approved context.
     *
     * @param approved_contextlist $contextlist
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;

        foreach ($contextlist->get_contexts() as $context) {
            if ($context instanceof context_module) {
                $instanceid = self::instanceid_from_context($context);
                if ($instanceid === null) {
                    continue;
                }
                $data = (object) [
                    'progress'  => array_values($DB->get_records('depthcontent_progress',
                        ['userid' => $userid, 'depthcontentid' => $instanceid])),
                    'responses' => array_values($DB->get_records('depthcontent_responses',
                        ['userid' => $userid, 'depthcontentid' => $instanceid])),
                    'sr'        => array_values($DB->get_records('depthcontent_sr',
                        ['userid' => $userid, 'depthcontentid' => $instanceid])),
                ];
                if ($data->progress || $data->responses || $data->sr) {
                    writer::with_context($context)->export_data(
                        [get_string('modulename', 'mod_depthcontent')], $data);
                }
            } else if ($context instanceof context_user && $context->instanceid == $userid) {
                $data = (object) [
                    'mastery'       => array_values($DB->get_records('depthcontent_mastery', ['userid' => $userid])),
                    'retrieval_log' => array_values($DB->get_records('depthcontent_retrieval_log', ['userid' => $userid])),
                    'feedback_log'  => array_values($DB->get_records('depthcontent_fb_events', ['userid' => $userid])),
                ];
                if ($data->mastery || $data->retrieval_log || $data->feedback_log) {
                    writer::with_context($context)->export_data(
                        [get_string('modulename', 'mod_depthcontent'),
                         get_string('privacy:ledgerpath', 'mod_depthcontent')], $data);
                }
            }
        }
    }

    /**
     * Erase all users' data in a context.
     *
     * @param context $context
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        if ($context instanceof context_module) {
            $instanceid = self::instanceid_from_context($context);
            if ($instanceid === null) {
                return;
            }
            foreach (self::INSTANCE_TABLES as $table) {
                $DB->delete_records($table, ['depthcontentid' => $instanceid]);
            }
        } else if ($context instanceof context_user) {
            self::erase_ledger($context->instanceid);
        }
    }

    /**
     * Erase the given data subject's data across the approved contexts.
     *
     * @param approved_contextlist $contextlist
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context instanceof context_module) {
                $instanceid = self::instanceid_from_context($context);
                if ($instanceid === null) {
                    continue;
                }
                foreach (self::INSTANCE_TABLES as $table) {
                    $DB->delete_records($table, ['userid' => $userid, 'depthcontentid' => $instanceid]);
                }
            } else if ($context instanceof context_user && $context->instanceid == $userid) {
                self::erase_ledger($userid);
            }
        }
    }

    /**
     * Erase the approved users in the given context.
     *
     * @param approved_userlist $userlist
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        global $DB;
        $context = $userlist->get_context();
        $userids = $userlist->get_userids();
        if (empty($userids)) {
            return;
        }

        if ($context instanceof context_module) {
            $instanceid = self::instanceid_from_context($context);
            if ($instanceid === null) {
                return;
            }
            list($insql, $params) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
            $params['dcid'] = $instanceid;
            foreach (self::INSTANCE_TABLES as $table) {
                $DB->delete_records_select($table, "depthcontentid = :dcid AND userid $insql", $params);
            }
        } else if ($context instanceof context_user) {
            foreach ($userids as $userid) {
                if ($userid == $context->instanceid) {
                    self::erase_ledger($userid);
                }
            }
        }
    }

    /**
     * Map a module context to its depthcontent instance id.
     *
     * @param context_module $context
     * @return int|null
     */
    protected static function instanceid_from_context(context_module $context): ?int {
        $cm = get_coursemodule_from_id('depthcontent', $context->instanceid, 0, false, IGNORE_MISSING);
        return $cm ? (int) $cm->instance : null;
    }

    /**
     * Does the user have any rows in the course-agnostic member ledgers?
     *
     * @param int $userid
     * @return bool
     */
    protected static function user_has_ledger_data(int $userid): bool {
        global $DB;
        foreach (self::LEDGER_TABLES as $table) {
            if ($DB->record_exists($table, ['userid' => $userid])) {
                return true;
            }
        }
        return false;
    }

    /**
     * THE ledger erasure primitive: a trivial explicit DELETE per FK-free member
     * ledger table. No cascade, no orphan-hunting.
     *
     * @param int $userid
     */
    protected static function erase_ledger(int $userid) {
        global $DB;
        foreach (self::LEDGER_TABLES as $table) {
            $DB->delete_records($table, ['userid' => $userid]);
        }
    }
}
