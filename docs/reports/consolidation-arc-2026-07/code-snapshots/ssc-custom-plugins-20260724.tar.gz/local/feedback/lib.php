<?php
/**
 * local_feedback — page-render hook lives in classes/hook_callbacks.php +
 * db/hooks.php (Moodle 4.4+ hook system).
 *
 * Legacy `local_feedback_before_footer()` function was removed because it
 * conflicts with the new hook (process_legacy_callbacks would invoke both,
 * duplicating the widget root div).
 */
defined('MOODLE_INTERNAL') || die();
