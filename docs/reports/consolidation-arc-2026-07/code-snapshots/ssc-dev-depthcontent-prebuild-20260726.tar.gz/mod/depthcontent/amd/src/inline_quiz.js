/**
 * Inline quiz module for mod_depthcontent.
 *
 * Handles zero-page-navigation quiz interactions: user clicks an option,
 * gets immediate feedback, correct/incorrect styling, and the response
 * is recorded via AJAX.
 *
 * Supported question types:
 * - multichoice (radio buttons, also covers truefalse)
 * - fillinblank (text input + check button)
 * - matching (select dropdowns + check button)
 *
 * Also handles quiz style toggling (inline / end / both).
 *
 * @module     mod_depthcontent/inline_quiz
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define(['jquery', 'core/ajax', 'core/notification'], function($, Ajax, Notification) {

    /**
     * Record a quiz response via AJAX.
     *
     * @param {number} cmid       Course module ID.
     * @param {jQuery} $item      The .dc-quiz-item element.
     * @param {string} response   The user's response string.
     * @param {boolean} isCorrect Whether the response was correct.
     */
    function recordResponse(cmid, $item, response, isCorrect) {
        var quizItemId = $item.data('quizitem');
        Ajax.call([{
            methodname: 'mod_depthcontent_record_response',
            args: {
                cmid: cmid,
                quizitemid: String(quizItemId),
                response: String(response),
                correct: isCorrect ? 1 : 0
            },
            fail: function() {
                // Silently fail for guests — response just isn't saved.
            }
        }]);
    }

    /**
     * Apply quiz style visibility.
     *
     * @param {string} style One of 'inline', 'end'.
     */
    function applyQuizStyle(style) {
        var $inline = $('.dc-quiz-inline');
        var $grouped = $('.dc-quiz-grouped');

        if (style === 'end') {
            $inline.hide();
            $grouped.show();
        } else {
            $inline.show();
            $grouped.hide();
        }
    }

    /**
     * Save the quiz style preference via AJAX.
     *
     * @param {string} style The style value to save.
     */
    function saveQuizStylePreference(style) {
        Ajax.call([{
            methodname: 'core_user_set_user_preferences',
            args: {
                preferences: [{
                    name: 'mod_depthcontent_quizstyle',
                    value: style
                }]
            },
            fail: Notification.exception
        }]);
    }

    return {
        /**
         * Initialise the inline quiz module.
         *
         * @param {number} cmid       Course module ID.
         * @param {Array}  quizItems  Quiz item data (passed from PHP, used for blanks metadata etc.).
         * @param {string} quizStyle  One of 'inline', 'end', 'both'. Defaults to 'inline'.
         */
        init: function(cmid, quizItems, quizStyle) {

            // Store quiz style for potential future use.
            quizStyle = quizStyle || 'inline';

            // ── Apply initial quiz style visibility ──
            applyQuizStyle(quizStyle);

            // ── Quiz style toggle handler ──
            $(document).on('change', '.dc-quizstyle-radio', function() {
                var newStyle = $(this).val();
                applyQuizStyle(newStyle);
                saveQuizStylePreference(newStyle);
            });

            // ── Number of questions handler — save preference and reload ──
            $(document).on('change', '.dc-quizcount-radio', function() {
                var newCount = $(this).val();
                Ajax.call([{
                    methodname: 'core_user_set_user_preferences',
                    args: {
                        preferences: [{
                            name: 'mod_depthcontent_quizcount',
                            value: newCount
                        }]
                    },
                    done: function() {
                        // Reload to re-render with new count (server-side limit).
                        window.location.reload();
                    },
                    fail: Notification.exception
                }]);
            });

            // ── Multichoice / Truefalse handler (radio buttons) ──
            $(document).on('change', '.dc-quiz-item input[type="radio"]', function() {
                var $input = $(this);
                var $item = $input.closest('.dc-quiz-item');
                var $option = $input.closest('.dc-quiz-option');
                var $feedback = $item.find('.dc-quiz-feedback');

                // Prevent re-answering.
                if ($item.hasClass('dc-answered')) {
                    return;
                }
                $item.addClass('dc-answered');

                // Disable all inputs in this question.
                $item.find('input[type="radio"]').prop('disabled', true);

                // Check correctness.
                var isCorrect = $option.data('correct') === 1;
                var feedbackText = $option.data('feedback') || '';

                // Style the selected option.
                if (isCorrect) {
                    $option.addClass('dc-correct');
                    $feedback.addClass('dc-feedback-correct')
                             .html('<strong>&#10003; Correct!</strong> ' + feedbackText)
                             .slideDown(200);
                } else {
                    $option.addClass('dc-incorrect');
                    // Highlight the correct answer.
                    $item.find('.dc-quiz-option[data-correct="1"]').addClass('dc-correct');
                    $feedback.addClass('dc-feedback-incorrect')
                             .html('<strong>&#10007; Not quite.</strong> ' + feedbackText)
                             .slideDown(200);
                }

                // Record response via AJAX.
                recordResponse(cmid, $item, $input.val(), isCorrect);
            });

            // ── Fill-in-the-blank handler ──
            $(document).on('click', '.dc-fillin-check', function() {
                var $btn = $(this);
                var $item = $btn.closest('.dc-quiz-item');

                if ($item.hasClass('dc-answered')) {
                    return;
                }

                var $container = $item.find('.dc-fillin-container');
                var blanks = $container.data('blanks');
                var alternatives = $container.data('alternatives') || [];
                var allCorrect = true;

                $item.find('.dc-fillin-input').each(function(idx) {
                    var userAnswer = $(this).val().trim().toLowerCase();
                    var expected = (blanks && blanks[idx]) ? blanks[idx].toLowerCase() : '';
                    // Also accept alternatives for this blank.
                    var alts = (alternatives && alternatives[idx]) ? alternatives[idx] : [];
                    if (typeof alts === 'string') {
                        alts = [alts];
                    }
                    var allAccepted = [expected].concat(alts.map(function(a) { return a.toLowerCase(); }));
                    if (allAccepted.indexOf(userAnswer) !== -1) {
                        $(this).addClass('dc-correct');
                    } else {
                        $(this).addClass('dc-incorrect');
                        allCorrect = false;
                    }
                    $(this).prop('disabled', true);
                });

                $item.addClass('dc-answered');
                var $feedback = $item.find('.dc-quiz-feedback');
                if (allCorrect) {
                    $feedback.addClass('dc-feedback-correct')
                             .html('<strong>&#10003; Correct!</strong>')
                             .slideDown(200);
                } else {
                    var answer = blanks ? blanks.join(', ') : '';
                    $feedback.addClass('dc-feedback-incorrect')
                             .html('<strong>&#10007; Not quite.</strong> The answer is: ' + answer)
                             .slideDown(200);
                }

                // Record response: join user inputs as comma-separated string.
                var userInputs = [];
                $item.find('.dc-fillin-input').each(function() {
                    userInputs.push($(this).val().trim());
                });
                recordResponse(cmid, $item, userInputs.join(', '), allCorrect);
            });

            // ── Matching handler ──
            $(document).on('click', '.dc-matching-check', function() {
                var $btn = $(this);
                var $item = $btn.closest('.dc-quiz-item');

                if ($item.hasClass('dc-answered')) {
                    return;
                }

                var allCorrect = true;
                var selections = {};
                var correctPairings = [];

                $item.find('.dc-matching-pair').each(function() {
                    var $pair = $(this);
                    var $select = $pair.find('.dc-matching-select');
                    var userValue = $select.val();
                    var correctValue = $pair.data('correct-right');
                    var leftLabel = $pair.find('.dc-matching-left').text().trim();

                    // Store the user's selection.
                    selections[leftLabel] = userValue;

                    if (userValue === String(correctValue)) {
                        $pair.addClass('dc-correct');
                    } else {
                        $pair.addClass('dc-incorrect');
                        allCorrect = false;
                        correctPairings.push(leftLabel + ' &rarr; ' + correctValue);
                    }

                    // Disable the select.
                    $select.prop('disabled', true);
                });

                $item.addClass('dc-answered');

                // Disable the check button.
                $btn.prop('disabled', true);

                var $feedback = $item.find('.dc-quiz-feedback');
                if (allCorrect) {
                    $feedback.addClass('dc-feedback-correct')
                             .html('<strong>&#10003; Correct!</strong> All pairs matched correctly.')
                             .slideDown(200);
                } else {
                    var pairingList = correctPairings.join('<br>');
                    $feedback.addClass('dc-feedback-incorrect')
                             .html('<strong>&#10007; Not quite.</strong> Correct pairings:<br>' + pairingList)
                             .slideDown(200);
                }

                // Record response as JSON string of selections.
                recordResponse(cmid, $item, JSON.stringify(selections), allCorrect);
            });
        }
    };
});
