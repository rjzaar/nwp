@local @local_feedback @javascript
Feature: Saint School floating feedback widget
  In order to capture feedback from learners and credit Tester Guild
  As a logged-in user on any page
  I need a floating green button that opens a quick submission form

  Background:
    Given the following config values are set as admin:
      | enabled        | 1 | local_feedback |
      | logged_in_only | 0 | local_feedback |
    And the following "users" exist:
      | username  | firstname | lastname  | email             |
      | submitter | Sub       | Mitter    | sub@example.com   |
      | mentor    | Test      | Mentor    | mentor@example.com|
    And the following "role assigns" exist:
      | user   | role    | contextlevel | reference |
      | mentor | manager | System       |           |

  @local_feedback_render
  Scenario: The widget button renders on every page when enabled
    Given I log in as "submitter"
    When I am on homepage
    Then ".local-feedback-trigger" "css_element" should be visible
    When I follow "All courses"
    Then ".local-feedback-trigger" "css_element" should be visible
    When I am on "Course: The Universal Call to Holiness" course homepage
    Then ".local-feedback-trigger" "css_element" should be visible

  @local_feedback_render_hide
  Scenario: The widget can be disabled site-wide
    Given the following config values are set as admin:
      | enabled | 0 | local_feedback |
    And I log in as "submitter"
    When I am on homepage
    Then ".local-feedback-trigger" "css_element" should not exist

  @local_feedback_submit
  Scenario: A logged-in user submits a suggestion
    Given I log in as "submitter"
    And I am on homepage
    When I click on ".local-feedback-trigger" "css_element"
    Then ".local-feedback-popup--open" "css_element" should be visible
    When I click on "Suggestion" "button" in the ".local-feedback-popup" "css_element"
    And I set the field "Brief title..." to "A test suggestion"
    And I set the field "Details (optional)..." to "From a Behat scenario."
    And I click on ".local-feedback-popup__submit" "css_element"
    Then I should see "Thank you for your feedback!"
    # Verify the DB row landed
    And the following should exist in the "local_feedback" table:
      | type       | title             | status  | username        |
      | suggestion | A test suggestion | pending | Sub Mitter      |

  @local_feedback_review
  Scenario: A Tester Guild mentor reviews + approves
    Given the following "local_feedback" entries exist:
      | type       | title             | body          | userid     | status  |
      | suggestion | A test suggestion | needs review  | submitter  | pending |
    And I log in as "mentor"
    When I navigate to "/local/feedback/index.php"
    Then I should see "A test suggestion"
    And I should see "Pending"
    When I follow "A test suggestion"
    And I press "Approve"
    Then I should see "approved"
    And the following should exist in the "local_feedback" table:
      | title             | status   | avc_score_awarded |
      | A test suggestion | approved | 10                |
