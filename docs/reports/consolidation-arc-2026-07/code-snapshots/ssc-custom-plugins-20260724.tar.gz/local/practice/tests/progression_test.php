<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Table-driven unit tests for the pure PROGRESSION-DISPLAY layer (N9 build #4/#6).
 *
 * Runs WITHOUT a Moodle runtime:  php tests/progression_test.php
 *
 * Proves the progression-visibility invariants (FORMATION-progression-visibility.md
 * + FORMATION-MASTER-DESIGN §3):
 *   - The 3 modes (full|gentle|quiet), default gentle; mode -> field granularity.
 *   - DISPLAY-ONLY invariant: `quiet` suppresses the VIEW, NEVER the recording —
 *     the state is still fully recorded (engaged_days intact, view() does not mutate).
 *   - Grace framing present on every rendered payload; never performance framing.
 *   - NO comparison-to-others field is EVER emitted (no leaderboards, ever).
 *   - States (—/forming/held/formed) map correctly from recorded state.
 *   - Never-miss-twice fires on the SECOND-consecutive-miss risk, never a single miss.
 *   - Anchor plan (implementation intention) stores + retrieves + surfaces on the grid.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
require_once(__DIR__ . '/../classes/engine.php');       // progression uses engine::ymd_to_daynum().
require_once(__DIR__ . '/../classes/progression.php');

use local_practice\engine;
use local_practice\progression;

// ---- Tiny assertion harness (no PHPUnit / no Moodle needed) ----------------
$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
$GLOBALS['__fails'] = [];

function check(string $name, $expected, $actual): void {
    if ($expected === $actual) {
        $GLOBALS['__pass']++;
    } else {
        $GLOBALS['__fail']++;
        $GLOBALS['__fails'][] = sprintf("  FAIL: %s\n        expected=%s got=%s",
            $name, var_export($expected, true), var_export($actual, true));
    }
}

const BASE = 1700000000;
const DAY = 86400;

/** Engagement-log row. */
function e(int $ymd, string $source = 'manual', int $dayoffset = 0): array {
    return ['ts' => BASE + $dayoffset * DAY, 'localdate' => $ymd, 'source' => $source];
}

// Fast thresholds so a habit consolidates in a tiny table.
$fast = ['habit_form_count' => ['daily' => 3], 'habit_span_floor_days' => ['daily' => 3]];

$task  = ['type' => 'task',  'pacing' => 'tick'];
$habit = ['type' => 'habit', 'cadence' => 'daily'];

// Reusable recorded states, produced by the REAL engine (so the display layer is
// tested against genuine recorded state, never hand-faked numbers).
$none    = engine::derive([], $habit);                                  // todo, nothing engaged.
$forming = engine::derive([e(20260701, 'manual', 0)], $habit, $fast);   // active, 1 day.
$log3    = [e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260703, 'manual', 2)];
$held    = engine::derive($log3, ['type' => 'habit', 'cadence' => 'daily', 'on_consolidate' => 'keep'], $fast);
$formed  = engine::derive($log3, ['type' => 'habit', 'cadence' => 'daily', 'on_consolidate' => 'promote'], $fast);
$done    = engine::derive([e(20260701, 'manual')], $task);              // task -> done.

// ===========================================================================
// MODE DEFAULT + NORMALISATION
// ===========================================================================

check('MODE.default_gentle', 'gentle', progression::default_mode());
check('MODE.normalise_unknown_to_gentle', 'gentle', progression::normalise_mode('sideways'));
check('MODE.normalise_null_to_gentle', 'gentle', progression::normalise_mode(null));
check('MODE.normalise_full', 'full', progression::normalise_mode('FULL'));
check('MODE.normalise_quiet', 'quiet', progression::normalise_mode(' quiet '));

// ===========================================================================
// STATES (—/forming/held/formed) map correctly from RECORDED state
// ===========================================================================

check('STATE.none', progression::STATE_NONE, progression::progression_state($none));
check('STATE.forming', progression::STATE_FORMING, progression::progression_state($forming));
check('STATE.held_on_keep', progression::STATE_HELD, progression::progression_state($held));
check('STATE.formed_on_promote', progression::STATE_FORMED, progression::progression_state($formed));
check('STATE.task_done_is_held', progression::STATE_HELD, progression::progression_state($done));
check('STATE.symbol_none', '—', progression::state_symbol(progression::STATE_NONE));
check('STATE.symbol_forming', '◐', progression::state_symbol(progression::STATE_FORMING));
check('STATE.symbol_held', '●', progression::state_symbol(progression::STATE_HELD));
check('STATE.symbol_formed', '★', progression::state_symbol(progression::STATE_FORMED));

// Growth (practice-plane ACT->HABIT->CHARACTER analog).
check('GROWTH.none_null', null, progression::growth($none));
check('GROWTH.forming_act', 'ACT', progression::growth($forming));
check('GROWTH.held_habit', 'HABIT', progression::growth($held));
check('GROWTH.formed_character', 'CHARACTER', progression::growth($formed));

// ===========================================================================
// MODE -> FIELD GRANULARITY (the load-bearing display contract)
// ===========================================================================

$vfull   = progression::view($held, 'full');
$vgentle = progression::view($held, 'gentle');
$vquiet  = progression::view($held, 'quiet');

// FULL: states + milestones + growth + the fidelity lifetime-count.
check('FULL.mode', 'full', $vfull['mode']);
check('FULL.not_suppressed', false, $vfull['suppressed']);
check('FULL.has_state', true, array_key_exists('state', $vfull));
check('FULL.has_growth', true, array_key_exists('growth', $vfull));
check('FULL.has_lifetime_count', true, array_key_exists('lifetime_count', $vfull));
check('FULL.lifetime_count_value', 3, $vfull['lifetime_count']);
check('FULL.has_milestones', true, array_key_exists('milestones', $vfull));

// GENTLE (default): milestones + current state ONLY — NO granular counts/growth.
check('GENTLE.mode', 'gentle', $vgentle['mode']);
check('GENTLE.has_state', true, array_key_exists('state', $vgentle));
check('GENTLE.has_milestones', true, array_key_exists('milestones', $vgentle));
check('GENTLE.no_growth', false, array_key_exists('growth', $vgentle));
check('GENTLE.no_lifetime_count', false, array_key_exists('lifetime_count', $vgentle));

// QUIET: empty/suppressed progression view — NO state, NO milestones, NO counts.
check('QUIET.mode', 'quiet', $vquiet['mode']);
check('QUIET.suppressed', true, $vquiet['suppressed']);
check('QUIET.no_state', false, array_key_exists('state', $vquiet));
check('QUIET.no_milestones', false, array_key_exists('milestones', $vquiet));
check('QUIET.no_lifetime_count', false, array_key_exists('lifetime_count', $vquiet));

// A resettable STREAK field is NEVER emitted at any granularity.
check('GUARD.full_no_streak_key', false, array_key_exists('streak', $vfull));
check('GUARD.gentle_no_streak_key', false, array_key_exists('streak', $vgentle));

// ===========================================================================
// GRACE FRAMING present on EVERY payload; never performance framing
// ===========================================================================

foreach (['full' => $vfull, 'gentle' => $vgentle, 'quiet' => $vquiet] as $m => $v) {
    check("FRAMING.present_$m", true, !empty($v['framing']));
    check("FRAMING.grace_$m", true, stripos($v['framing'], 'grace') !== false);
    // Never performance/achievement framing.
    $bad = false;
    foreach (['score', 'rank', 'win', 'beat', 'achievement', 'points'] as $word) {
        if (stripos($v['framing'], $word) !== false) {
            $bad = true;
        }
    }
    check("FRAMING.no_performance_$m", false, $bad);
}

// ===========================================================================
// GUARDRAIL: NO comparison-to-others field is EVER emitted (no leaderboards)
// ===========================================================================

check('COMPARE.full_none', false, progression::contains_comparison($vfull));
check('COMPARE.gentle_none', false, progression::contains_comparison($vgentle));
check('COMPARE.quiet_none', false, progression::contains_comparison($vquiet));
// The guard actually detects a comparison-shaped key (proves it isn't a no-op).
check('COMPARE.guard_detects', true, progression::contains_comparison(['leaderboard_rank' => 4]));
check('COMPARE.guard_detects_nested', true,
    progression::contains_comparison(['ok' => 1, 'nested' => ['peer_percentile' => 90]]));

// ===========================================================================
// DISPLAY-ONLY INVARIANT: `quiet` never stops recording (hiding != data op)
// ===========================================================================

// Genuine recorded state (via the real engine) for a member who WOULD be in quiet mode.
$recorded = engine::derive($log3, ['type' => 'habit', 'cadence' => 'daily'], $fast);
check('RECORD.data_present_before', 3, $recorded['engaged_days']);
$snapshot = $recorded; // copy.
$qview = progression::view($recorded, 'quiet');
// The quiet VIEW shows nothing...
check('RECORD.quiet_suppresses_view', true, $qview['suppressed']);
check('RECORD.quiet_view_has_no_count', false, array_key_exists('lifetime_count', $qview));
// ...but the DATA is untouched and still fully recorded (view() did not mutate it).
check('RECORD.data_recorded_in_quiet', 3, $recorded['engaged_days']);
check('RECORD.state_unmutated', $snapshot, $recorded);
check('RECORD.status_still_consolidated', 'consolidated', $recorded['status']);

// ===========================================================================
// NEVER-MISS-TWICE — fires on the SECOND-consecutive-miss risk, never a single miss
// ===========================================================================

// Daily cadence. last engaged = 20260710.
check('NMT.engaged_today_no_nudge', null,
    progression::never_miss_twice_nudge(20260710, 20260710, 'daily'));
check('NMT.single_blank_yesterday_no_nudge', null,
    progression::never_miss_twice_nudge(20260710, 20260711, 'daily')); // gap 1 -> 0 elapsed misses.
$nmt = progression::never_miss_twice_nudge(20260710, 20260712, 'daily'); // gap 2 -> 1 elapsed miss -> FIRE.
check('NMT.second_miss_risk_fires', true, is_array($nmt) && $nmt['fires'] === true);
check('NMT.level', 'never_miss_twice', $nmt['level']);
check('NMT.gentle_copy_no_shame', false,
    stripos($nmt['message'], 'fail') !== false || stripos($nmt['message'], 'broken streak') === 0);
check('NMT.already_missed_twice_no_nudge', null,
    progression::never_miss_twice_nudge(20260710, 20260713, 'daily')); // gap 3 -> 2 elapsed -> out of scope.

// Weekly cadence: one week missed, second at risk -> fire (14-day gap).
$nmtw = progression::never_miss_twice_nudge(20260701, 20260715, 'weekly');
check('NMT.weekly_second_miss_fires', true, is_array($nmtw) && $nmtw['fires'] === true);
check('NMT.weekly_one_week_gap_no_nudge', null,
    progression::never_miss_twice_nudge(20260701, 20260708, 'weekly')); // gap 7 -> 0 elapsed.

// Non-periodic cadences carry no calendar-miss concept -> never nudged.
check('NMT.situational_never', null, progression::never_miss_twice_nudge(20260701, 20260901, 'situational'));
check('NMT.once_never', null, progression::never_miss_twice_nudge(20260701, 20260901, 'once'));
check('NMT.never_engaged_no_nudge', null, progression::never_miss_twice_nudge(0, 20260712, 'daily'));

// ===========================================================================
// ANCHOR PLAN (implementation intention) — store + retrieve + surface on grid
// ===========================================================================

// Sanitisation.
check('ANCHOR.sanitise_trims', 'After coffee, I will pray.',
    progression::sanitise_anchor('  After coffee, I will pray.  '));
check('ANCHOR.sanitise_empty_null', null, progression::sanitise_anchor('   '));
check('ANCHOR.sanitise_nonstring_null', null, progression::sanitise_anchor(42));
check('ANCHOR.sanitise_caps_length', 255,
    strlen(progression::sanitise_anchor(str_repeat('x', 400))));

// Store the anchor with the adopted checkpoint state, then surface it on the grid
// (the gentle/full view carries it; the round-trip proves store + retrieve).
$adopted = $forming;
$adopted['anchor_plan'] = progression::sanitise_anchor('After I brush my teeth, I will do mental prayer.');
$vg = progression::view($adopted, 'gentle');
check('ANCHOR.surfaced_gentle', 'After I brush my teeth, I will do mental prayer.', $vg['anchor']);
$vf = progression::view($adopted, 'full');
check('ANCHOR.surfaced_full', 'After I brush my teeth, I will do mental prayer.', $vf['anchor']);
// No anchor set -> null (not surfaced).
check('ANCHOR.absent_is_null', null, progression::view($forming, 'gentle')['anchor']);
// Quiet suppresses the anchor with the rest of the view.
check('ANCHOR.quiet_suppressed', false, array_key_exists('anchor', progression::view($adopted, 'quiet')));

// ===========================================================================
// RENEWAL — a lapsed held/formed item renders "due for renewal" (invitation)
// ===========================================================================

// Held item last engaged 20260703; as-of 40 days later -> due for renewal.
check('RENEWAL.due_after_window', true, progression::renewal_due($held, 20260815));
check('RENEWAL.not_due_within_window', false, progression::renewal_due($held, 20260710));
check('RENEWAL.forming_never_due', false, progression::renewal_due($forming, 20261231));
check('RENEWAL.no_asof_never_due', false, progression::renewal_due($held, 0));

// ---- Report ----------------------------------------------------------------
$total = $GLOBALS['__pass'] + $GLOBALS['__fail'];
echo "\nlocal_practice progression-visibility (3-mode display) tests\n";
echo str_repeat('-', 58) . "\n";
if ($GLOBALS['__fail'] > 0) {
    echo implode("\n", $GLOBALS['__fails']) . "\n";
}
printf("%d/%d checks passed (%d failed)\n", $GLOBALS['__pass'], $total, $GLOBALS['__fail']);
exit($GLOBALS['__fail'] === 0 ? 0 : 1);
