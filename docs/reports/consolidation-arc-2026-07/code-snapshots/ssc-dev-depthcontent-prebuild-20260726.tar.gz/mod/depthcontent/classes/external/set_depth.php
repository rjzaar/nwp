<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Set user depth preference via AJAX.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_depthcontent\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;

class set_depth extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'depth' => new external_value(PARAM_ALPHA, 'Depth level name'),
            'remember' => new external_value(PARAM_BOOL, 'Persist as global default', VALUE_DEFAULT, true),
            'depthcontentid' => new external_value(PARAM_INT, 'Activity instance id for per-point override', VALUE_DEFAULT, 0),
        ]);
    }

    public static function execute(string $depth, bool $remember = true, int $depthcontentid = 0): array {
        global $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'depth' => $depth,
            'remember' => $remember,
            'depthcontentid' => $depthcontentid,
        ]);

        require_once($GLOBALS['CFG']->dirroot . '/mod/depthcontent/lib.php');

        // Persist the remember preference itself.
        depthcontent_set_remember_preference($USER->id, $params['remember']);

        if ($params['remember']) {
            // Save as global default.
            depthcontent_set_user_depth($USER->id, $params['depth'], true);
        }

        // If a specific point id is given, save a per-point override.
        if ($params['depthcontentid'] > 0) {
            depthcontent_set_point_depth($USER->id, $params['depthcontentid'], $params['depth']);
        }

        return ['success' => true, 'depth' => $params['depth']];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Success'),
            'depth' => new external_value(PARAM_ALPHA, 'Set depth level'),
        ]);
    }
}
