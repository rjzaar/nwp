<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * local_mentor — the Plan-of-Love ACCOMPANIMENT (mentor) plane.
 *
 * The firewall-safe, member-initiated, push-only accompaniment feature: the
 * digital analog of spiritual direction. A mentor sees ONLY the coarse snapshot
 * the member elected to PUSH — never a live pull of tick grids, never the granular
 * practice/knowing data. "Accompaniment is push; surveillance is pull."
 *
 * Build #5 of the formation roadmap (FORMATION-MASTER-DESIGN §4;
 * FORMATION-plan-of-love-ux.md §4). Reads local_practice's public
 * progression::view(...,'gentle') for the coarse engagement tier; touches nothing
 * else in local_practice and nothing in mod_depthcontent.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_mentor';
$plugin->version   = 2026072000;       // v1.0: firewall-safe accompaniment (consent tiers + covenant + push-only dashboard).
$plugin->requires  = 2024041600;       // Moodle 4.4+
$plugin->dependencies = [
    'local_practice' => 2026072002,    // reads progression::view(...,'gentle') — the coarse member-safe share.
];
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.0';
