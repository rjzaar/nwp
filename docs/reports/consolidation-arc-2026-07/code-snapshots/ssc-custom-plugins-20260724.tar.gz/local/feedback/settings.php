<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_feedback', get_string('pluginname', 'local_feedback'));
    $ADMIN->add('localplugins', $settings);

    // General
    $settings->add(new admin_setting_heading('local_feedback/general',
        get_string('settings_general', 'local_feedback'), ''));

    $settings->add(new admin_setting_configcheckbox('local_feedback/enabled',
        get_string('settings_enabled', 'local_feedback'),
        get_string('settings_enabled_desc', 'local_feedback'),
        1));

    $settings->add(new admin_setting_configcheckbox('local_feedback/logged_in_only',
        get_string('settings_logged_in_only', 'local_feedback'),
        get_string('settings_logged_in_only_desc', 'local_feedback'),
        0));

    // GitLab forwarding
    $settings->add(new admin_setting_heading('local_feedback/gitlab_header',
        get_string('settings_gitlab', 'local_feedback'), ''));

    $settings->add(new admin_setting_configtext('local_feedback/gitlab_url',
        get_string('settings_gitlab_url', 'local_feedback'),
        get_string('settings_gitlab_url_desc', 'local_feedback'),
        '', PARAM_URL));

    $settings->add(new admin_setting_configtext('local_feedback/gitlab_project',
        get_string('settings_gitlab_project', 'local_feedback'),
        get_string('settings_gitlab_project_desc', 'local_feedback'),
        '', PARAM_RAW_TRIMMED));

    $settings->add(new admin_setting_configpasswordunmask('local_feedback/gitlab_token',
        get_string('settings_gitlab_token', 'local_feedback'),
        get_string('settings_gitlab_token_desc', 'local_feedback'),
        ''));

    // AVC logging
    $settings->add(new admin_setting_heading('local_feedback/avc_header',
        get_string('settings_avc', 'local_feedback'), ''));

    $settings->add(new admin_setting_configtext('local_feedback/avc_url',
        get_string('settings_avc_url', 'local_feedback'),
        get_string('settings_avc_url_desc', 'local_feedback'),
        '', PARAM_URL));

    $settings->add(new admin_setting_configpasswordunmask('local_feedback/avc_token',
        get_string('settings_avc_token', 'local_feedback'),
        get_string('settings_avc_token_desc', 'local_feedback'),
        ''));

    $settings->add(new admin_setting_configtext('local_feedback/avc_score_default',
        get_string('settings_avc_score_default', 'local_feedback'),
        get_string('settings_avc_score_default_desc', 'local_feedback'),
        '10', PARAM_INT));
}
