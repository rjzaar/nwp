<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * S13 Phase 3 — Level C (per-slot-fit + fact-check) and Level D (re-trim).
 *
 * Records the event locally and forwards to AVC's clip-review signal
 * endpoint so the curator board sees the learner signal aggregated
 * alongside other Level A/B inputs.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP / Sacred Sources (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace mod_depthcontent\external;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/externallib.php');

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;

class feedback_full_annotation extends external_api {

    public static function submit_level_c_parameters(): external_function_parameters {
        return new external_function_parameters([
            'fb_state_id' => new external_value(PARAM_INT, 'Feedback state row id'),
            'slot_fit'    => new external_value(PARAM_INT, 'Per-slot fit score 0-10'),
            'authority_ok' => new external_value(PARAM_BOOL, 'Authority citation looks accurate'),
            'cross_ref'   => new external_value(PARAM_TEXT, 'Optional cross-reference suggestion', VALUE_DEFAULT, ''),
            'notes'       => new external_value(PARAM_TEXT, 'Free-text reviewer notes', VALUE_DEFAULT, ''),
        ]);
    }

    public static function submit_level_c(int $fbstateid, int $slotfit, bool $authorityok, string $crossref = '', string $notes = ''): array {
        global $DB, $USER;

        self::validate_parameters(self::submit_level_c_parameters(), [
            'fb_state_id' => $fbstateid,
            'slot_fit' => $slotfit,
            'authority_ok' => $authorityok,
            'cross_ref' => $crossref,
            'notes' => $notes,
        ]);

        $state = $DB->get_record('depthcontent_fb_state', ['id' => $fbstateid], '*', MUST_EXIST);

        $payload = [
            'slot_fit' => max(0, min(10, $slotfit)),
            'authority_ok' => (bool) $authorityok,
            'cross_ref' => $crossref,
            'notes' => $notes,
        ];

        $event = (object) [
            'fb_state_id' => (int) $state->id,
            'userid' => (int) $USER->id,
            'level' => 'C',
            'payload_json' => json_encode($payload),
            'timecreated' => time(),
        ];
        $DB->insert_record('depthcontent_fb_events', $event);

        $forwarded = self::forward_to_avc($state, $USER, 'C', $payload);

        return [
            'ok' => true,
            'avc_signal_id' => $forwarded['signal_id'] ?? null,
            'promoted_to' => $forwarded['promoted_to'] ?? null,
        ];
    }

    public static function submit_level_c_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, 'Success flag'),
            'avc_signal_id' => new external_value(PARAM_INT, 'AVC LearnerSignal id', VALUE_OPTIONAL),
            'promoted_to' => new external_value(PARAM_INT, 'Auto-promoted ClipSuggestion id', VALUE_OPTIONAL),
        ]);
    }

    public static function submit_level_d_parameters(): external_function_parameters {
        return new external_function_parameters([
            'fb_state_id' => new external_value(PARAM_INT, 'Feedback state row id'),
            'episode'     => new external_value(PARAM_INT, 'DIR episode number'),
            'start_s'     => new external_value(PARAM_FLOAT, 'Proposed start (seconds)'),
            'end_s'       => new external_value(PARAM_FLOAT, 'Proposed end (seconds)'),
            'rationale'   => new external_value(PARAM_TEXT, 'Why this trim is better'),
            'youtube_id'  => new external_value(PARAM_TEXT, 'YouTube id if known', VALUE_DEFAULT, ''),
        ]);
    }

    public static function submit_level_d(int $fbstateid, int $episode, float $starts, float $ends, string $rationale, string $youtubeid = ''): array {
        global $DB, $USER;

        self::validate_parameters(self::submit_level_d_parameters(), [
            'fb_state_id' => $fbstateid,
            'episode' => $episode,
            'start_s' => $starts,
            'end_s' => $ends,
            'rationale' => $rationale,
            'youtube_id' => $youtubeid,
        ]);

        if ($ends <= $starts) {
            throw new \invalid_parameter_exception('end_s must be greater than start_s');
        }

        $state = $DB->get_record('depthcontent_fb_state', ['id' => $fbstateid], '*', MUST_EXIST);

        $payload = [
            'episode' => $episode,
            'start_s' => $starts,
            'end_s' => $ends,
            'rationale' => $rationale,
            'youtube_id' => $youtubeid,
        ];

        $event = (object) [
            'fb_state_id' => (int) $state->id,
            'userid' => (int) $USER->id,
            'level' => 'D',
            'payload_json' => json_encode($payload),
            'timecreated' => time(),
        ];
        $DB->insert_record('depthcontent_fb_events', $event);

        $forwarded = self::forward_to_avc($state, $USER, 'D', $payload);

        return [
            'ok' => true,
            'avc_signal_id' => $forwarded['signal_id'] ?? null,
            'promoted_to' => $forwarded['promoted_to'] ?? null,
        ];
    }

    public static function submit_level_d_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, 'Success flag'),
            'avc_signal_id' => new external_value(PARAM_INT, 'AVC LearnerSignal id', VALUE_OPTIONAL),
            'promoted_to' => new external_value(PARAM_INT, 'Auto-promoted ClipSuggestion id', VALUE_OPTIONAL),
        ]);
    }

    /**
     * Forward an event to AVC's /api/clip-review/signal endpoint.
     */
    protected static function forward_to_avc(\stdClass $state, \stdClass $user, string $level, array $payload): array {
        $base = get_config('local_avc_copyright_sync', 'avc_base_url');
        $token = get_config('local_avc_copyright_sync', 'avc_token');
        if (!$base || !$token) {
            return [];
        }

        $course_code = self::extract_course_code($state->pointid);
        $session_id = self::extract_session_id($state);
        $target = "lp:{$course_code}:{$session_id}:{$state->pointid}:{$state->depth}";

        $body = [
            'target' => $target,
            'level' => $level,
            'user_id' => (int) $user->id,
            'source' => 'mod_depthcontent',
            'payload' => $payload,
        ];

        $url = rtrim($base, '/') . '/api/clip-review/signal';
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => json_encode($body),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-Cross-Site-Token: ' . $token,
            ],
            CURLOPT_TIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
        if (!$resp) {
            return [];
        }
        $decoded = json_decode((string) $resp, true);
        return is_array($decoded) ? $decoded : [];
    }

    protected static function extract_course_code(string $pointid): string {
        if (preg_match('/^([A-Z]+\d+)\./', $pointid, $m)) {
            return $m[1];
        }
        return preg_replace('/\..*$/', '', $pointid);
    }

    protected static function extract_session_id(\stdClass $state): int {
        if (!empty($state->current_clip_json)) {
            $j = json_decode($state->current_clip_json, true);
            if (is_array($j) && isset($j['session'])) {
                return (int) $j['session'];
            }
        }
        return 1;
    }

}
