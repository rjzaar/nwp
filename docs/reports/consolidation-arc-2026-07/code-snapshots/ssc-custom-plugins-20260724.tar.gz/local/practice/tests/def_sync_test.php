<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Pure unit tests for def_sync's extraction + uid derivation.
 *
 * Runs WITHOUT a Moodle runtime:  php tests/def_sync_test.php
 * (only exercises the DB-free static methods make_uid()/extract()).
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
require_once(__DIR__ . '/../classes/engine.php');   // def_sync uses engine::default_cadence().
require_once(__DIR__ . '/../classes/def_sync.php');

use local_practice\def_sync;

$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
$GLOBALS['__fails'] = [];

function check(string $name, $expected, $actual): void {
    if ($expected === $actual) {
        $GLOBALS['__pass']++;
    } else {
        $GLOBALS['__fail']++;
        $GLOBALS['__fails'][] = sprintf("  FAIL: %s\n        expected=%s got=%s",
            $name, var_export($expected, true), var_export($actual, true));
    }
}

// --- uid derivation: course prefix collapsed when pointid carries it. --------
check('uid.dedup', 'B5.03.mental_prayer', def_sync::make_uid('B5', 'B5.03', 'mental_prayer'));
check('uid.no_prefix', 'X.Y.k', def_sync::make_uid('X', 'Y', 'k'));

// --- LP-level checkpoints: typed extracted, TODO_pedagogy skipped. -----------
$lp = ['id' => 'B5.03', 'checkpoints' => [
    ['key' => 'mental_prayer', 'type' => 'habit', 'title' => 'Daily mental prayer', 'autotick' => 'view'],
    ['key' => 'scaffold', 'type' => 'TODO_pedagogy', 'title' => 'x'],
]];
$defs = def_sync::extract($lp);
check('extract.skips_todo', 1, count($defs));
check('extract.uid', 'B5.03.mental_prayer', $defs[0]['checkpoint_uid']);
// MF-2 at compile: a habit may not opt into auto-tick — forced back to none.
check('extract.mf2_habit_autotick_none', 'none', $defs[0]['autotick']);

// --- application-atom checkpoint (§2.3) also compiles to a def. ---------------
$lp2 = ['id' => 'A1.01', 'application' => [
    ['slot' => 'application', 'prompt_self' => true,
     'checkpoint' => ['key' => 'reflect', 'type' => 'task', 'title' => 'Reflect']],
]];
$d2 = def_sync::extract($lp2);
check('app_atom.uid', 'A1.01.reflect', $d2[0]['checkpoint_uid']);
check('app_atom.prompt_self', 1, $d2[0]['prompt_self']);

// A content-consumption task MAY keep autotick=view (only manual-only types forced).
$lp3 = ['id' => 'A1.02', 'checkpoints' => [
    ['key' => 'read', 'type' => 'task', 'title' => 'Read', 'autotick' => 'view'],
]];
$d3 = def_sync::extract($lp3);
check('task.autotick_view_kept', 'view', $d3[0]['autotick']);

// --- v3.3 6-type model: challenge/rule/suggested accepted; counsel skipped. ---
$lp4 = ['id' => 'B6.04', 'checkpoints' => [
    ['key' => 'practice', 'type' => 'challenge', 'title' => 'Decade week',
     'cadence' => 'daily', 'contributes_to' => 'rosary_decade', 'review_after_days' => 7,
     'autotick' => 'view'],
]];
$d4 = def_sync::extract($lp4)[0];
check('challenge.type', 'challenge', $d4['type']);
check('challenge.cadence', 'daily', $d4['cadence']);
check('challenge.contributes_to', 'rosary_decade', $d4['contributes_to']);
check('challenge.review_after_days', 7, $d4['review_after_days']);
// MF-2: a challenge is manual-only — autotick forced to none.
check('challenge.mf2_autotick_none', 'none', $d4['autotick']);

// habit with on_consolidate: promote + contributes_to.
$lp5 = ['id' => 'E4.03', 'checkpoints' => [
    ['key' => 'practice', 'type' => 'habit', 'title' => 'Little flowers',
     'on_consolidate' => 'promote', 'contributes_to' => 'little_flowers'],
]];
$d5 = def_sync::extract($lp5)[0];
check('habit.on_consolidate', 'promote', $d5['on_consolidate']);
check('habit.contributes_to', 'little_flowers', $d5['contributes_to']);

// suggested defaults adopts_as to task when unset; is manual-only.
$lp6 = ['id' => 'D5.04', 'checkpoints' => [
    ['key' => 'practice', 'type' => 'suggested', 'title' => 'Tell someone'],
]];
$d6 = def_sync::extract($lp6)[0];
check('suggested.adopts_as_default_task', 'task', $d6['adopts_as']);

// counsel is a DISPOSITION, not a type — def_sync SKIPS it (no def row).
$lp7 = ['id' => 'C1.01', 'checkpoints' => [
    ['key' => 'practice', 'type' => 'counsel', 'title' => 'Take heart'],
]];
check('counsel.skipped', 0, count(def_sync::extract($lp7)));

// --- discipline registry -> rule defs (minted once; uid = rule.<uid>). --------
$registry = ['disciplines' => [
    ['uid' => 'mental_prayer', 'title' => 'Daily mental prayer', 'cadence' => 'daily'],
    ['uid' => 'confession', 'title' => 'Monthly Confession', 'cadence' => 'monthly'],
]];
$rules = def_sync::disciplines_from_registry($registry);
check('registry.count', 2, count($rules));
check('registry.uid', 'rule.mental_prayer', $rules[0]['checkpoint_uid']);
check('registry.type_rule', 'rule', $rules[0]['type']);
check('registry.autotick_none', 'none', $rules[0]['autotick']);
check('registry.cadence', 'monthly', $rules[1]['cadence']);

// ---- Report ----------------------------------------------------------------
$total = $GLOBALS['__pass'] + $GLOBALS['__fail'];
echo "\nlocal_practice def_sync unit tests\n";
echo str_repeat('-', 40) . "\n";
if ($GLOBALS['__fail'] > 0) {
    echo implode("\n", $GLOBALS['__fails']) . "\n";
}
printf("%d/%d checks passed (%d failed)\n", $GLOBALS['__pass'], $total, $GLOBALS['__fail']);
exit($GLOBALS['__fail'] === 0 ? 0 : 1);
