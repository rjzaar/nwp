# NWC Trialing Guild scoring integration

The SS `local_feedback` plugin POSTs every submission and every mentor
review to an NWC endpoint so the user's **Tester Guild** score can be
updated. This file specifies what AVC needs on its side.

## Architecture

```
        ┌─────────────────────────────────┐                ┌─────────────────────────────────┐
        │   ss.nwpcode.org (Moodle)        │   HTTPS POST    │   avc.nwpcode.org (Drupal)       │
        │                                  ├────────────────►│                                  │
        │   local_feedback plugin          │   JSON payload   │   nwc_feedback / tester_guild    │
        │   - widget submit                │                  │   - resolve oauth_sub → user     │
        │   - mentor review                │                  │   - log feedback                 │
        │                                  │                  │   - credit Tester Guild score    │
        └─────────────────────────────────┘                  └─────────────────────────────────┘
```

The cross-site link is the OAuth2 `sub` (subject) claim, captured on SS
when the user signs in via `auth_nwc_oauth2` (already installed in the
v3 plugin set). SS stores it in `user_preferences` under
`auth_nwc_oauth2_sub`; the `local_feedback\forwarder` reads it for the
POST payload.

## What AVC needs to build

A single Drupal route + controller — call it `nwc_feedback_log` —
listening at `POST /api/feedback/log`.

### Request

- **Headers**:
  - `Authorization: Bearer <token>` — the shared secret configured at
    SS admin → Plugins → Local plugins → Feedback widget → AVC API token
  - `Content-Type: application/json`
- **Body** (see `README.md` for the full schema):
  ```json
  {
    "ss_feedback_id": 42,
    "ss_userid": 17,
    "username": "Rob Zaar",
    "email": "rjzaar@gmail.com",
    "oauth_sub": "abc123...",
    "type": "suggestion",
    "title": "Better progress markers on the J series",
    "body": "...",
    "target_url": "/course/view.php?id=47",
    "status": "submitted",
    "score": null,
    "timecreated": 1715900000,
    "gitlab_issue_url": "https://git.nwpcode.org/nwp/courses/-/issues/123"
  }
  ```

### Response

- **200** on success with body `{"ok": true, "nwc_feedback_id": <int>}`
- **401** if Bearer token invalid
- **400** if payload malformed
- **5xx** if AVC DB or upstream call failed

### Behaviour

| `status` value | AVC action |
|----------------|-----------|
| `submitted` | Insert a new `feedback_log` row. Link to the NWC user via `oauth_sub` → AVC user mapping. Score = 0. |
| `approved` | Find the existing `feedback_log` row by `ss_feedback_id`; mark it `approved`; credit `score` points to the user's Tester Guild record. |
| `implemented` | Same as `approved` but with bonus (already baked into the `score` value the SS side sends — 1.5× the `avc_score_default`). |
| `rejected` | Mark the existing row as `rejected`. No score change. If a previous approval had credited score, reverse it. |
| `duplicate` | Mark as `duplicate`. Refund any previously-awarded score for this feedback. |

## NWC Trialing Guild schema (suggested)

If AVC doesn't have a Tester Guild scoring schema yet, suggested minimal
Drupal entity / table:

```sql
CREATE TABLE avc_tester_guild_score (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,            -- AVC user id
    source VARCHAR(64) NOT NULL,        -- 'ss_feedback', 'manual', ...
    source_ref VARCHAR(128) NOT NULL,   -- e.g. 'ss_feedback:42'
    delta INT NOT NULL,                 -- points awarded (or refunded as negative)
    reason VARCHAR(255),                -- 'approved' / 'implemented' / 'reject-refund'
    awarded_by_user_id BIGINT,          -- reviewer (mentor)
    timecreated INT NOT NULL,
    UNIQUE (source, source_ref, reason)  -- idempotent: don't double-credit
);
```

The unique key on `(source, source_ref, reason)` makes the endpoint
idempotent — if SS retries a POST, AVC doesn't double-credit.

The Tester Guild member's total score is `SUM(delta) WHERE user_id = ?`.

## OAuth `sub` mapping

When `auth_nwc_oauth2` authenticates a user, it stores the OAuth2 `sub`
claim in two places:

1. **On AVC**: in the Drupal user's external authentication record (the
   standard OAuth2 module stores this in `users_field_data` or in a
   separate `external_auth` table — check your OAuth2 module install).
2. **On SS**: in Moodle's `user_preferences` table under `name =
   'auth_nwc_oauth2_sub'`.

Both sides have the same `sub` value for the same physical user, so AVC
can resolve `oauth_sub` from the SS POST to the right AVC `user_id`.

**If `oauth_sub` is null** (user signed up directly on SS without OAuth):
AVC should still log the submission for moderation purposes but cannot
credit a Tester Guild score. The mentor can still approve the feedback
on SS — just no score awarded.

## Auth + secrets

The Bearer token is a shared secret. Generate it once:

```bash
openssl rand -hex 32
```

Set it on both sides:
- **SS**: Site admin → Plugins → Local plugins → Feedback widget → AVC
  API token
- **AVC**: store hashed in Drupal config (e.g., `nwc_feedback.api_token_hash`)
  and verify on each request

Rotate quarterly or after any potential leak.

## Build order on NWC

1. Add a `feedback_log` entity in `nwc_feedback` (Drupal ContentEntityType)
   with the fields from the SS POST payload.
2. Add a Drupal route at `/api/feedback/log` POST, controller method
   `\Drupal\nwc_feedback\Controller\FeedbackLogController::log`.
3. Implement Bearer token verification.
4. Implement `oauth_sub` → AVC user resolver.
5. Implement scoring: insert/update `avc_tester_guild_score` row based on
   `status`.
6. Expose Tester Guild leaderboard at `/community/tester-guild` for AVC
   members to see their scores.

## Status

- **SS side**: ✅ built (`local_feedback`, this directory)
- **AVC side**: ❌ not yet built. The POST endpoint will fail silently
  on SS (logged via `debugging()`) until AVC implements it. The DB log
  on SS continues to work, so no submission is lost.

## Preservation note

This integration spec is canonical at
`~/dir/courses_v3/plugins/local/feedback/AVC_INTEGRATION.md`. When the
AVC side is built, it should be preserved similarly:

- AVC custom Drupal modules already live at
  `~/nwp/sites/avc/dev/html/profiles/custom/avc/modules/avc_features/`
  which is part of the NWC profile git tree (canonical).
- Add `nwc_feedback`'s `feedback_log` entity and the `/api/feedback/log`
  route alongside the existing `nwc_feedback.routing.yml`.
- The AVC profile is version-controlled, so changes propagate to every
  AVC site (dev, stg, test, live) via the standard nwp deploy path
  (`pl stg2live avc`).
