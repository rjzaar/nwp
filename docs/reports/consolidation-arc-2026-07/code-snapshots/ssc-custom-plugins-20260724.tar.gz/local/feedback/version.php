<?php
// Saint School local_feedback — floating feedback widget for SS Moodle.
// Mirrors avc_feedback's Drupal widget, with the same UX, persisted into
// a Moodle DB table and (optionally) forwarded to GitLab + AVC for
// cross-site Tester Guild scoring.
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_feedback';
$plugin->version   = 2026051704;
$plugin->release   = '0.1.0';
$plugin->requires  = 2024042200;   // Moodle 4.4
$plugin->maturity  = MATURITY_STABLE;
