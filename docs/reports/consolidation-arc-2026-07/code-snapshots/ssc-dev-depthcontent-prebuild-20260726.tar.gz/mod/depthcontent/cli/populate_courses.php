<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * CLI script to populate courses with depthcontent learning point activities.
 *
 * Reads JSON files from a specified directory and creates depthcontent
 * activity instances in the matching Moodle courses (matched by course shortname).
 *
 * Each JSON file becomes one activity instance in the corresponding course section.
 *
 * Usage:
 *   php populate_courses.php --jsondir=/path/to/json
 *   php populate_courses.php --jsondir=/path/to/json --course=A1
 *   php populate_courses.php --jsondir=/path/to/json --dry-run
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('CLI_SCRIPT', true);

require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/clilib.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/course/modlib.php');
require_once($CFG->dirroot . '/mod/depthcontent/lib.php');

list($options, $unrecognised) = cli_get_params([
    'jsondir' => '',
    'course' => '',
    'dry-run' => false,
    'help' => false,
    'clear' => false,
], [
    'j' => 'jsondir',
    'c' => 'course',
    'n' => 'dry-run',
    'h' => 'help',
]);

if ($options['help'] || empty($options['jsondir'])) {
    $help = <<<EOT
Populate Moodle courses with depthcontent learning point activities.

Options:
  --jsondir=PATH     Directory containing learning point JSON files (required)
  --course=CODE      Only populate this course (e.g., A1). Default: all.
  --dry-run, -n      Show what would be done without making changes
  --clear            Remove existing depthcontent instances before populating
  -h, --help         Show this help

Examples:
  php populate_courses.php --jsondir=/tmp/lp-json
  php populate_courses.php --jsondir=/tmp/lp-json --course=A1
  php populate_courses.php --jsondir=/tmp/lp-json --dry-run
  php populate_courses.php --jsondir=/tmp/lp-json --clear

EOT;
    cli_writeln($help);
    exit(0);
}

$jsondir = $options['jsondir'];
if (!is_dir($jsondir)) {
    cli_error("JSON directory not found: $jsondir");
}

// Get the module ID for depthcontent.
$module = $DB->get_record('modules', ['name' => 'depthcontent']);
if (!$module) {
    cli_error("mod_depthcontent is not installed. Run the Moodle upgrade first.");
}

$dryrun = !empty($options['dry-run']);
$clearfirst = !empty($options['clear']);
$coursefilter = $options['course'] ?: '';

// Gather JSON files grouped by course code.
$files = glob("$jsondir/*.json");
if (empty($files)) {
    cli_error("No JSON files found in $jsondir");
}

$bycourse = [];
foreach ($files as $file) {
    $basename = basename($file, '.json');
    // Point ID format: A1.01 -> course code is everything before the last dot.
    $parts = explode('.', $basename);
    if (count($parts) < 2) {
        continue;
    }
    $coursecode = $parts[0];
    if ($coursefilter && $coursecode !== $coursefilter) {
        continue;
    }
    $bycourse[$coursecode][] = $file;
}

ksort($bycourse);
cli_writeln("Found " . count($files) . " JSON files across " . count($bycourse) . " courses.");

$created = 0;
$skipped = 0;
$errors = 0;

foreach ($bycourse as $coursecode => $coursefiles) {
    // Find the Moodle course by shortname.
    $course = $DB->get_record('course', ['shortname' => $coursecode]);
    if (!$course) {
        cli_writeln("  SKIP $coursecode — no matching Moodle course");
        $skipped += count($coursefiles);
        continue;
    }

    cli_writeln("\n--- $coursecode: {$course->fullname} (id={$course->id}) ---");

    // Sort files by point number.
    usort($coursefiles, function($a, $b) {
        return strcmp(basename($a), basename($b));
    });

    foreach ($coursefiles as $file) {
        $json = file_get_contents($file);
        $data = json_decode($json, true);
        if (!$data) {
            cli_writeln("  ERROR: Invalid JSON in " . basename($file));
            $errors++;
            continue;
        }

        $pointid = $data['id'] ?? basename($file, '.json');
        $title = $data['title'] ?? $pointid;
        $session = intval($data['session'] ?? 1);

        // Check if this point already exists in this course.
        $existing = $DB->get_record('depthcontent', [
            'course' => $course->id,
            'pointid' => $pointid,
        ]);
        if ($existing) {
            if ($clearfirst) {
                // Update in place rather than delete+recreate.
                $existing->content_json = $json;
                $existing->name = $title;
                $existing->timemodified = time();
                $DB->update_record('depthcontent', $existing);
                cli_writeln("  UPD $pointid — $title (id={$existing->id})");
                $created++;
                continue;
            }
            cli_writeln("  SKIP $pointid — already exists (id={$existing->id})");
            $skipped++;
            continue;
        }

        if ($dryrun) {
            cli_writeln("  [DRY] Would create: $pointid — $title (section $session)");
            $created++;
            continue;
        }

        // Create the activity instance.
        $moduleinfo = new stdClass();
        $moduleinfo->modulename = 'depthcontent';
        $moduleinfo->module = $module->id;
        $moduleinfo->course = $course->id;
        $moduleinfo->section = $session; // Section = session number.
        // Default-HIDDEN (2026-07-21): LPs are not public until their course
        // passes the NWC guild workflow (local/nwc_publish_sync flips course
        // visibility on approval). See create_v3_courses.php.
        $moduleinfo->visible = 0;
        $moduleinfo->visibleoncoursepage = 0;
        $moduleinfo->name = $title;
        $moduleinfo->intro = '';
        $moduleinfo->introformat = FORMAT_HTML;
        $moduleinfo->pointid = $pointid;
        $moduleinfo->content_json = $json;

        // Required fields for add_moduleinfo().
        $moduleinfo->cmidnumber = '';
        $moduleinfo->groupmode = 0;
        $moduleinfo->groupingid = 0;
        $moduleinfo->showdescription = 0;
        $moduleinfo->completion = COMPLETION_TRACKING_AUTOMATIC;
        $moduleinfo->completionview = 1;
        $moduleinfo->completionpassgrade = 0;
        $moduleinfo->completiongradeitemnumber = null;
        $moduleinfo->completionexpected = 0;

        try {
            $result = add_moduleinfo($moduleinfo, $course);
            cli_writeln("  OK $pointid — {$title} (cmid={$result->coursemodule})");
            $created++;
        } catch (Exception $e) {
            cli_writeln("  ERROR $pointid — " . $e->getMessage());
            $errors++;
        }
    }
}

cli_writeln("\n=== Summary ===");
cli_writeln("Created: $created");
cli_writeln("Skipped: $skipped");
cli_writeln("Errors:  $errors");
if ($dryrun) {
    cli_writeln("(Dry run — no changes made)");
}
