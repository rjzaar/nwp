<?php
/**
 * local_nwc_copyright_sync\policy_writer — publishes a new
 * tool_policy version from NWC-supplied canonical text.
 *
 * Implemented on tool_policy's own api (form_policydoc_add /
 * form_policydoc_update_new / make_current) rather than raw table
 * writes: {tool_policy} holds only id/sortorder/currentversionid in
 * Moodle 4.4 — name/type/content live on {tool_policy_versions}, and
 * make_current() is what drives forced re-acceptance.
 *
 * Slug → policy id mapping (e.g. 'site_terms' → 3) is kept in plugin
 * config ('policyid_<slug>'), since tool_policy has no stable
 * machine-name of its own.
 */
namespace local_nwc_copyright_sync;

use tool_policy\api;
use tool_policy\policy_version;

defined('MOODLE_INTERNAL') || die();

class policy_writer {

    const COMPONENT = 'local_nwc_copyright_sync';

    /**
     * Publish canonical text as the current active version of the
     * policy identified by $policy_name, creating the policy document
     * on first sync. Users are re-prompted via tool_policy natively.
     *
     * @return array{ok:bool, policy_id:int, ss_version_id:int}
     */
    public static function publish(
        string $policy_name,
        string $title,
        string $type,
        string $body_md,
        ?string $effective_date,
        ?string $change_summary,
    ): array {
        global $DB;

        $form = (object) [
            'name' => $title,
            'type' => self::resolve_policy_type($type),
            'audience' => policy_version::AUDIENCE_ALL,
            'optional' => 0,
            'agreementstyle' => 0,
            'revision' => 'v' . self::format_revision_date($effective_date),
            'summary_editor' => [
                'text' => s($change_summary ?? ''),
                'format' => FORMAT_HTML,
                'itemid' => 0,
            ],
            'content_editor' => [
                'text' => self::md_to_html($body_md),
                'format' => FORMAT_HTML,
                'itemid' => 0,
            ],
        ];

        $policyid = (int) get_config(self::COMPONENT, 'policyid_' . $policy_name);
        if ($policyid && $DB->record_exists('tool_policy', ['id' => $policyid])) {
            // Idempotency: if the current version already carries this
            // exact revision + content, do NOT publish a new version —
            // every new current version forces sitewide re-acceptance.
            $current = $DB->get_record_sql(
                'SELECT v.id, v.name, v.revision, v.content
                   FROM {tool_policy} p
                   JOIN {tool_policy_versions} v ON v.id = p.currentversionid
                  WHERE p.id = ?', [$policyid]);
            if ($current
                && $current->name === $form->name
                && $current->revision === $form->revision
                && $current->content === $form->content_editor['text']) {
                return [
                    'ok' => true,
                    'action' => 'unchanged',
                    'policy_id' => $policyid,
                    'ss_version_id' => (int) $current->id,
                ];
            }
            $form->policyid = $policyid;
            $version = api::form_policydoc_update_new($form);
        } else {
            $version = api::form_policydoc_add($form);
            $policyid = (int) $version->get('policyid');
            set_config('policyid_' . $policy_name, $policyid, self::COMPONENT);
        }

        api::make_current((int) $version->get('id'));

        return [
            'ok' => true,
            'policy_id' => $policyid,
            'ss_version_id' => (int) $version->get('id'),
        ];
    }

    /**
     * The sender may pass a Y-m-d string or a unix timestamp; render
     * either as Y-m-d, falling back to today.
     */
    private static function format_revision_date(?string $effective_date): string {
        if ($effective_date === null || $effective_date === '') {
            return date('Y-m-d');
        }
        if (ctype_digit($effective_date)) {
            return date('Y-m-d', (int) $effective_date);
        }
        return $effective_date;
    }

    private static function resolve_policy_type(string $type): int {
        // tool_policy types: 0=site, 1=privacy, 2=third-party, 99=other
        return match (strtolower($type)) {
            'site'        => 0,
            'privacy'     => 1,
            'third_party' => 2,
            default       => 99,
        };
    }

    /**
     * Light-weight markdown → HTML. Avoids a hard dependency on a full
     * markdown library; converts headings/paragraphs/lists/code in a
     * predictable way. For richer rendering, install
     * `michelf/php-markdown` and replace this method.
     */
    private static function md_to_html(string $md): string {
        $lines = preg_split("/\r?\n/", $md);
        $out = [];
        $in_ul = false;
        $in_pre = false;
        foreach ($lines as $ln) {
            if (preg_match('/^```/', $ln)) {
                $in_pre = !$in_pre;
                $out[] = $in_pre ? '<pre><code>' : '</code></pre>';
                continue;
            }
            if ($in_pre) {
                $out[] = htmlspecialchars($ln);
                continue;
            }
            if (preg_match('/^(\#{1,6})\s+(.+)$/', $ln, $m)) {
                $level = strlen($m[1]);
                if ($in_ul) { $out[] = '</ul>'; $in_ul = false; }
                $out[] = sprintf('<h%d>%s</h%d>', $level, htmlspecialchars($m[2]), $level);
                continue;
            }
            if (preg_match('/^\s*[-*]\s+(.+)$/', $ln, $m)) {
                if (!$in_ul) { $out[] = '<ul>'; $in_ul = true; }
                $out[] = '<li>' . htmlspecialchars($m[1]) . '</li>';
                continue;
            }
            if (trim($ln) === '') {
                if ($in_ul) { $out[] = '</ul>'; $in_ul = false; }
                $out[] = '';
                continue;
            }
            $out[] = '<p>' . htmlspecialchars($ln) . '</p>';
        }
        if ($in_ul) $out[] = '</ul>';
        if ($in_pre) $out[] = '</code></pre>';
        return implode("\n", $out);
    }

}
