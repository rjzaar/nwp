/**
 * @module     local_feedback/widget
 * @description Floating feedback button + popup, mirroring avc_feedback's UX.
 */
define([], function() {
    'use strict';

    function init(config) {
        var submitUrl = config.submitUrl;
        var boardUrl = config.boardUrl;
        var sesskey = config.sesskey;
        var isLoggedIn = config.isLoggedIn;
        var s = config.strings;

        // ── Trigger button ───────────────────────────────────────────
        var trigger = document.createElement('button');
        trigger.className = 'local-feedback-trigger';
        trigger.setAttribute('type', 'button');
        trigger.setAttribute('aria-label', s.title);
        trigger.setAttribute('title', s.title);
        trigger.innerHTML =
            '<svg class="local-feedback-trigger__icon" viewBox="0 0 24 24" fill="none"' +
            ' stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>' +
            '</svg>';
        document.body.appendChild(trigger);

        // ── Popup ────────────────────────────────────────────────────
        var popup = document.createElement('div');
        popup.className = 'local-feedback-popup';
        popup.setAttribute('role', 'dialog');
        popup.setAttribute('aria-labelledby', 'local-feedback-popup-title');
        popup.innerHTML =
            '<div class="local-feedback-popup__header">' +
                '<span class="local-feedback-popup__title" id="local-feedback-popup-title">' + s.title + '</span>' +
                '<button class="local-feedback-popup__close" type="button" aria-label="Close">&times;</button>' +
            '</div>' +
            '<div class="local-feedback-popup__body">' +
                '<div class="local-feedback-popup__types" role="radiogroup" aria-label="Feedback type">' +
                    '<button type="button" class="local-feedback-popup__type-btn local-feedback-popup__type-btn--active" data-type="suggestion" role="radio" aria-checked="true">' + s.type_sug + '</button>' +
                    '<button type="button" class="local-feedback-popup__type-btn" data-type="question" role="radio" aria-checked="false">' + s.type_qu + '</button>' +
                    '<button type="button" class="local-feedback-popup__type-btn" data-type="issue" role="radio" aria-checked="false">' + s.type_iss + '</button>' +
                    '<button type="button" class="local-feedback-popup__type-btn" data-type="praise" role="radio" aria-checked="false">' + s.type_pr + '</button>' +
                '</div>' +
                '<input class="local-feedback-popup__input" type="text" placeholder="' + s.ph_title + '" maxlength="255" aria-label="' + s.ph_title + '" />' +
                '<textarea class="local-feedback-popup__textarea" placeholder="' + s.ph_body + '" rows="3" aria-label="' + s.ph_body + '"></textarea>' +
                '<button type="button" class="local-feedback-popup__submit">' + s.submit + '</button>' +
            '</div>' +
            '<div class="local-feedback-popup__message" role="status" aria-live="polite"></div>' +
            '<div class="local-feedback-popup__footer">' +
                '<a href="' + boardUrl + '">' + s.view_board + '</a>' +
            '</div>';
        document.body.appendChild(popup);

        // ── Refs ─────────────────────────────────────────────────────
        var closeBtn = popup.querySelector('.local-feedback-popup__close');
        var typeBtns = popup.querySelectorAll('.local-feedback-popup__type-btn');
        var titleInput = popup.querySelector('.local-feedback-popup__input');
        var bodyInput = popup.querySelector('.local-feedback-popup__textarea');
        var submitBtn = popup.querySelector('.local-feedback-popup__submit');
        var message = popup.querySelector('.local-feedback-popup__message');
        var bodyDiv = popup.querySelector('.local-feedback-popup__body');
        var selectedType = 'suggestion';

        function togglePopup(open) {
            if (typeof open !== 'boolean') {
                open = !popup.classList.contains('local-feedback-popup--open');
            }
            popup.classList.toggle('local-feedback-popup--open', open);
            trigger.classList.toggle('local-feedback-trigger--active', open);
            if (open) titleInput.focus();
        }

        function showMessage(text, isSuccess) {
            message.textContent = text;
            message.className = 'local-feedback-popup__message ' +
                (isSuccess ? 'local-feedback-popup__message--success' : 'local-feedback-popup__message--error');
            message.style.display = 'block';
        }

        // ── Events ───────────────────────────────────────────────────
        trigger.addEventListener('click', function() { togglePopup(); });
        closeBtn.addEventListener('click', function() { togglePopup(false); });

        // Close on Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && popup.classList.contains('local-feedback-popup--open')) {
                togglePopup(false);
                trigger.focus();
            }
        });

        typeBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                typeBtns.forEach(function(b) {
                    b.classList.remove('local-feedback-popup__type-btn--active');
                    b.setAttribute('aria-checked', 'false');
                });
                btn.classList.add('local-feedback-popup__type-btn--active');
                btn.setAttribute('aria-checked', 'true');
                selectedType = btn.getAttribute('data-type');
            });
        });

        submitBtn.addEventListener('click', function() {
            var title = titleInput.value.trim();
            if (!title) {
                titleInput.focus();
                return;
            }

            submitBtn.disabled = true;
            submitBtn.textContent = s.submitting;

            var data = new FormData();
            data.append('type', selectedType);
            data.append('title', title);
            data.append('body', bodyInput.value.trim());
            data.append('target_url', window.location.pathname + window.location.search);
            data.append('sesskey', sesskey);

            fetch(submitUrl, {
                method: 'POST',
                body: data,
                credentials: 'same-origin'
            })
            .then(function(response) { return response.json(); })
            .then(function(result) {
                if (result && result.success) {
                    showMessage(s.thanks, true);
                    bodyDiv.style.display = 'none';
                    setTimeout(function() {
                        togglePopup(false);
                        titleInput.value = '';
                        bodyInput.value = '';
                        message.style.display = 'none';
                        bodyDiv.style.display = 'block';
                        submitBtn.disabled = false;
                        submitBtn.textContent = s.submit;
                    }, 1800);
                } else {
                    showMessage((result && result.message) || s.error, false);
                    submitBtn.disabled = false;
                    submitBtn.textContent = s.submit;
                    setTimeout(function() { message.style.display = 'none'; }, 3000);
                }
            })
            .catch(function() {
                showMessage(s.error, false);
                submitBtn.disabled = false;
                submitBtn.textContent = s.submit;
            });
        });
    }

    return { init: init };
});
