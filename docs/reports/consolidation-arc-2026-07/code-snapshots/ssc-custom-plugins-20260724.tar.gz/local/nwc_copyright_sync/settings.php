<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage(
        'local_nwc_copyright_sync',
        new lang_string('pluginname', 'local_nwc_copyright_sync')
    );

    $ADMIN->add('localplugins', $settings);

    $settings->add(new admin_setting_configcheckbox(
        'local_nwc_copyright_sync/enabled',
        new lang_string('setting_enabled', 'local_nwc_copyright_sync'),
        new lang_string('setting_enabled_desc', 'local_nwc_copyright_sync'),
        0
    ));

    $settings->add(new admin_setting_configpasswordunmask(
        'local_nwc_copyright_sync/admin_token',
        new lang_string('setting_admin_token', 'local_nwc_copyright_sync'),
        new lang_string('setting_admin_token_desc', 'local_nwc_copyright_sync'),
        ''
    ));

    // Optional: restrict to the NWC server's IP.
    $settings->add(new admin_setting_configtext(
        'local_nwc_copyright_sync/allowed_ips',
        new lang_string('setting_allowed_ips', 'local_nwc_copyright_sync'),
        new lang_string('setting_allowed_ips_desc', 'local_nwc_copyright_sync'),
        '',
        PARAM_RAW
    ));
}
