<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Submit credit-by-examination results.
 *
 * Receives per-point pass/fail data and updates:
 * - depthcontent_progress: status → 'mastered', mastered_via → 'examination' for passed points.
 * - depthcontent_sr: interval_days → 7, next_review set accordingly for passed points.
 * - depthcontent_progress: status → 'learning' for failed points (if currently 'new').
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_depthcontent\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;

class submit_review extends external_api {

    /**
     * Parameter definitions.
     */
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid' => new external_value(PARAM_INT, 'Course ID'),
            'pointresults' => new external_value(PARAM_RAW, 'JSON array of per-point results'),
        ]);
    }

    /**
     * Process examination results.
     *
     * @param int $courseid
     * @param string $pointresults JSON string: [{ depthcontentid, correct, total, passed }]
     * @return array
     */
    public static function execute(int $courseid, string $pointresults): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid' => $courseid,
            'pointresults' => $pointresults,
        ]);

        $context = \context_course::instance($params['courseid']);
        self::validate_context($context);

        require_once($GLOBALS['CFG']->dirroot . '/mod/depthcontent/lib.php');

        // ops#118 Art. 9 consent gate: a Trialing (non-consented) member's
        // credit-by-examination results (progress / spaced-repetition / response
        // summaries) are special-category formation data. Acknowledge the
        // submission but persist NOTHING. Fail closed on unproven consent.
        if (!depthcontent_may_keep_formation($USER->id)) {
            debugging('depthcontent: submit_review ephemeral (no Art.9 consent) '
                . 'userid=' . $USER->id, DEBUG_DEVELOPER);
            return ['success' => true, 'passed' => 0, 'failed' => 0];
        }

        $results = json_decode($params['pointresults'], true);
        if (!is_array($results)) {
            throw new \invalid_parameter_exception('pointresults must be a valid JSON array');
        }

        $userid = $USER->id;
        $now = time();
        $passedcount = 0;
        $failedcount = 0;

        foreach ($results as $result) {
            $depthcontentid = (int) ($result['depthcontentid'] ?? 0);
            $passed = !empty($result['passed']);
            $correct = (int) ($result['correct'] ?? 0);
            $total = (int) ($result['total'] ?? 0);

            if ($depthcontentid <= 0) {
                continue;
            }

            // Verify this depthcontent belongs to the specified course.
            $dc = $DB->get_record('depthcontent', ['id' => $depthcontentid, 'course' => $params['courseid']]);
            if (!$dc) {
                continue;
            }

            // Get or create progress record.
            $progress = depthcontent_get_progress($userid, $depthcontentid);

            if ($passed) {
                // Mark as mastered via examination.
                $progress->status = 'mastered';
                $progress->mastered_via = 'examination';
                $progress->timemodified = $now;
                $DB->update_record('depthcontent_progress', $progress);

                // Set up spaced repetition: start at 7-day interval.
                $sr = depthcontent_get_sr_state($userid, $depthcontentid);
                if (!$sr) {
                    $sr = new \stdClass();
                    $sr->userid = $userid;
                    $sr->depthcontentid = $depthcontentid;
                    $sr->ease_factor = 2.50;
                    $sr->repetitions = 0;
                }

                $sr->interval_days = 7;
                $sr->repetitions = 1;
                $sr->next_review = $now + (7 * 86400);
                $sr->last_reviewed = $now;

                if (isset($sr->id)) {
                    $DB->update_record('depthcontent_sr', $sr);
                } else {
                    $sr->id = $DB->insert_record('depthcontent_sr', $sr);
                }

                $passedcount++;
            } else {
                // Failed: set status to 'learning' if currently 'new', leave as-is otherwise.
                if ($progress->status === 'new') {
                    $progress->status = 'learning';
                    $progress->timemodified = $now;
                    $DB->update_record('depthcontent_progress', $progress);
                }

                $failedcount++;
            }

            // Record individual question responses for analytics.
            // Store a summary response for the examination attempt.
            $response = new \stdClass();
            $response->userid = $userid;
            $response->depthcontentid = $depthcontentid;
            $response->quizitemid = 'examination';
            $response->response = json_encode([
                'correct' => $correct,
                'total' => $total,
                'passed' => $passed,
                'mode' => 'examination',
            ]);
            $response->correct = $passed ? 1 : 0;
            $response->timecreated = $now;
            $DB->insert_record('depthcontent_responses', $response);
        }

        return [
            'success' => true,
            'passed' => $passedcount,
            'failed' => $failedcount,
        ];
    }

    /**
     * Return value definitions.
     */
    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Whether results were recorded'),
            'passed' => new external_value(PARAM_INT, 'Number of points that passed'),
            'failed' => new external_value(PARAM_INT, 'Number of points that failed'),
        ]);
    }
}
