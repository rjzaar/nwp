<?php
/**
 * local_feedback hook callbacks (Moodle 4.4+).
 * Injects the floating feedback widget at the end of every page body.
 */
namespace local_feedback;

defined('MOODLE_INTERNAL') || die();

class hook_callbacks {

    /**
     * Should the widget render on this request?
     */
    private static function should_render(): bool {
        $enabled = get_config('local_feedback', 'enabled');
        if (!$enabled) {
            return false;
        }
        $loggedinonly = (bool)get_config('local_feedback', 'logged_in_only');
        $isloggedin = isloggedin() && !isguestuser();
        if ($loggedinonly && !$isloggedin) {
            return false;
        }
        // Skip on the widget endpoints + CLI.
        $skip_paths = ['/local/feedback/submit.php', '/admin/cli/'];
        $ruri = $_SERVER['REQUEST_URI'] ?? '';
        foreach ($skip_paths as $p) {
            if (strpos($ruri, $p) !== false) {
                return false;
            }
        }
        // Capability check (logged-in users only — guests bypass).
        if ($isloggedin && !has_capability('local/feedback:submit', \context_system::instance())) {
            return false;
        }
        return true;
    }

    /**
     * Register the CSS — fires during <head> rendering (head hook, not footer).
     */
    public static function before_head(\core\hook\output\before_standard_head_html_generation $hook): void {
        global $PAGE;
        if (!self::should_render()) {
            return;
        }
        $PAGE->requires->css(new \moodle_url('/local/feedback/styles.css'));
    }

    /**
     * Add the floating widget HTML + AMD loader to the page footer.
     */
    public static function before_footer(\core\hook\output\before_footer_html_generation $hook): void {
        global $PAGE, $USER;

        if (!self::should_render()) {
            return;
        }

        $isloggedin = isloggedin() && !isguestuser();
        $submiturl = (new \moodle_url('/local/feedback/submit.php'))->out(false);
        $boardurl  = (new \moodle_url('/local/feedback/index.php'))->out(false);

        $strings = [
            'title'         => get_string('widget_title', 'local_feedback'),
            'type_sug'      => get_string('widget_type_suggestion', 'local_feedback'),
            'type_qu'       => get_string('widget_type_question', 'local_feedback'),
            'type_iss'      => get_string('widget_type_issue', 'local_feedback'),
            'type_pr'       => get_string('widget_type_praise', 'local_feedback'),
            'ph_title'      => get_string('widget_title_placeholder', 'local_feedback'),
            'ph_body'       => get_string('widget_body_placeholder', 'local_feedback'),
            'submit'        => get_string('widget_submit', 'local_feedback'),
            'submitting'    => get_string('widget_submitting', 'local_feedback'),
            'thanks'        => get_string('widget_thanks', 'local_feedback'),
            'error'         => get_string('widget_error', 'local_feedback'),
            'view_board'    => get_string('widget_view_board', 'local_feedback'),
            'login_required'=> get_string('widget_login_required', 'local_feedback'),
        ];

        // Inline the widget directly instead of going through Moodle's AMD
        // pipeline. AMD modules sometimes get cached aggressively or
        // pre-processed; inlining guarantees the button code runs.
        $config_json = json_encode([
            'submitUrl' => $submiturl,
            'boardUrl'  => $boardurl,
            'sesskey'   => sesskey(),
            'isLoggedIn'=> $isloggedin,
            'strings'   => $strings,
        ]);

        $widget_js = file_get_contents(__DIR__ . '/../amd/src/widget.js');
        // Strip the AMD define() wrapper to convert to plain IIFE
        $widget_js = preg_replace('/^define\(\[\],\s*function\(\)\s*\{/m', '(function() {', $widget_js);
        $widget_js = preg_replace('/\}\);\s*$/', '})();', $widget_js);
        // Replace `return { init: init };` with a direct call
        $widget_js = preg_replace(
            '/return\s*\{\s*init:\s*init\s*\};?/',
            'init(' . $config_json . ');',
            $widget_js
        );

        $hook->add_html(
            '<div id="local-feedback-widget-root" aria-hidden="true"></div>' .
            "\n<script>\n" . $widget_js . "\n</script>"
        );
    }
}
