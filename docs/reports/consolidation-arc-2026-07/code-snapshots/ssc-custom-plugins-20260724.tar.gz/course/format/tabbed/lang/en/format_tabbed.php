<?php
$string['pluginname'] = 'Tabbed format';
$string['currentsection'] = 'This session';
$string['sectionname'] = 'Session';
$string['section0name'] = 'General';
$string['hidefromothers'] = 'Hide session';
$string['showfromothers'] = 'Show session';
$string['privacy:metadata'] = 'The Tabbed format plugin does not store any personal data.';
