<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Message providers for local_practice.
 *
 * The daily nudge (mirrors mod_depthcontent/reviewreminder) rides the Moodle
 * Message API — popup + email + airnotifier push for free. Opt-in, default OFF.
 *
 * PRIVACY (GDPR §3): the nudge payload MUST be content-neutral — a generic
 * greeting + a bare authenticated deep-link to the member's plan. NEVER a
 * checkpoint name, book title, or reflection on a lock screen or in an email
 * body (that would disclose Art. 9 religious-practice data over channels the
 * member does not fully control).
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$messageproviders = [
    'practicenudge' => [
        'defaults' => [
            // Opt-in, default OFF (Q-P). Content-neutral payload only.
            'popup' => MESSAGE_PERMITTED,
            'email' => MESSAGE_PERMITTED,
        ],
    ],
];
