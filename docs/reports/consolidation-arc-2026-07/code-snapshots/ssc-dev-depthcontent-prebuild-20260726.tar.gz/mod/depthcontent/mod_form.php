<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Instance configuration form for mod_depthcontent.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/course/moodleform_mod.php');

class mod_depthcontent_mod_form extends moodleform_mod {

    public function definition() {
        $mform = $this->_form;

        // General section.
        $mform->addElement('header', 'general', get_string('general', 'form'));

        $mform->addElement('text', 'name', get_string('name'), ['size' => '64']);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');

        $this->standard_intro_elements();

        // Learning point ID.
        $mform->addElement('text', 'pointid', 'Learning Point ID', ['size' => '20']);
        $mform->setType('pointid', PARAM_ALPHANUMEXT);
        $mform->addHelpButton('pointid', 'pointid', 'depthcontent');
        $mform->addRule('pointid', null, 'required', null, 'client');

        // Content JSON (all depth levels + quiz items).
        $mform->addElement('textarea', 'content_json', 'Content (JSON)', [
            'rows' => 20,
            'cols' => 80,
        ]);
        $mform->setType('content_json', PARAM_RAW);

        // Standard course module elements.
        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        if (!empty($data['content_json'])) {
            $decoded = json_decode($data['content_json']);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $errors['content_json'] = 'Invalid JSON: ' . json_last_error_msg();
            }
        }

        return $errors;
    }
}
