<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * List all depthcontent instances in a course.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');

$id = required_param('id', PARAM_INT); // Course ID.
$course = $DB->get_record('course', ['id' => $id], '*', MUST_EXIST);

require_course_login($course);
$PAGE->set_url('/mod/depthcontent/index.php', ['id' => $id]);
$PAGE->set_title($course->shortname . ': ' . get_string('modulenameplural', 'depthcontent'));
$PAGE->set_heading($course->fullname);

echo $OUTPUT->header();

$depthcontents = get_all_instances_in_course('depthcontent', $course);

if (empty($depthcontents)) {
    notice(get_string('thereareno', 'moodle', get_string('modulenameplural', 'depthcontent')),
           new moodle_url('/course/view.php', ['id' => $course->id]));
}

$table = new html_table();
$table->head = ['Name', 'Learning Point', 'Description'];
$table->align = ['left', 'left', 'left'];

foreach ($depthcontents as $dc) {
    $link = html_writer::link(
        new moodle_url('/mod/depthcontent/view.php', ['id' => $dc->coursemodule]),
        format_string($dc->name)
    );
    $table->data[] = [$link, $dc->pointid, format_text($dc->intro, $dc->introformat)];
}

echo html_writer::table($table);
echo $OUTPUT->footer();
