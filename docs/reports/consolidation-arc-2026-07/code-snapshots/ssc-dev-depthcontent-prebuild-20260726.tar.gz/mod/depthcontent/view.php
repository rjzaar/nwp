<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * View a depthcontent learning point.
 *
 * Quiz items are scattered through content at their matching depth level
 * (inline mode), grouped at the end (end mode), or both.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');
require_once($CFG->dirroot . '/mod/depthcontent/lib.php');

$id = optional_param('id', 0, PARAM_INT);       // Course module ID.
$d  = optional_param('d', 0, PARAM_INT);        // Instance ID.
$depth = optional_param('depth', '', PARAM_ALPHA); // Override depth for this view.
$setquizstyle = optional_param('quizstyle', '', PARAM_ALPHA); // Quiz placement change.

if ($d) {
    $depthcontent = $DB->get_record('depthcontent', ['id' => $d], '*', MUST_EXIST);
    $cm = get_coursemodule_from_instance('depthcontent', $depthcontent->id, $depthcontent->course, false, MUST_EXIST);
} else {
    $cm = get_coursemodule_from_id('depthcontent', $id, 0, false, MUST_EXIST);
    $depthcontent = $DB->get_record('depthcontent', ['id' => $cm->instance], '*', MUST_EXIST);
}

$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);

require_course_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/depthcontent:view', $context);

$isloggedinuser = isloggedin() && !isguestuser();

// Handle depth preference change via URL parameter (non-JS fallback).
if ($depth && $isloggedinuser) {
    depthcontent_set_user_depth($USER->id, $depth);
}

// Handle quiz style preference change via URL parameter (non-JS fallback).
$validquizstyles = ['inline', 'end'];
if ($setquizstyle && $isloggedinuser && in_array($setquizstyle, $validquizstyles)) {
    set_user_preference('mod_depthcontent_quizstyle', $setquizstyle);
}

// Handle number-of-questions preference via URL parameter.
$setquizcount = optional_param('quizcount', '', PARAM_ALPHANUMEXT);
$validquizcounts = ['1', '2', '3', 'all'];
if ($setquizcount && $isloggedinuser && in_array($setquizcount, $validquizcounts)) {
    set_user_preference('mod_depthcontent_quizcount', $setquizcount);
}

// Trigger view event + completion.
depthcontent_view($depthcontent, $course, $cm, $context);

// Determine effective depth using the new resolver.
if ($isloggedinuser) {
    $urloverride = ($depth && in_array($depth, depthcontent_get_depth_levels())) ? $depth : null;
    $userdepth = depthcontent_resolve_effective_depth($USER->id, $depthcontent->id, $urloverride);
    $rememberpref = depthcontent_get_remember_preference($USER->id);
    $quizstyle = get_user_preferences('mod_depthcontent_quizstyle', 'inline', $USER->id);
    if (!in_array($quizstyle, $validquizstyles)) {
        $quizstyle = 'inline';
    }
} else {
    $userdepth = DEPTHCONTENT_DEPTH_STANDARD;
    $rememberpref = true;
    $quizstyle = 'inline';
}

// Decode content.
$content = json_decode($depthcontent->content_json, true);
if (!$content) {
    $content = ['depths' => [], 'quiz_items' => [], 'practice' => null];
}

// Build template data.
$depths = $content['depths'] ?? [];
$quizitems = $content['quiz_items'] ?? [];
$practice = $content['practice'] ?? null;
$depthorder = depthcontent_get_depth_levels();

// ── Map quiz items to depth levels by difficulty ──
// Each difficulty maps to its corresponding depth section:
//   standard -> standard, longer -> longer, detailed -> detailed, advanced -> advanced.
$difficultytodepth = [
    'standard' => DEPTHCONTENT_DEPTH_STANDARD,
    'longer'   => DEPTHCONTENT_DEPTH_LONGER,
    'detailed' => DEPTHCONTENT_DEPTH_DETAILED,
    'advanced' => DEPTHCONTENT_DEPTH_ADVANCED,
];
$quizitemsbydepth = [];
foreach ($quizitems as $idx => $item) {
    $difficulty = $item['difficulty'] ?? 'standard';
    $mappeddepth = $difficultytodepth[$difficulty] ?? DEPTHCONTENT_DEPTH_STANDARD;
    $quizitemsbydepth[$mappeddepth][] = ['index' => $idx, 'item' => $item, 'mindepth' => $mappeddepth];
}

// ── Number of questions preference ──
$quizcount = 'all';
if ($isloggedinuser) {
    $quizcount = get_user_preferences('mod_depthcontent_quizcount', 'all', $USER->id);
    if (!in_array($quizcount, ['1', '2', '3', 'all'])) {
        $quizcount = 'all';
    }
}
// Apply the limit: trim each depth section's quiz items.
if ($quizcount !== 'all') {
    $limit = (int) $quizcount;
    foreach ($quizitemsbydepth as $dlevel => $items) {
        $quizitemsbydepth[$dlevel] = array_slice($items, 0, $limit);
    }
}

/**
 * Render markdown text, preserving <details> HTML blocks.
 *
 * Moodle's FORMAT_MARKDOWN strips unrecognised HTML tags. This function
 * extracts <details> blocks before markdown processing and re-inserts them.
 *
 * @param string $text Raw markdown text that may contain <details> blocks.
 * @return string Rendered HTML.
 */
/**
 * Sanitise a raw <details> HTML block before it is re-inserted into rendered
 * output.
 *
 * The block deliberately bypasses format_text() (so its HTML survives markdown
 * processing), which means the author's raw HTML would otherwise reach the page
 * unsanitised — a stored-XSS vector (ops#90). This strips dangerous elements
 * (<script>/<style>/<iframe>/<object>/<embed>/<form>/…), all on* event-handler
 * attributes, style/srcdoc attributes, and javascript:/vbscript:/data: URLs,
 * while preserving <details>/<summary> and their safe structural attributes
 * (class, id, open, data-*).
 *
 * @param string $block Raw HTML for a single <details>...</details> block.
 * @return string Sanitised HTML safe to embed.
 */
function depthcontent_sanitise_details_block($block) {
    if (trim($block) === '') {
        return '';
    }
    $prev = libxml_use_internal_errors(true);
    $doc = new DOMDocument('1.0', 'UTF-8');
    $doc->loadHTML(
        '<?xml encoding="UTF-8"?><body><div id="dc-wrap">' . $block . '</div></body>',
        LIBXML_NOERROR | LIBXML_NONET | LIBXML_NOWARNING
    );
    libxml_clear_errors();
    libxml_use_internal_errors($prev);

    $xpath = new DOMXPath($doc);

    // 1. Remove entire dangerous elements.
    $kill = $xpath->query('//script | //style | //iframe | //object | //embed | //form '
        . '| //link | //meta | //base | //noscript | //template | //svg | //math');
    foreach (iterator_to_array($kill) as $node) {
        if ($node->parentNode) {
            $node->parentNode->removeChild($node);
        }
    }

    // 2. Strip dangerous attributes from every remaining element.
    $urlattrs = ['href', 'src', 'action', 'formaction', 'xlink:href', 'poster', 'background', 'srcset'];
    foreach ($xpath->query('//*') as $el) {
        for ($i = $el->attributes->length - 1; $i >= 0; $i--) {
            $attr = $el->attributes->item($i);
            $name = strtolower($attr->nodeName);
            $val  = (string) $attr->nodeValue;
            $remove = (strpos($name, 'on') === 0)
                   || $name === 'style'
                   || $name === 'srcdoc'
                   || (in_array($name, $urlattrs, true)
                       && preg_match('/^\s*(javascript|vbscript|data)\s*:/i', $val));
            if ($remove) {
                $el->removeAttributeNode($attr);
            }
        }
    }

    // 3. Serialise the sanitised children of the wrapper.
    $wrap = $xpath->query('//div[@id="dc-wrap"]')->item(0);
    if (!$wrap) {
        return '';
    }
    $out = '';
    foreach ($wrap->childNodes as $child) {
        $out .= $doc->saveHTML($child);
    }
    return $out;
}

/**
 * Render markdown text, preserving <details> HTML blocks.
 *
 * Moodle's FORMAT_MARKDOWN strips unrecognised HTML tags. This function
 * extracts <details> blocks before markdown processing and re-inserts them.
 *
 * @param string $text Raw markdown text that may contain <details> blocks.
 * @return string Rendered HTML.
 */
function depthcontent_render_markdown($text) {
    // Extract <details> blocks and replace with placeholders.
    $blocks = [];
    $text = preg_replace_callback(
        '/<details\b[^>]*>.*?<\/details>/s',
        function ($match) use (&$blocks) {
            $key = '%%DETAILS_' . count($blocks) . '%%';
            // ops#90: sanitise now — the block bypasses format_text(), so raw
            // author HTML here would otherwise be a stored-XSS vector.
            $blocks[$key] = depthcontent_sanitise_details_block($match[0]);
            return $key;
        },
        $text
    );

    // Render the markdown.
    $html = format_text($text, FORMAT_MARKDOWN);

    // Re-insert the <details> blocks (they may be wrapped in <p> tags).
    foreach ($blocks as $key => $block) {
        $html = str_replace('<p>' . $key . '</p>', $block, $html);
        $html = str_replace($key, $block, $html);
    }

    return $html;
}

/**
 * Parse a "MM:SS", "H:MM:SS", or bare-seconds timecode to integer seconds.
 *
 * @param mixed $t
 * @return int|null Seconds, or null if unparseable / empty.
 */
function depthcontent_parse_timecode($t) {
    if ($t === null || $t === '') {
        return null;
    }
    if (is_int($t) || is_float($t)) {
        return (int) round($t);
    }
    $parts = array_map('trim', explode(':', (string) $t));
    if (!$parts || !ctype_digit(implode('', $parts))) {
        return is_numeric($t) ? (int) round((float) $t) : null;
    }
    $parts = array_map('intval', $parts);
    $n = count($parts);
    if ($n === 1) { return $parts[0]; }
    if ($n === 2) { return $parts[0] * 60 + $parts[1]; }
    return $parts[0] * 3600 + $parts[1] * 60 + $parts[2];
}

/**
 * Render a depth level's `video` block (a selected YouTube clip) as a trusted,
 * responsive embed clipped to its start/end. Built by the plugin (NOT author
 * text), so it does not pass through depthcontent_sanitise_details_block() and
 * is not subject to the iframe-stripping that guards author HTML.
 *
 * @param array $video { youtube_id, start, end, episode?, duration_min? }
 * @return string HTML (empty string when there is no usable youtube_id).
 */
function depthcontent_render_video($video): string {
    if (!is_array($video) || empty($video['youtube_id'])) {
        return '';
    }
    $ytid = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $video['youtube_id']);
    if ($ytid === '') {
        return '';
    }
    $start = depthcontent_parse_timecode($video['start'] ?? null);
    $end   = depthcontent_parse_timecode($video['end'] ?? null);

    $params = ['rel' => 0, 'modestbranding' => 1];
    if ($start !== null) { $params['start'] = $start; }
    if ($end !== null && ($start === null || $end > $start)) { $params['end'] = $end; }
    $src = 'https://www.youtube-nocookie.com/embed/' . rawurlencode($ytid) . '?' . http_build_query($params);

    $label = get_string('modulename', 'depthcontent');
    if (!empty($video['duration_min'])) {
        $label = format_string((string) $video['duration_min']) . ' min clip';
    }

    return '<div class="dc-video" style="margin:0 0 1em;">'
        . '<div class="dc-video-frame" style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:6px;">'
        . '<iframe src="' . s($src) . '" title="' . s($label) . '" loading="lazy" '
        . 'style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" '
        . 'allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture" '
        . 'allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>'
        . '</div></div>';
}

/**
 * Render a depth level's `audio` block as an HTML5 player, clipped to its
 * start/end via a media fragment. AUDIO IS A FALLBACK FOR VIDEO (operator
 * policy 2026-07-22): the caller only invokes this when the depth has no
 * `video`, since a video clip already carries the audio.
 *
 * Schema (added to depths.<level>.audio when the Media Guild sources audio for
 * a clip-less LP):
 *   audio: { url: <https mp3/m4a/ogg>, start?: MM:SS|sec, end?: MM:SS|sec, title? }
 *
 * @param array $audio
 * @return string HTML (empty when there is no usable https url).
 */
function depthcontent_render_audio($audio): string {
    if (!is_array($audio) || empty($audio['url'])) {
        return '';
    }
    $url = trim((string) $audio['url']);
    // Only allow absolute https/http media URLs — never javascript:/data:/etc.
    if (!preg_match('#^https?://#i', $url)) {
        return '';
    }
    $url = clean_param($url, PARAM_URL);
    if ($url === '') {
        return '';
    }
    $start = depthcontent_parse_timecode($audio['start'] ?? null);
    $end   = depthcontent_parse_timecode($audio['end'] ?? null);
    $frag = '';
    if ($start !== null) {
        $frag = '#t=' . $start . (($end !== null && $end > $start) ? ',' . $end : '');
    }
    $title = !empty($audio['title']) ? (string) $audio['title'] : get_string('modulename', 'depthcontent') . ' audio';

    return '<div class="dc-audio" style="margin:0 0 1em;">'
        . '<audio controls preload="none" style="width:100%;" '
        . 'title="' . s($title) . '" src="' . s($url . $frag) . '">'
        . s(get_string('modulename', 'depthcontent')) . ' audio'
        . '</audio></div>';
}

// Build all content sections (each tagged with data-depth for JS switching).
$allsections = [];
foreach ($depthorder as $dlevel) {
    if (!isset($depths[$dlevel])) {
        continue;
    }
    $ddata = $depths[$dlevel];
    $html = '';
    if ($dlevel === 'short' && isset($ddata['summary'])) {
        $html = '<div class="dc-summary">'
            . '<em>' . format_text($ddata['summary'], FORMAT_MARKDOWN) . '</em>'
            . '</div>';
    } else if (isset($ddata['text'])) {
        $html = '<div class="dc-content dc-' . $dlevel . '">'
            . depthcontent_render_markdown($ddata['text'])
            . '</div>';
    }
    // Selected clip for this depth level (Media Guild pipeline), rendered above
    // the prose. Video wins; audio is the fallback ONLY when there is no video
    // (operator policy 2026-07-22 — the clip already carries the audio).
    if (!empty($ddata['video'])) {
        $html = depthcontent_render_video($ddata['video']) . $html;
    } else if (!empty($ddata['audio'])) {
        $html = depthcontent_render_audio($ddata['audio']) . $html;
    }
    if ($html !== '') {
        $allsections[$dlevel] = $html;
    }
}

// Determine which depth levels have content available.
$availablelevels = array_keys($allsections);

// Page setup.
$PAGE->set_url('/mod/depthcontent/view.php', ['id' => $cm->id]);
$PAGE->set_title($course->shortname . ': ' . $depthcontent->name);
$PAGE->set_heading($course->fullname);
$PAGE->set_activity_record($depthcontent);
$PAGE->add_body_class('limitedwidth');
$PAGE->requires->css('/mod/depthcontent/styles.css');

// Initialise inline quiz JS (pass quizstyle as 3rd argument).
$PAGE->requires->js_call_amd('mod_depthcontent/inline_quiz', 'init', [
    $cm->id,
    $quizitems,
    $quizstyle,
]);

// Initialise depth selector JS.
$PAGE->requires->js_call_amd('mod_depthcontent/depth_selector', 'init', [
    $cm->id,
    $depthcontent->id,
    $userdepth,
    $rememberpref,
    $depthorder,
    $availablelevels,
]);

// S13: initialise feedback modal JS (only for logged-in users).
if ($isloggedinuser) {
    $PAGE->requires->js_call_amd('mod_depthcontent/feedback_modal', 'init', [
        '.dc-fb-btn',
    ]);
}

echo $OUTPUT->header();

// ── Depth Selector Bar ──
echo '<div class="dc-depth-bar" id="dc-depth-bar">';
echo '<div class="dc-depth-bar-top">';
echo '<span class="dc-depth-label">' . get_string('changedepth', 'depthcontent') . '</span>';
echo '<div class="dc-depth-selector" role="radiogroup" aria-label="' . get_string('changedepth', 'depthcontent') . '">';

foreach ($depthorder as $dlevel) {
    $isactive = ($dlevel === $userdepth);
    $isavailable = in_array($dlevel, $availablelevels);
    $classes = 'dc-depth-btn';
    $classes .= $isactive ? ' active' : '';
    $classes .= $isavailable ? '' : ' disabled';

    $desc = get_string('depth_' . $dlevel . '_desc', 'depthcontent');
    $label = get_string('depth_' . $dlevel, 'depthcontent');

    // Non-JS fallback: link to same page with depth param.
    $url = new moodle_url('/mod/depthcontent/view.php', ['id' => $cm->id, 'depth' => $dlevel]);

    echo '<a href="' . $url . '"'
        . ' class="' . $classes . '"'
        . ' role="radio"'
        . ' aria-checked="' . ($isactive ? 'true' : 'false') . '"'
        . ' data-depth="' . $dlevel . '"'
        . ' title="' . s($desc) . '"'
        . ($isavailable ? '' : ' aria-disabled="true" tabindex="-1"')
        . '>' . $label . '</a>';
}

echo '</div>'; // .dc-depth-selector
echo '</div>'; // .dc-depth-bar-top

// "Remember my preference" checkbox.
if ($isloggedinuser) {
    echo '<div class="dc-remember-row">';
    echo '<label class="dc-remember-label">';
    echo '<input type="checkbox" id="dc-remember-pref" class="dc-remember-checkbox"'
        . ($rememberpref ? ' checked' : '') . '> ';
    echo get_string('remembermypref', 'depthcontent');
    echo '</label>';
    echo '</div>';
}

// ── Quiz Placement Toggle ──
if ($isloggedinuser && !empty($quizitems)) {
    $quizstyleurl = new moodle_url('/mod/depthcontent/view.php', ['id' => $cm->id]);
    echo '<div class="dc-quizstyle-row">';
    echo '<span class="dc-quizstyle-label">' . get_string('quizstyle', 'depthcontent') . ':</span> ';
    echo '<div class="dc-quizstyle-options" role="radiogroup" aria-label="' . s(get_string('quizstyle', 'depthcontent')) . '">';

    $quizstylechoices = [
        'inline' => get_string('quizstyle_inline', 'depthcontent'),
        'end'    => get_string('quizstyle_end', 'depthcontent'),
    ];
    foreach ($quizstylechoices as $val => $labeltxt) {
        $ischecked = ($quizstyle === $val);
        $radiourl = new moodle_url('/mod/depthcontent/view.php', ['id' => $cm->id, 'quizstyle' => $val]);
        echo '<label class="dc-quizstyle-option">';
        echo '<input type="radio" name="dc_quizstyle" value="' . s($val) . '"'
            . ' data-url="' . $radiourl . '"'
            . ($ischecked ? ' checked' : '')
            . ' class="dc-quizstyle-radio">';
        echo ' ' . s($labeltxt);
        echo '</label> ';
    }

    echo '</div>'; // .dc-quizstyle-options

    // Number of questions selector.
    echo '<span class="dc-quizstyle-sep">|</span>';
    echo '<span class="dc-quizstyle-label">' . get_string('quizcount', 'depthcontent') . ':</span> ';
    echo '<div class="dc-quizcount-options" role="radiogroup" aria-label="' . s(get_string('quizcount', 'depthcontent')) . '">';

    $quizcountchoices = ['1' => '1', '2' => '2', '3' => '3', 'all' => get_string('quizcount_all', 'depthcontent')];
    foreach ($quizcountchoices as $val => $labeltxt) {
        $ischecked = ($quizcount === $val);
        $counturl = new moodle_url('/mod/depthcontent/view.php', ['id' => $cm->id, 'quizcount' => $val]);
        echo '<label class="dc-quizstyle-option">';
        echo '<input type="radio" name="dc_quizcount" value="' . s($val) . '"'
            . ' data-url="' . $counturl . '"'
            . ($ischecked ? ' checked' : '')
            . ' class="dc-quizcount-radio">';
        echo ' ' . s($labeltxt);
        echo '</label> ';
    }

    echo '</div>'; // .dc-quizcount-options
    echo '</div>'; // .dc-quizstyle-row
}

echo '</div>'; // .dc-depth-bar

// ── Helper: render a single quiz item as HTML ──
/**
 * Render a single quiz item to HTML.
 *
 * @param array $item The quiz item data.
 * @param int $idx Numeric index for this item.
 * @param string $mindepth The min-depth attribute value.
 * @return string HTML output.
 */
function depthcontent_render_quiz_item(array $item, int $idx, string $mindepth): string {
    $out = '';
    $qid = s($item['id'] ?? $idx);
    $qtype = $item['type'] ?? 'multichoice';
    $out .= '<div class="dc-quiz-item" data-quizitem="' . $qid . '"'
        . ' data-type="' . s($qtype) . '"'
        . ' data-min-depth="' . s($mindepth) . '">';
    $out .= '<p class="dc-quiz-question">' . format_text($item['question'] ?? '', FORMAT_PLAIN) . '</p>';

    switch ($qtype) {
        case 'multichoice':
            if (!empty($item['options'])) {
                $out .= '<div class="dc-quiz-options">';
                foreach ($item['options'] as $oidx => $opt) {
                    $out .= '<label class="dc-quiz-option"'
                        . ' data-correct="' . ($opt['correct'] ? '1' : '0') . '"'
                        . ' data-feedback="' . s($opt['feedback'] ?? '') . '">';
                    $out .= '<input type="radio" name="q_' . $qid . '" value="' . $oidx . '"> ';
                    $out .= s($opt['text'] ?? '');
                    $out .= '</label>';
                }
                $out .= '</div>';
            }
            break;

        case 'truefalse':
            $correctval = !empty($item['correct_answer']) ? '1' : '0';
            $out .= '<div class="dc-quiz-options">';
            $out .= '<label class="dc-quiz-option"'
                . ' data-correct="' . ($correctval === '1' ? '1' : '0') . '"'
                . ' data-feedback="' . s($item['feedback_correct'] ?? '') . '">';
            $out .= '<input type="radio" name="q_' . $qid . '" value="1"> True';
            $out .= '</label>';
            $out .= '<label class="dc-quiz-option"'
                . ' data-correct="' . ($correctval === '0' ? '1' : '0') . '"'
                . ' data-feedback="' . s($item['feedback_incorrect'] ?? '') . '">';
            $out .= '<input type="radio" name="q_' . $qid . '" value="0"> False';
            $out .= '</label>';
            $out .= '</div>';
            break;

        case 'fillinblank':
            $blanks = $item['blanks'] ?? [];
            $alternatives = $item['accept_alternatives'] ?? [];
            $template = $item['template'] ?? '';
            $out .= '<div class="dc-fillin-container"'
                . ' data-blanks=\'' . s(json_encode($blanks, JSON_UNESCAPED_UNICODE)) . '\''
                . ' data-alternatives=\'' . s(json_encode($alternatives, JSON_UNESCAPED_UNICODE)) . '\'>';
            if ($template !== '') {
                $out .= '<p class="dc-fillin-template">' . format_text($template, FORMAT_PLAIN) . '</p>';
            }
            $out .= '<input type="text" class="dc-fillin-input" placeholder="Your answer">';
            $out .= '<button class="btn btn-sm btn-primary dc-fillin-check">Check</button>';
            $out .= '</div>';
            break;

        case 'matching':
            $pairs = $item['pairs'] ?? [];
            if (!empty($pairs)) {
                // Collect all right-side options and shuffle them.
                $rightoptions = [];
                foreach ($pairs as $pair) {
                    $rightoptions[] = $pair['right'] ?? '';
                }
                shuffle($rightoptions);

                $out .= '<div class="dc-matching-container">';
                foreach ($pairs as $pidx => $pair) {
                    $lefttext = $pair['left'] ?? '';
                    $correctright = $pair['right'] ?? '';
                    $out .= '<div class="dc-matching-pair" data-correct-right="' . s($correctright) . '">';
                    $out .= '<span class="dc-matching-left">' . s($lefttext) . '</span>';
                    $out .= '<span class="dc-matching-arrow">&rarr;</span>';
                    $out .= '<select class="dc-matching-select">';
                    $out .= '<option value="">Select...</option>';
                    foreach ($rightoptions as $ropt) {
                        $out .= '<option value="' . s($ropt) . '">' . s($ropt) . '</option>';
                    }
                    $out .= '</select>';
                    $out .= '</div>';
                }
                $out .= '<button class="btn btn-sm btn-primary dc-matching-check">Check</button>';
                $out .= '</div>';
            }
            break;
    }

    $out .= '<div class="dc-quiz-feedback" style="display:none;"></div>';
    $out .= '</div>';
    return $out;
}

// ── Content Sections ──
// Render ALL sections; JS will show/hide. Each section carries data-depth-level.
// For non-JS, only sections up to $userdepth are visible (others get dc-depth-hidden).
// Both inline and grouped quiz sections are always rendered; JS toggles visibility.
$hideinline = ($quizstyle === 'end');
$hidegrouped = ($quizstyle === 'inline');

echo '<div class="dc-content-wrapper" id="dc-content-wrapper">';

foreach ($depthorder as $dlevel) {
    if (!isset($allsections[$dlevel])) {
        continue;
    }
    $idxlevel = array_search($dlevel, $depthorder);
    $idxuser = array_search($userdepth, $depthorder);
    $hidden = ($idxlevel > $idxuser);

    echo '<div class="dc-depth-section' . ($hidden ? ' dc-depth-hidden' : '') . '"'
        . ' data-depth-level="' . $dlevel . '">';
    echo $allsections[$dlevel];

    // Scattered (inline) quiz items for this depth level.
    if (!empty($quizitemsbydepth[$dlevel])) {
        echo '<div class="dc-quiz-inline"' . ($hideinline ? ' style="display:none"' : '') . '>';
        echo '<h5 class="dc-quiz-heading">' . get_string('checkyourunderstanding', 'depthcontent') . '</h5>';
        foreach ($quizitemsbydepth[$dlevel] as $qentry) {
            echo depthcontent_render_quiz_item($qentry['item'], $qentry['index'], $qentry['mindepth']);
        }
        echo '</div>';
    }

    echo '</div>';
}

echo '</div>'; // .dc-content-wrapper

// ── Grouped Quiz Items (end section) ──
if (!empty($quizitems)) {
    echo '<div class="dc-quiz-section dc-quiz-grouped"' . ($hidegrouped ? ' style="display:none"' : '') . '>';
    echo '<h4 class="dc-quiz-heading">' . get_string('checkyourunderstanding', 'depthcontent') . '</h4>';
    foreach ($quizitems as $idx => $item) {
        $difficulty = $item['difficulty'] ?? 'standard';
        $mindepth = ($difficulty === 'advanced') ? DEPTHCONTENT_DEPTH_ADVANCED : DEPTHCONTENT_DEPTH_STANDARD;
        echo depthcontent_render_quiz_item($item, $idx, $mindepth);
    }
    echo '</div>';
}

// ── Practice Section ──
if ($practice) {
    echo '<div class="dc-practice">';
    echo '<h4>' . get_string('todayspractice', 'depthcontent') . '</h4>';
    if (!empty($practice['action'])) {
        echo '<p class="dc-practice-action">' . format_text($practice['action'], FORMAT_PLAIN) . '</p>';
    }
    if (!empty($practice['habit_tip'])) {
        echo '<p class="dc-habit-tip"><strong>' . get_string('habittip', 'depthcontent') . ':</strong> '
            . format_text($practice['habit_tip'], FORMAT_PLAIN) . '</p>';
    }
    echo '</div>';
}

// ── S13: Feedback panel ──
// Render "Help improve this" / "Report a problem" controls per slot for
// this (course, pointid). Slots come from the depthcontent_fb_state table;
// an empty table just means no slots have feedback state yet.
if ($isloggedinuser && has_capability('mod/depthcontent:submitfeedback', $context)) {
    $fbstates = $DB->get_records('depthcontent_fb_state', [
        'courseid' => $course->id,
        'pointid'  => $depthcontent->pointid,
    ], 'depth ASC, slot ASC');

    if (!empty($fbstates)) {
        echo '<div class="depthcontent-feedback-panel">';
        echo '<h4>' . get_string('feedback:help_improve', 'depthcontent') . '</h4>';
        echo '<ul class="depthcontent-feedback-slot-list">';
        foreach ($fbstates as $fb) {
            $btnlabel = ($fb->status === 'locked')
                ? get_string('feedback:report_problem', 'depthcontent')
                : get_string('feedback:help_improve', 'depthcontent');
            $btnclass = 'dc-fb-btn btn btn-sm btn-outline-primary';
            if ($fb->status === 'locked') {
                $btnclass .= ' dc-fb-btn-locked';
            }
            echo '<li class="depthcontent-feedback-slot">';
            echo '<span class="depthcontent-feedback-slot-label">'
                . s($fb->depth) . ' / ' . s($fb->slot) . '</span> ';
            echo '<button type="button" class="' . $btnclass . '"'
                . ' data-fb-state-id="' . (int) $fb->id . '"'
                . ' data-fb-status="' . s($fb->status) . '"'
                . ' data-fb-current-clip="' . s((string) ($fb->current_clip_json ?? '')) . '"'
                . ' data-fb-candidates="' . s((string) ($fb->candidates_json ?? '')) . '">'
                . s($btnlabel)
                . '</button>';
            echo '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }
}

// ── Review / Dashboard Links ──
if ($isloggedinuser) {
    $reviewurl = new moodle_url('/mod/depthcontent/review.php', ['course' => $course->id]);
    $dashboardurl = new moodle_url('/mod/depthcontent/dashboard.php', ['course' => $course->id]);
    echo '<div class="dc-mode-links">';
    echo '<a href="' . $reviewurl . '" class="btn btn-sm btn-outline-secondary">'
        . get_string('reviewmode', 'depthcontent') . '</a> ';
    echo '<a href="' . $dashboardurl . '" class="btn btn-sm btn-outline-secondary">'
        . get_string('reviewdashboard', 'depthcontent') . '</a>';
    echo '</div>';
}

echo $OUTPUT->footer();
