<?php
// local_nwc_copyright_sync — receives canonical legal-text from NWC's
// nwc_copyright module and publishes new versions in Moodle's native
// tool_policy (forcing re-acceptance on next login).
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_nwc_copyright_sync';
$plugin->version   = 2026070301;
$plugin->release   = '0.2.1';
$plugin->requires  = 2024042200;   // Moodle 4.4
$plugin->maturity  = MATURITY_STABLE;
$plugin->dependencies = [
    'tool_policy' => ANY_VERSION,
];
