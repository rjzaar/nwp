import Ajax from 'core/ajax';
import Notification from 'core/notification';

const SEL = '.depthcontent-feedback-level-cd';

const switchTab = (root, which) => {
    root.querySelectorAll('[data-cd-tab]').forEach((btn) => {
        const active = btn.getAttribute('data-cd-tab') === which;
        btn.classList.toggle('active', active);
        btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    root.querySelectorAll('[data-cd-pane]').forEach((pane) => {
        pane.hidden = pane.getAttribute('data-cd-pane') !== which;
    });
};

const submitC = async (root) => {
    const fbStateId = parseInt(root.getAttribute('data-fb-state-id'), 10);
    const slotFit = parseInt(root.querySelector('input[name="slot_fit"]').value, 10);
    const authorityOk = root.querySelector('input[name="authority_ok"]').checked;
    const crossRef = root.querySelector('input[name="cross_ref"]').value;
    const notes = root.querySelector('textarea[name="notes"]').value;
    return Ajax.call([{
        methodname: 'mod_depthcontent_feedback_submit_level_c',
        args: {fb_state_id: fbStateId, slot_fit: slotFit, authority_ok: authorityOk, cross_ref: crossRef, notes: notes},
    }])[0];
};

const submitD = async (root) => {
    const fbStateId = parseInt(root.getAttribute('data-fb-state-id'), 10);
    const episode = parseInt(root.getAttribute('data-episode'), 10);
    const youtubeId = root.getAttribute('data-youtube-id') || '';
    const startS = parseFloat(root.querySelector('input[name="start_s"]').value);
    const endS = parseFloat(root.querySelector('input[name="end_s"]').value);
    const rationale = root.querySelector('textarea[name="rationale"]').value;
    if (!(endS > startS)) {
        throw new Error('end must be greater than start');
    }
    if (!rationale.trim()) {
        throw new Error('rationale is required');
    }
    return Ajax.call([{
        methodname: 'mod_depthcontent_feedback_submit_level_d',
        args: {fb_state_id: fbStateId, episode: episode, start_s: startS, end_s: endS, rationale: rationale, youtube_id: youtubeId},
    }])[0];
};

const setStatus = (root, html) => {
    const el = root.querySelector('.dc-fb-cd-status');
    if (el) el.innerHTML = html;
};

export const init = (rootSelector = SEL) => {
    document.querySelectorAll(rootSelector).forEach((root) => {
        root.querySelectorAll('[data-cd-tab]').forEach((btn) => {
            btn.addEventListener('click', () => switchTab(root, btn.getAttribute('data-cd-tab')));
        });
        const slotFitInput = root.querySelector('input[name="slot_fit"]');
        const slotFitOut = root.querySelector('output[name="slot_fit_value"]');
        if (slotFitInput && slotFitOut) {
            slotFitInput.addEventListener('input', () => { slotFitOut.value = slotFitInput.value; });
        }
        const cBtn = root.querySelector('[data-cd-submit="c"]');
        if (cBtn) cBtn.addEventListener('click', async () => {
            try {
                const r = await submitC(root);
                setStatus(root, 'Level C recorded' + (r.promoted_to ? ' (promoted)' : ''));
            } catch (e) { Notification.exception(e); }
        });
        const dBtn = root.querySelector('[data-cd-submit="d"]');
        if (dBtn) dBtn.addEventListener('click', async () => {
            try {
                const r = await submitD(root);
                setStatus(root, 'Re-trim proposal sent' + (r.promoted_to ? ' (suggestion #' + r.promoted_to + ')' : ''));
            } catch (e) { Notification.exception(e); }
        });
    });
};
