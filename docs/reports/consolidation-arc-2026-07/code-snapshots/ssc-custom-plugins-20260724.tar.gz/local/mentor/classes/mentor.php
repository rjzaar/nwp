<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Pure ACCOMPANIMENT service for the Plan-of-Love mentor feature.
 *
 * THE SPEC IS THE CHURCH'S INTERNAL/EXTERNAL-FORUM FIREWALL (FORMATION-MASTER-DESIGN
 * §4; FORMATION-plan-of-love-ux.md §4): "accompaniment is *push*; surveillance is
 * *pull*." A mentor is a real person the MEMBER chose and to whom the member
 * confided a scoped, revocable, periodically-renewed view — the digital analog of
 * spiritual direction. This class encodes that firewall as pure, testable logic.
 *
 * THE LOAD-BEARING INVARIANTS baked in here:
 *
 *   PUSH-ONLY (never a live pull). The mentor-visible view is assembled ONLY from
 *   member-PUSHED snapshots (assemble_mentor_view() takes stored shares + the
 *   relationship — nothing else). There is NO method here that reads live
 *   local_practice_state, the engagement log, reflections, or ANY doctrine-level
 *   (mod_depthcontent) data. The mentor side is structurally unable to reach raw
 *   member state: the only input it accepts is the shares the member elected to send.
 *
 *   COARSE BY DEFAULT + revocable. Three consent tiers (coarse | engagement |
 *   detail), default = the LOWEST (coarse), 90-day renewable term, per-item
 *   overrides. Revocation is instant AND retroactive: purge_shares() deletes the
 *   previously-pushed snapshots and assemble_mentor_view() resolves to no-access
 *   the instant status != active (belt-and-braces, so even an un-purged row leaks
 *   nothing).
 *
 *   FORBIDDEN-FIELD FIREWALL (no-AI / no doctrine-level reach). A fixed token
 *   denylist (FORBIDDEN_KEY_TOKENS) covers tick grids, reflections, analytics,
 *   granular counts/streaks/timestamps, comparison/leaderboard shapes, AND every
 *   doctrine-level knowing field (belief/error/doctrine/quiz/mastery/knowing).
 *   build_share_payload() strips any such key at push time; assemble_mentor_view()
 *   ASSERTS none survives — mirroring progression::contains_comparison(). This is
 *   the same automated "no doctrine-level field reachable" property, extended to
 *   cover the mentor endpoints (design §4.2).
 *
 *   ROLE-EXCLUSIVITY (hard, from the Ratio/PPF forum firewall). The one who sees
 *   the interior life cannot vote on advancement: can_mentor() returns false if the
 *   prospective mentor holds any advancement-/recognition-gating role over that
 *   mentee (the gating-role set is INJECTED as a callable so it is testable without
 *   a live Moodle).
 *
 * PURE PHP: runs WITHOUT a Moodle runtime and is table-driven testable
 * (tests/mentor_test.php + tests/firewall_test.php), mirroring engine.php +
 * progression.php. The impure Moodle adapters (load a relationship row, read the
 * shares table, write a push) live in lib.php.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_mentor;

defined('MOODLE_INTERNAL') || die();

use local_practice\progression;

/**
 * Pure accompaniment service (consent + push-only assembly + the firewall guards).
 */
class mentor {

    // ========================================================================
    // CONSENT TIERS — default = the LOWEST/coarsest (design §4.6: Tier 1).
    // ========================================================================

    /** Coarse engagement only: rule-shape + member-composed notes. No per-item, no marks. */
    const TIER_COARSE = 'coarse';

    /** + coarse progression STATES (via progression::view(...,'gentle')) per shared item. */
    const TIER_ENGAGEMENT = 'engagement';

    /** + what the member explicitly ELECTS per-item (per-item overrides). Still coarse. */
    const TIER_DETAIL = 'detail';

    /** The three consent tiers, coarsest-first. */
    const TIERS = [self::TIER_COARSE, self::TIER_ENGAGEMENT, self::TIER_DETAIL];

    /** Default consent tier — the LOWEST/coarsest (member must opt UP, never down-to). */
    const DEFAULT_TIER = self::TIER_COARSE;

    /** Ordinal rank of each tier (for "at least this tier" comparisons). */
    const TIER_RANK = [self::TIER_COARSE => 0, self::TIER_ENGAGEMENT => 1, self::TIER_DETAIL => 2];

    // ========================================================================
    // RELATIONSHIP LIFECYCLE.
    // ========================================================================

    const STATUS_INVITED = 'invited';   // member invited; mentor has not yet accepted the covenant.
    const STATUS_ACTIVE  = 'active';     // covenant accepted; grant live.
    const STATUS_PAUSED  = 'paused';     // temporarily suspended by either party (no access resolves).
    const STATUS_REVOKED = 'revoked';    // ended; shares purged; access can never resolve again.

    /** All relationship statuses. */
    const STATUSES = [self::STATUS_INVITED, self::STATUS_ACTIVE, self::STATUS_PAUSED, self::STATUS_REVOKED];

    /** Default renewable term (days). Renewal is a FRESH consent, never auto-renew (design §4.3). */
    const TERM_DAYS = 90;

    /** Soft cap on active mentees per mentor — a shepherd's span of care (design §4.3/§4.6). */
    const MAX_MENTEES_PER_MENTOR = 12;

    /** Cap on active mentors per mentee (a director + an accountability friend; design §4.3). */
    const MAX_MENTORS_PER_MENTEE = 2;

    // ========================================================================
    // THE FORBIDDEN-FIELD FIREWALL.
    //
    // Substrings that may NEVER appear as a key in anything a mentor can see.
    // Mirrors progression::FORBIDDEN_KEY_TOKENS and EXTENDS it to the mentor
    // firewall: tick grids, reflections, analytics, granular counts/streaks/
    // timestamps, comparison/leaderboard shapes, AND every doctrine-level knowing
    // field. build_share_payload() strips these; assemble_mentor_view() asserts
    // none survives (contains_forbidden() proves the guard in tests).
    // ========================================================================
    const FORBIDDEN_KEY_TOKENS = [
        // Tick grids / day-by-day marks / provenance / per-checkpoint timestamps.
        'tick', 'grid', 'cell', 'mark', 'provenance', 'timestamp',
        // Reflections / journals / private self-prompts.
        'reflection', 'journal', 'prompt_self', 'diary',
        // Analytics / granular counts / streaks / scores.
        'analytic', 'streak', 'count', 'lifetime', 'score', 'percent',
        // Comparison / leaderboard (inherited from progression.php).
        'rank', 'leaderboard', 'compare', 'comparison', 'versus', 'peer',
        'cohort', 'percentile', 'position', 'others',
        // Doctrine-level KNOWING ledger — NEVER shareable, even to a mentor
        // (the hard firewall; mod_depthcontent is a separate, firewalled plane).
        'belief', 'error', 'doctrine', 'quiz', 'confidence', 'mastery',
        'knowing', 'depthcontent', 'correctness', 'heresy', 'orthodox',
    ];

    // ========================================================================
    // NORMALISERS.
    // ========================================================================

    /**
     * Normalise an arbitrary value to a valid consent tier (default = coarse).
     *
     * @param string|null $tier
     * @return string one of self::TIERS
     */
    public static function normalise_tier(?string $tier): string {
        $tier = is_string($tier) ? strtolower(trim($tier)) : '';
        return in_array($tier, self::TIERS, true) ? $tier : self::DEFAULT_TIER;
    }

    /**
     * Normalise an arbitrary value to a valid status (default = invited).
     *
     * @param string|null $status
     * @return string one of self::STATUSES
     */
    public static function normalise_status(?string $status): string {
        $status = is_string($status) ? strtolower(trim($status)) : '';
        return in_array($status, self::STATUSES, true) ? $status : self::STATUS_INVITED;
    }

    /**
     * The default consent tier (coarsest).
     *
     * @return string
     */
    public static function default_tier(): string {
        return self::DEFAULT_TIER;
    }

    /**
     * The rank of a tier (0=coarse .. 2=detail).
     *
     * @param string $tier
     * @return int
     */
    public static function tier_rank(string $tier): int {
        return self::TIER_RANK[self::normalise_tier($tier)];
    }

    /**
     * Does this tier grant AT LEAST the given tier's scope?
     *
     * @param string $tier      the relationship's granted tier
     * @param string $atleast   the tier being tested for
     * @return bool
     */
    public static function tier_at_least(string $tier, string $atleast): bool {
        return self::tier_rank($tier) >= self::tier_rank($atleast);
    }

    // ========================================================================
    // THE COVENANT.
    // ========================================================================

    /** The current covenant text version (bumped like the legal-doc workflow). */
    const COVENANT_VERSION = 1;

    /**
     * The mentor COVENANT text — the confidentiality promise the mentor must
     * accept before any grant activates (design §4.3). Echoes the direction
     * relationship; carries what the role is FOR and NOT for.
     *
     * @return string
     */
    public static function covenant_text(): string {
        return 'What you see here is confided to you. Hold it in confidence; '
            . 'never discuss it with others or raise it publicly; encourage privately; '
            . 'celebrate quietly; when someone is quiet, reach out as a friend, never to '
            . 'chase compliance. If you see something beyond you, help them find the right '
            . 'help. No automated system reads or summarises what you are shown — only you, '
            . 'the person they chose.';
    }

    /**
     * Record covenant acceptance on a relationship and (if invited) activate it.
     * A relationship CANNOT go active without an accepted covenant.
     *
     * @param array $relationship
     * @return array the updated relationship
     */
    public static function accept_covenant(array $relationship): array {
        $relationship['covenant_accepted'] = 1;
        $relationship['covenant_vid'] = self::COVENANT_VERSION;
        if (self::normalise_status($relationship['status'] ?? '') === self::STATUS_INVITED) {
            $relationship['status'] = self::STATUS_ACTIVE;
        }
        return $relationship;
    }

    // ========================================================================
    // THE INVITE PATH — adults-only, cap, role-exclusivity, self-exclusion.
    // ========================================================================

    /**
     * ROLE-EXCLUSIVITY guard (hard). The prospective mentor may NOT mentor this
     * mentee if they hold any advancement-/recognition-gating role over them — the
     * director who sees the interior life cannot vote on advancement (design §4;
     * the Ratio/PPF forum firewall). Also excludes self-mentoring.
     *
     * The gating-role check is INJECTED as a callable so this is testable without a
     * live Moodle capability stack: $gatingrolecheck(int $mentorid, int $menteeid)
     * returns true iff the mentor gates that mentee's advancement/recognition.
     *
     * @param int      $mentorid
     * @param int      $menteeid
     * @param callable $gatingrolecheck fn(int $mentorid, int $menteeid): bool
     * @return bool true iff this person MAY mentor that mentee.
     */
    public static function can_mentor(int $mentorid, int $menteeid, callable $gatingrolecheck): bool {
        if ($mentorid === $menteeid) {
            return false; // no self-mentoring.
        }
        if ($gatingrolecheck($mentorid, $menteeid) === true) {
            return false; // holds an advancement-gating role over this mentee.
        }
        return true;
    }

    /**
     * Full INVITE-path guard. Enforces (design §4.6): member-initiated adults-only
     * v1, the ~12-mentees/mentor cap, the 2-mentors/mentee cap, role-exclusivity,
     * and self-exclusion. Returns a structured result so the caller can surface the
     * exact reason.
     *
     * @param int      $mentorid
     * @param int      $menteeid
     * @param array    $opts {
     *     @var bool $mentee_is_adult    (required) adults-only v1.
     *     @var bool $mentor_is_adult    (required) adults-only v1.
     *     @var int  $mentor_mentee_count active mentees this mentor already holds.
     *     @var int  $mentee_mentor_count active mentors this mentee already holds.
     *     @var callable $gating_role_check fn(mentorid, menteeid): bool.
     * }
     * @return array {ok: bool, reason: string|null}
     */
    public static function can_invite(int $mentorid, int $menteeid, array $opts): array {
        $adultmentee = !empty($opts['mentee_is_adult']);
        $adultmentor = !empty($opts['mentor_is_adult']);
        $menteecount = (int) ($opts['mentor_mentee_count'] ?? 0);
        $mentorcount = (int) ($opts['mentee_mentor_count'] ?? 0);
        $gating = $opts['gating_role_check'] ?? function () {
            return false;
        };

        if (!$adultmentee || !$adultmentor) {
            return ['ok' => false, 'reason' => 'adults_only'];       // adults-only v1.
        }
        if (!self::can_mentor($mentorid, $menteeid, $gating)) {
            // Distinguish self vs gating-role for clearer messaging.
            $reason = ($mentorid === $menteeid) ? 'self' : 'gating_role';
            return ['ok' => false, 'reason' => $reason];
        }
        if ($menteecount >= self::MAX_MENTEES_PER_MENTOR) {
            return ['ok' => false, 'reason' => 'mentee_cap'];        // 12-mentees/mentor cap.
        }
        if ($mentorcount >= self::MAX_MENTORS_PER_MENTEE) {
            return ['ok' => false, 'reason' => 'mentor_cap'];        // 2-mentors/mentee cap.
        }
        return ['ok' => true, 'reason' => null];
    }

    /**
     * Build a fresh INVITED relationship (member-initiated). Term defaults to
     * 90 days from $today. The covenant is NOT yet accepted (invited, not active).
     *
     * @param int    $menteeid
     * @param int    $mentorid
     * @param string $tier   requested tier (default coarse).
     * @param int    $today  YYYYMMDD start date.
     * @param int    $renewsat YYYYMMDD term end (0 => caller lets Moodle compute; stored as given).
     * @param array  $overrides per-item {uid => show|hide} overrides.
     * @return array the new relationship (status=invited).
     */
    public static function new_relationship(int $menteeid, int $mentorid, string $tier,
            int $today, int $renewsat = 0, array $overrides = []): array {
        return [
            'menteeid'          => $menteeid,
            'mentorid'          => $mentorid,
            'status'            => self::STATUS_INVITED,
            'tier'              => self::normalise_tier($tier),
            'item_overrides'    => self::normalise_overrides($overrides),
            'covenant_accepted' => 0,
            'covenant_vid'      => 0,
            'created'           => $today,
            'renews_at'         => $renewsat,
        ];
    }

    // ========================================================================
    // ACTIVE-ACCESS RESOLUTION.
    // ========================================================================

    /**
     * Is this relationship an ACTIVE grant that resolves to access AS OF a date?
     * Requires: status=active AND covenant accepted AND not expired. A paused,
     * invited, revoked, covenant-unaccepted, or expired relationship resolves to
     * NO access (the mentor's view simply ceases to exist).
     *
     * @param array $relationship
     * @param int   $asof YYYYMMDD "today" (0 => ignore expiry).
     * @return bool
     */
    public static function is_active(array $relationship, int $asof = 0): bool {
        if (self::normalise_status($relationship['status'] ?? '') !== self::STATUS_ACTIVE) {
            return false;
        }
        if (empty($relationship['covenant_accepted'])) {
            return false; // no covenant, no access — ever.
        }
        $renews = (int) ($relationship['renews_at'] ?? 0);
        if ($asof > 0 && $renews > 0 && $asof > $renews) {
            return false; // term expired; reverts silently to no-access.
        }
        return true;
    }

    /**
     * REVOKE a relationship instantly AND retroactively. Returns the ended
     * relationship; the caller MUST also purge_shares() so the previously-pushed
     * snapshots are deleted. After this, is_active() is false forever.
     *
     * @param array  $relationship
     * @param string $endedby member | mentor | expiry
     * @return array
     */
    public static function revoke(array $relationship, string $endedby = 'member'): array {
        $relationship['status'] = self::STATUS_REVOKED;
        $relationship['ended_by'] = $endedby;
        return $relationship;
    }

    /**
     * RETROACTIVE purge: return the shares list with every snapshot for this
     * (menteeid, mentorid) pair removed. Revocation deletes what was pushed —
     * "nothing was ever copied" (design §4.3). Used by lib.php's revoke adapter as
     * a DELETE WHERE menteeid=? AND mentorid=?.
     *
     * @param array[] $shares full shares list.
     * @param int     $menteeid
     * @param int     $mentorid
     * @return array[] the surviving shares.
     */
    public static function purge_shares(array $shares, int $menteeid, int $mentorid): array {
        $kept = [];
        foreach ($shares as $s) {
            if ((int) ($s['menteeid'] ?? 0) === $menteeid && (int) ($s['mentorid'] ?? 0) === $mentorid) {
                continue; // purged.
            }
            $kept[] = $s;
        }
        return $kept;
    }

    // ========================================================================
    // PER-ITEM OVERRIDE RESOLUTION.
    // ========================================================================

    /**
     * Normalise a per-item override map to {uid => 'show'|'hide'} only.
     *
     * @param array $overrides
     * @return array
     */
    public static function normalise_overrides(array $overrides): array {
        $out = [];
        foreach ($overrides as $uid => $v) {
            $v = is_string($v) ? strtolower(trim($v)) : '';
            if ($v === 'show' || $v === 'hide') {
                $out[(string) $uid] = $v;
            }
        }
        return $out;
    }

    /**
     * Is one checkpoint visible to the mentor, given the granted tier + overrides?
     *
     * Resolution order (a per-item override ALWAYS wins over the tier default —
     * "share/hide individual checkpoints regardless of tier"):
     *   1. explicit override: show|hide wins outright.
     *   2. coarse tier: NO per-item visibility (coarse shows only rule-shape aggregate).
     *   3. personal items: default HIDDEN at every tier (design §4.2).
     *   4. otherwise (engagement/detail, non-personal): visible.
     *
     * @param string $tier
     * @param array  $overrides {uid => show|hide}
     * @param string $uid
     * @param bool   $ispersonal member flagged this item personal.
     * @return bool
     */
    public static function item_visible(string $tier, array $overrides, string $uid, bool $ispersonal = false): bool {
        $overrides = self::normalise_overrides($overrides);
        if (isset($overrides[$uid])) {
            return $overrides[$uid] === 'show'; // per-item override wins, regardless of tier.
        }
        if (self::normalise_tier($tier) === self::TIER_COARSE) {
            return false; // coarse tier carries no per-item detail at all.
        }
        if ($ispersonal) {
            return false; // personal items default hidden at engagement/detail tiers.
        }
        return true;
    }

    // ========================================================================
    // THE PUSH SIDE — build the coarse snapshot the member elects to SEND.
    // ========================================================================

    /**
     * Build the member-PUSHED coarse share payload for a relationship's tier.
     *
     * This runs on the MEMBER side, at the moment the member chooses to push. Its
     * output is what lands in local_mentor_share; the mentor sees ONLY this. Per
     * tier:
     *   coarse      : {rule_shape[], notes} — the shape of the rule + the member's
     *                 own composed notes. NO per-item data, NO counts, NO marks.
     *   engagement  : coarse + per-VISIBLE-item coarse progression STATE, projected
     *                 from progression::view(...,'gentle') through a strict allowlist
     *                 (state + symbol + milestones + renewal, plus the member's own
     *                 title). NO counts, NO growth, NO marks.
     *   detail      : engagement + the member's per-item elected note (member-composed).
     *
     * Every payload is passed through strip_forbidden() so it is STRUCTURALLY
     * impossible for a tick grid / reflection / streak / doctrine-level field to be
     * stored, even if a caller mistakenly supplies one.
     *
     * @param array[] $items each: {
     *     uid: string, title: string, rule_shape: string, personal: bool,
     *     note: string (member-composed), state: array (engine-state, engagement+ only)
     * }
     * @param string  $tier
     * @param array   $overrides per-item {uid => show|hide}
     * @param int     $asof YYYYMMDD (for renewal detection in the gentle projection).
     * @return array the coarse payload (safe to store + show to the mentor).
     */
    public static function build_share_payload(array $items, string $tier, array $overrides = [], int $asof = 0): array {
        $tier = self::normalise_tier($tier);

        // Coarse aggregate: the distinct RULE SHAPES present + the member's notes.
        // No item names, no counts — just the shape of a life of prayer.
        $shapes = [];
        foreach ($items as $it) {
            $shape = isset($it['rule_shape']) ? trim((string) $it['rule_shape']) : '';
            if ($shape !== '' && !in_array($shape, $shapes, true)) {
                $shapes[] = $shape;
            }
        }
        sort($shapes);

        $payload = [
            'tier'       => $tier,
            'rule_shape' => $shapes,
            'notes'      => self::sanitise_note(self::collect_notes($items)),
            'framing'    => 'Held in grace — practice disposes; God gives.',
        ];

        // ENGAGEMENT + : per-visible-item coarse progression STATE (gentle projection).
        if (self::tier_at_least($tier, self::TIER_ENGAGEMENT)) {
            $entries = [];
            foreach ($items as $it) {
                $uid = (string) ($it['uid'] ?? '');
                if ($uid === '') {
                    continue;
                }
                if (!self::item_visible($tier, $overrides, $uid, !empty($it['personal']))) {
                    continue; // hidden by tier/override/personal-default.
                }
                $entry = [
                    'uid'   => $uid,
                    'title' => self::sanitise_note((string) ($it['title'] ?? '')),
                ];
                // Coarse STATE only, projected from the member-safe gentle view.
                if (isset($it['state']) && is_array($it['state'])) {
                    $entry += self::coarse_state_projection($it['state'], $asof);
                }
                // DETAIL tier: the member's per-item elected note (member-composed).
                if ($tier === self::TIER_DETAIL && isset($it['note'])) {
                    $note = self::sanitise_note((string) $it['note']);
                    if ($note !== '') {
                        $entry['elected_note'] = $note;
                    }
                }
                $entries[] = $entry;
            }
            $payload['items'] = $entries;

            // If ANY item was hidden, show the single generic private line — never a
            // count, never a name (design §4.2).
            $payload['has_private'] = self::any_hidden($items, $tier, $overrides);
        }

        // STRUCTURAL GUARANTEE: strip any forbidden-shaped key before it is ever stored.
        return self::strip_forbidden($payload);
    }

    /**
     * Project a member's engine-state array to the COARSE, member-safe subset a
     * mentor may see, via progression::view(...,'gentle') + a strict allowlist.
     * NEVER carries counts, growth, timestamps, marks, or provenance.
     *
     * @param array $state engine-state array.
     * @param int   $asof  YYYYMMDD.
     * @return array {state, state_symbol, milestones, renewal_due}
     */
    public static function coarse_state_projection(array $state, int $asof = 0): array {
        $gentle = progression::view($state, 'gentle', $asof);
        // ALLOWLIST — only these keys cross to the mentor. (gentle already excludes
        // lifetime_count/growth; we further drop anchor + label-key + paused as
        // member-internal.)
        $allow = ['state', 'state_symbol', 'milestones', 'renewal_due'];
        $out = [];
        foreach ($allow as $k) {
            if (array_key_exists($k, $gentle)) {
                $out[$k] = $gentle[$k];
            }
        }
        return $out;
    }

    /**
     * Collect the member-composed plan-level notes across items into one string.
     *
     * @param array[] $items
     * @return string
     */
    protected static function collect_notes(array $items): string {
        foreach ($items as $it) {
            if (!empty($it['plan_note'])) {
                return (string) $it['plan_note'];
            }
        }
        return '';
    }

    /**
     * Was ANY item hidden from the mentor (so the generic "some items are private"
     * line should render)? Never exposes which, or how many.
     *
     * @param array[] $items
     * @param string  $tier
     * @param array   $overrides
     * @return bool
     */
    protected static function any_hidden(array $items, string $tier, array $overrides): bool {
        foreach ($items as $it) {
            $uid = (string) ($it['uid'] ?? '');
            if ($uid === '') {
                continue;
            }
            if (!self::item_visible($tier, $overrides, $uid, !empty($it['personal']))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Sanitise a member-composed string (trim, cap length; multibyte-safe).
     *
     * @param string $s
     * @param int    $max
     * @return string
     */
    public static function sanitise_note(string $s, int $max = 1000): string {
        $s = trim($s);
        if ($s === '') {
            return '';
        }
        return function_exists('mb_substr') ? mb_substr($s, 0, $max) : substr($s, 0, $max);
    }

    // ========================================================================
    // THE CHOKE POINT — assemble the mentor-visible view from PUSHED shares ONLY.
    // ========================================================================

    /**
     * THE SINGLE CHOKE POINT for everything a mentor sees.
     *
     * Inputs are ONLY: the relationship, and the stored SHARES (member-pushed
     * snapshots). It NEVER receives, queries, or reaches raw local_practice_state,
     * the engagement log, reflections, or ANY doctrine-level (mod_depthcontent)
     * data — the mentor side is structurally unable to pull live member state.
     * "Accompaniment is push; surveillance is pull" — this function is push-only by
     * construction.
     *
     * Behaviour:
     *   - If the relationship is not an active grant AS OF $asof (invited, paused,
     *     revoked, covenant-unaccepted, or expired) => {access: false} and NOTHING
     *     else (belt-and-braces: even an un-purged share leaks nothing).
     *   - Otherwise it returns the LATEST pushed snapshot for this (mentee, mentor)
     *     pair, and ASSERTS via contains_forbidden() that no forbidden-shaped field
     *     survived — throwing if one somehow did (the firewall as a runtime tripwire).
     *
     * @param array   $relationship
     * @param array[] $shares stored local_mentor_share rows (any set; filtered here).
     * @param int     $asof   YYYYMMDD "today" (expiry + renewal).
     * @return array {access: bool, ...view}
     */
    public static function assemble_mentor_view(array $relationship, array $shares, int $asof = 0): array {
        if (!self::is_active($relationship, $asof)) {
            // No access resolves — the view simply does not exist.
            return ['access' => false];
        }

        $menteeid = (int) ($relationship['menteeid'] ?? 0);
        $mentorid = (int) ($relationship['mentorid'] ?? 0);

        // From the PUSHED shares only, take the latest snapshot for this pair.
        $latest = null;
        foreach ($shares as $s) {
            if ((int) ($s['menteeid'] ?? 0) !== $menteeid || (int) ($s['mentorid'] ?? 0) !== $mentorid) {
                continue;
            }
            if ($latest === null || (int) ($s['shared_on'] ?? 0) >= (int) ($latest['shared_on'] ?? 0)) {
                $latest = $s;
            }
        }

        if ($latest === null) {
            // Active grant but the member has not pushed anything yet.
            return [
                'access'   => true,
                'menteeid' => $menteeid,
                'tier'     => self::normalise_tier($relationship['tier'] ?? ''),
                'pushed'   => false,
                'shared_on' => 0,
                'payload'  => [],
            ];
        }

        $payload = is_array($latest['payload'] ?? null) ? $latest['payload'] : [];

        // RUNTIME FIREWALL TRIPWIRE: a mentor view may NEVER carry a forbidden field.
        // If a malformed push somehow stored one, refuse to render it (fail closed).
        if (self::contains_forbidden($payload)) {
            throw new \RuntimeException('local_mentor: forbidden field reached the mentor view (firewall breach).');
        }

        return [
            'access'    => true,
            'menteeid'  => $menteeid,
            'tier'      => self::normalise_tier($relationship['tier'] ?? ''),
            'pushed'    => true,
            'shared_on' => (int) ($latest['shared_on'] ?? 0),
            'payload'   => $payload,
        ];
    }

    // ========================================================================
    // THE FORBIDDEN-FIELD GUARD (mirrors progression::contains_comparison()).
    // ========================================================================

    /**
     * Does any key in this (possibly nested) payload match a forbidden token —
     * a tick grid, reflection, analytic, streak/count, comparison, or ANY
     * doctrine-level knowing field? Used by tests to PROVE the mentor firewall,
     * and by assemble_mentor_view() as a runtime tripwire.
     *
     * @param array $payload
     * @return bool true iff a forbidden-shaped key is present anywhere.
     */
    public static function contains_forbidden(array $payload): bool {
        foreach ($payload as $key => $value) {
            $k = strtolower((string) $key);
            foreach (self::FORBIDDEN_KEY_TOKENS as $tok) {
                if (strpos($k, $tok) !== false) {
                    return true;
                }
            }
            if (is_array($value) && self::contains_forbidden($value)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Recursively STRIP any forbidden-shaped key from a payload (defense in depth
     * on the push side, so a forbidden field can never even be stored).
     *
     * @param array $payload
     * @return array the cleaned payload.
     */
    public static function strip_forbidden(array $payload): array {
        $out = [];
        foreach ($payload as $key => $value) {
            $k = strtolower((string) $key);
            $bad = false;
            foreach (self::FORBIDDEN_KEY_TOKENS as $tok) {
                if (strpos($k, $tok) !== false) {
                    $bad = true;
                    break;
                }
            }
            if ($bad) {
                continue; // drop the key entirely.
            }
            $out[$key] = is_array($value) ? self::strip_forbidden($value) : $value;
        }
        return $out;
    }
}
