<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Attainment evaluators for the mastery ledger (ACT / HABIT / CHARACTER).
 *
 * PURE, unit-testable PHP. Every method takes plain arrays (retrieval-log rows
 * + injected thresholds) and returns plain arrays. There are NO Moodle DB calls
 * and NO Moodle globals in this class, so it runs without a Moodle runtime and
 * is table-driven testable. The impure adapter (reads rows, upserts the ledger
 * row, reads thresholds from config) lives in lib.php.
 *
 * The ledger is defined over OUTCOMES and TIMESTAMPS only (never scheduler
 * internals), so the v1 SM-2 scheduler can be swapped for FSRS with no change
 * to these evaluators or to the ledger schema.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_depthcontent\mastery;

defined('MOODLE_INTERNAL') || die();

/**
 * Pure attainment evaluators.
 *
 * A retrieval-log row is an associative array with keys:
 *   ts               int    unix timestamp of the event (required)
 *   outcome          int    1 correct, 0 miss (required)
 *   item_id          string quiz item id, e.g. "B5.03.q4" (required)
 *   item_type        string multichoice|truefalse|shortanswer
 *   cognition        string recall|apply|discern
 *   core_accountable bool   MF-4 firewall: only true rows move the ledger
 *   single_tag       bool   MF-D: true iff the item tags exactly one pointid
 *   confidence       ?int   transient 1..3 (1=guessing,2=think-so,3=sure)
 *   mode             string inline|examination|weekly|monthly_probe (provenance)
 */
class evaluator {

    /** @var int Seconds in a day. */
    const DAY = 86400;

    /** Confidence value that means "guessing" (anti-guess guard, MF-B). */
    const CONF_GUESSING = 1;

    /**
     * Threshold defaults. Callers inject the catalog `completion_defaults`
     * block (schema.yaml) over these; nothing here is hardcoded at a call site.
     *
     * @return array
     */
    public static function defaults(): array {
        return [
            // From catalog completion_defaults (Pedagogy-owned).
            'habit_k'               => 3,
            'habit_gap_days'        => 3,
            'habit_span_floor_days' => 21,   // MF-A
            'probe_schedule'        => [30, 60, 120, 240, 365],
            'bank_floor'            => 4,     // MF-C-lesser (>=4 for unpredictability)
            // CHARACTER band sub-criteria (design §A.2; injectable, defaulted here).
            'char_min_distinct_items' => 3,
            'char_min_lag_days'       => 60,
            'char_min_transfer'       => 1,   // >=1 apply/discern (MF, formation twist)
            'char_min_shortanswer'    => 2,   // >=2 non-guessable probes
        ];
    }

    /**
     * Merge injected thresholds over the defaults.
     *
     * @param array $injected
     * @return array
     */
    public static function thresholds(array $injected = []): array {
        return array_merge(self::defaults(), $injected);
    }

    /**
     * The minimum number of probes a CHARACTER window needs = length of the
     * probe schedule (design: +30/60/120/240/365 => 5 probes).
     *
     * @param array $t Merged thresholds.
     * @return int
     */
    protected static function char_min_probes(array $t): int {
        $n = is_array($t['probe_schedule'] ?? null) ? count($t['probe_schedule']) : 5;
        return max(1, $n);
    }

    /**
     * Sort rows by timestamp ascending, stably.
     *
     * @param array $log
     * @return array
     */
    protected static function sorted(array $log): array {
        // Stable sort: decorate with original index.
        $decorated = [];
        foreach ($log as $i => $row) {
            $decorated[] = [$row['ts'] ?? 0, $i, $row];
        }
        usort($decorated, function ($a, $b) {
            return ($a[0] <=> $b[0]) ?: ($a[1] <=> $b[1]);
        });
        return array_map(function ($d) {
            return $d[2];
        }, $decorated);
    }

    /**
     * Only core-accountable rows move the ledger (MF-4 firewall).
     *
     * @param array $row
     * @return bool
     */
    protected static function moves_ledger(array $row): bool {
        return !empty($row['core_accountable']);
    }

    // ------------------------------------------------------------------
    // HABIT (spacing + span). Also yields the streak signal ACT reuses.
    // ------------------------------------------------------------------

    /**
     * Evaluate the HABIT criterion over the retrieval log.
     *
     * Rules:
     *  - Only core-accountable rows participate (MF-4).
     *  - Only SINGLE-TAG correct items advance the streak (MF-D) — a composite
     *    item tagged with many LPs cannot pump HABIT across all of them.
     *  - A correct success advances the streak only if >= habit_gap_days after
     *    the previously counted success (anti-cramming); same/next-day repeats
     *    are logged but not counted.
     *  - Any miss on a core-accountable item zeroes the streak.
     *  - HABIT attained when streak >= k AND the current streak spans
     *    >= habit_span_floor_days (MF-A: 6-day d0/d3/d6 runs do NOT qualify).
     *  - habit_at is monotonic (first attainment only); a later miss sets
     *    lapsed=true but never clears habit_at.
     *
     * @param array $log Retrieval-log rows.
     * @param array $t   Merged thresholds.
     * @return array {habit_at, habit_streak, first_success_at, last_success_at, max_streak, lapsed}
     */
    public static function evaluate_habit(array $log, array $t): array {
        $k        = (int) $t['habit_k'];
        $gap      = (int) $t['habit_gap_days'] * self::DAY;
        $spanfloor = (int) $t['habit_span_floor_days'] * self::DAY;

        $streak = 0;
        $firstct = 0;   // first counted success in current streak.
        $lastct  = 0;   // last counted success in current streak.
        $maxstreak = 0;
        $habitat = 0;
        $lapsed = false;

        foreach (self::sorted($log) as $row) {
            if (!self::moves_ledger($row)) {
                continue;
            }
            $ts = (int) $row['ts'];
            if (!empty($row['outcome'])) {
                // Correct. Only single-tag items advance the streak (MF-D).
                if (empty($row['single_tag'])) {
                    continue;
                }
                if ($streak === 0) {
                    $streak = 1;
                    $firstct = $ts;
                    $lastct = $ts;
                } else if (($ts - $lastct) >= $gap) {
                    $streak++;
                    $lastct = $ts;
                }
                // else: too soon since last counted success — logged, not counted.
                $maxstreak = max($maxstreak, $streak);

                if ($habitat === 0 && $streak >= $k && ($lastct - $firstct) >= $spanfloor) {
                    $habitat = $ts;
                }
            } else {
                // Miss on a core-accountable item: streak resets.
                $streak = 0;
                $firstct = 0;
                $lastct = 0;
                if ($habitat > 0) {
                    $lapsed = true; // live disposition regresses; habit_at stands.
                }
            }
        }

        return [
            'habit_at'         => $habitat,
            'habit_streak'     => $streak,
            'first_success_at' => $firstct,
            'last_success_at'  => $lastct,
            'max_streak'       => $maxstreak,
            'lapsed'           => $lapsed,
        ];
    }

    // ------------------------------------------------------------------
    // ACT (first verified closed-book correct) + anti-guess guard (MF-B).
    // ------------------------------------------------------------------

    /**
     * Evaluate the ACT criterion.
     *
     * ACT fires on the first correct retrieval of a core-accountable item.
     * act_at is IMMUTABLE once set. But a single lucky multichoice guess has a
     * ~25% floor, so ACT is PROVISIONAL until confirmed (MF-B) by ANY of:
     *   - the triggering item is a shortanswer (non-guessable), OR
     *   - confidence != guessing on the triggering item, OR
     *   - a second spaced success (habit streak reaches >= 2).
     * Only a CONFIRMED act counts toward Class-A course completion.
     *
     * @param array $log Retrieval-log rows.
     * @param array $t   Merged thresholds.
     * @param int   $maxstreak Highest habit streak reached (from evaluate_habit).
     * @return array {act_at, act_confirmed}
     */
    public static function evaluate_act(array $log, array $t, int $maxstreak = 0): array {
        $actat = 0;
        $selfconfirmed = false;

        foreach (self::sorted($log) as $row) {
            if (!self::moves_ledger($row) || empty($row['outcome'])) {
                continue;
            }
            // First correct core-accountable retrieval.
            $actat = (int) $row['ts'];
            $type = $row['item_type'] ?? '';
            $conf = $row['confidence'] ?? null;
            $shortanswer = ($type === 'shortanswer');
            $notguessing = ($conf !== null && (int) $conf !== self::CONF_GUESSING);
            $selfconfirmed = ($shortanswer || $notguessing);
            break;
        }

        if ($actat === 0) {
            return ['act_at' => 0, 'act_confirmed' => false];
        }

        // Confirmed if the triggering item was non-guessable/high-confidence,
        // OR a second spaced success has since occurred (streak >= 2).
        $confirmed = $selfconfirmed || ($maxstreak >= 2);
        return ['act_at' => $actat, 'act_confirmed' => $confirmed];
    }

    // ------------------------------------------------------------------
    // CHARACTER (durable retention + transfer) with MF-G band.
    // ------------------------------------------------------------------

    /**
     * Evaluate the CHARACTER criterion over the probe/retrieval window.
     *
     * The window starts at habit_at. Over the rolling window the criterion is a
     * BAND (MF-G), not literal all-correct:
     *   (band)  no TWO CONSECUTIVE misses — a single isolated miss EXTENDS the
     *           window; two consecutive misses RESET char_window_start to the
     *           second miss and clear the window counters.
     *   (a) >= char_min_probes probes answered in the window
     *   (b) window span >= 365 days
     *   (c) >= char_min_distinct_items distinct items answered correctly
     *   (d) >= 1 correct probe at lag >= char_min_lag_days since the previous
     *       retrieval on this LP
     *   (e) >= char_min_transfer correct apply/discern (transfer) probes
     *   (f) >= char_min_shortanswer correct non-guessable shortanswer probes
     *   (g) bank_floor: the LP's bank must hold >= bank_floor distinct items
     *       (MF-C) — else CHARACTER is unsatisfiable and the LP caps at HABIT.
     *
     * Course-adjacency (MF-H) is deliberately NOT considered: evaluation is
     * course-blind (the ledger row has no single course).
     *
     * @param array    $log       Retrieval-log rows.
     * @param array    $t         Merged thresholds.
     * @param int      $habitat   habit_at (window origin); 0 => not eligible.
     * @param int|null $banksize  distinct core-accountable items in the LP bank;
     *                            null => caller asserts eligibility (skip gate).
     * @return array {character_at, char_window_start, probes_answered,
     *                distinct_items_correct, last_transfer_ok, bank_eligible}
     */
    public static function evaluate_character(array $log, array $t, int $habitat, ?int $banksize = null): array {
        $result = [
            'character_at'           => 0,
            'char_window_start'      => $habitat,
            'probes_answered'        => 0,
            'distinct_items_correct' => 0,
            'last_transfer_ok'       => false,
            'bank_eligible'          => true,
        ];

        if ($habitat <= 0) {
            $result['char_window_start'] = 0;
            return $result;
        }

        // Bank-floor gate (MF-C). Unknown bank size => caller asserts eligibility.
        $bankfloor = (int) $t['bank_floor'];
        $eligible = ($banksize === null) ? true : ($banksize >= $bankfloor);
        $result['bank_eligible'] = $eligible;

        $minprobes   = self::char_min_probes($t);
        $mindistinct = (int) $t['char_min_distinct_items'];
        $minlag      = (int) $t['char_min_lag_days'] * self::DAY;
        $mintransfer = (int) $t['char_min_transfer'];
        $minshort    = (int) $t['char_min_shortanswer'];
        $yearspan    = 365 * self::DAY;

        // Window counters (reset on a two-consecutive-miss event).
        $winstart      = $habitat;
        $probes        = 0;
        $correctitems  = [];      // distinct item_ids answered correctly.
        $lagok         = false;
        $transferct    = 0;
        $shortct       = 0;
        $prevmiss      = false;
        $lastanyts     = 0;       // last retrieval ts (any outcome) for lag.
        $characterat   = 0;

        foreach (self::sorted($log) as $row) {
            if (!self::moves_ledger($row)) {
                continue;
            }
            $ts = (int) $row['ts'];
            $lastretbefore = $lastanyts;
            $lastanyts = $ts; // updated for every ledger-moving row.

            if ($ts < $winstart) {
                continue; // pre-window (before habit_at / before a reset).
            }

            if (empty($row['outcome'])) {
                // Miss.
                if ($prevmiss) {
                    // Two consecutive misses -> reset the window to this miss.
                    $winstart     = $ts;
                    $probes       = 0;
                    $correctitems = [];
                    $lagok        = false;
                    $transferct   = 0;
                    $shortct      = 0;
                    $prevmiss     = false;
                } else {
                    // Isolated miss: extends the window, counts as an answered probe.
                    $prevmiss = true;
                    $probes++;
                }
                continue;
            }

            // Correct probe.
            $prevmiss = false;
            $probes++;
            $itemid = (string) ($row['item_id'] ?? '');
            $correctitems[$itemid] = true;
            $lag = ($lastretbefore > 0) ? ($ts - $lastretbefore) : PHP_INT_MAX;
            if ($lag >= $minlag) {
                $lagok = true;
            }
            $cog = $row['cognition'] ?? '';
            if ($cog === 'apply' || $cog === 'discern') {
                $transferct++;
            }
            if (($row['item_type'] ?? '') === 'shortanswer') {
                $shortct++;
            }

            // Attainment check (first time all criteria met).
            if ($characterat === 0 && $eligible
                && $probes >= $minprobes
                && ($ts - $winstart) >= $yearspan
                && count($correctitems) >= $mindistinct
                && $lagok
                && $transferct >= $mintransfer
                && $shortct >= $minshort) {
                $characterat = $ts;
            }
        }

        $result['character_at']           = $characterat;
        $result['char_window_start']      = $winstart;
        $result['probes_answered']        = $probes;
        $result['distinct_items_correct'] = count($correctitems);
        $result['last_transfer_ok']       = ($transferct > 0);
        return $result;
    }

    // ------------------------------------------------------------------
    // Combined state.
    // ------------------------------------------------------------------

    /**
     * Evaluate the full ledger state for one (user, pointid) from its log.
     *
     * @param array    $log      Retrieval-log rows for this (user, pointid).
     * @param array    $injected Injected thresholds (catalog completion block).
     * @param int|null $banksize distinct core-accountable items in the LP bank.
     * @return array Full derived ledger state.
     */
    public static function evaluate(array $log, array $injected = [], ?int $banksize = null): array {
        $t = self::thresholds($injected);

        $habit = self::evaluate_habit($log, $t);
        $act   = self::evaluate_act($log, $t, (int) $habit['max_streak']);
        $char  = self::evaluate_character($log, $t, (int) $habit['habit_at'], $banksize);

        // Live status: the highest attainment reached; a lapse regresses the
        // LIVE status but never clears an attainment timestamp.
        $status = 'none';
        if ($act['act_at'] > 0) {
            $status = 'act';
        }
        if ($habit['habit_at'] > 0) {
            $status = 'habit';
        }
        if ($char['character_at'] > 0) {
            $status = 'character';
        }
        // A habit-level lapse regresses live status to 'act' (attainment kept).
        if ($habit['lapsed'] && $char['character_at'] === 0 && $act['act_at'] > 0) {
            $status = 'act';
        }

        return [
            'status'                 => $status,
            'act_at'                 => $act['act_at'],
            'act_confirmed'          => $act['act_confirmed'],
            'habit_at'               => $habit['habit_at'],
            'habit_streak'           => $habit['habit_streak'],
            'first_success_at'       => $habit['first_success_at'],
            'last_success_at'        => $habit['last_success_at'],
            'character_at'           => $char['character_at'],
            'char_window_start'      => $char['char_window_start'],
            'probes_answered'        => $char['probes_answered'],
            'distinct_items_correct' => $char['distinct_items_correct'],
            'last_transfer_ok'       => $char['last_transfer_ok'],
            'bank_eligible'          => $char['bank_eligible'],
            'lapsed'                 => $habit['lapsed'],
        ];
    }
}
