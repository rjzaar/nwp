<?php
/**
 * Mock AVC Tester-Guild logging endpoint, for tests + manual integration.
 *
 * Captures every POST it receives to a JSONL file at
 * /var/www/html/local/feedback/tests/fixtures/mock_avc.captures.jsonl
 *
 * One line per request: {
 *   "received_at": <unix ts>,
 *   "http_method": "POST",
 *   "auth_header": "Bearer ...",
 *   "body": { ...the JSON the SS forwarder posted... }
 * }
 *
 * The real AVC endpoint (see AVC_INTEGRATION.md) will replace this when
 * built. For tests, the assertions read the JSONL file back.
 */

declare(strict_types=1);

const CAPTURE_FILE = __DIR__ . '/mock_avc.captures.jsonl';

function respond(int $code, array $payload): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

// Allow GET ?reset=1 to clear captures (used by tests' "reset" step).
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    if (isset($_GET['reset'])) {
        @unlink(CAPTURE_FILE);
        respond(200, ['reset' => true]);
    }
    if (isset($_GET['captures'])) {
        // Returns the captured requests as JSON array for assertions.
        if (!file_exists(CAPTURE_FILE)) {
            respond(200, ['captures' => []]);
        }
        $lines = file(CAPTURE_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $captures = array_map(fn($l) => json_decode($l, true), $lines);
        respond(200, ['captures' => $captures]);
    }
    respond(405, ['error' => 'Use POST, or GET ?reset=1 / ?captures=1']);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    respond(405, ['error' => 'POST only']);
}

$body = file_get_contents('php://input');
$decoded = json_decode($body, true);
if (!is_array($decoded)) {
    respond(400, ['error' => 'Invalid JSON', 'raw_len' => strlen((string)$body)]);
}

// Verify Bearer token (matches what tests set via avc_token config).
$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!preg_match('/^Bearer\s+(.+)$/', $auth, $m)) {
    respond(401, ['error' => 'Missing Bearer token']);
}
$token = $m[1];

// In production AVC, the token would be verified against a stored hash.
// Here, we just record what we received and let the test verify.

$capture = [
    'received_at' => time(),
    'http_method' => 'POST',
    'auth_header' => $auth,
    'token'       => $token,
    'body'        => $decoded,
];

file_put_contents(
    CAPTURE_FILE,
    json_encode($capture) . "\n",
    FILE_APPEND | LOCK_EX
);

// AVC would return the new avc_feedback_id; we synthesise one from the
// SS feedback id for stability.
respond(200, [
    'ok' => true,
    'avc_feedback_id' => 1000 + (int)($decoded['ss_feedback_id'] ?? 0),
]);
