<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External services for mod_depthcontent.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'mod_depthcontent_record_response' => [
        'classname'   => 'mod_depthcontent\external\record_response',
        'description' => 'Record an inline quiz response',
        'type'        => 'write',
        'ajax'        => true,
        'loginrequired' => true,
    ],
    'mod_depthcontent_set_depth' => [
        'classname'   => 'mod_depthcontent\external\set_depth',
        'description' => 'Set user depth preference',
        'type'        => 'write',
        'ajax'        => true,
        'loginrequired' => true,
    ],
    'mod_depthcontent_submit_review' => [
        'classname'   => 'mod_depthcontent\external\submit_review',
        'description' => 'Submit credit-by-examination results and update SR state',
        'type'        => 'write',
        'ajax'        => true,
        'loginrequired' => true,
    ],
    // S13 Phase 2: feedback endpoints.
    'mod_depthcontent_feedback_submit_level_a' => [
        'classname'     => 'mod_depthcontent\external\feedback',
        'methodname'    => 'submit_level_a',
        'description'   => 'Submit a Level A (candidate pick) feedback vote',
        'type'          => 'write',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'mod/depthcontent:submitfeedback',
    ],
    'mod_depthcontent_feedback_submit_level_b' => [
        'classname'     => 'mod_depthcontent\external\feedback',
        'methodname'    => 'submit_level_b',
        'description'   => 'Submit a Level B (thumbs + verdict) feedback vote',
        'type'          => 'write',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'mod/depthcontent:submitfeedback',
    ],
    'mod_depthcontent_feedback_get_state' => [
        'classname'     => 'mod_depthcontent\external\feedback',
        'methodname'    => 'get_state',
        'description'   => 'Get current feedback state for a slot',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
    ],
    // S13 Phase 3: Level C/D full annotation, forwarded to AVC.
    'mod_depthcontent_feedback_submit_level_c' => [
        'classname'     => 'mod_depthcontent\external\feedback_full_annotation',
        'methodname'    => 'submit_level_c',
        'description'   => 'Submit a Level C (per-slot fit + fact-check) annotation',
        'type'          => 'write',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'mod/depthcontent:submitfeedback',
    ],
    'mod_depthcontent_feedback_submit_level_d' => [
        'classname'     => 'mod_depthcontent\external\feedback_full_annotation',
        'methodname'    => 'submit_level_d',
        'description'   => 'Submit a Level D (re-trim) proposal',
        'type'          => 'write',
        'ajax'          => true,
        'loginrequired' => true,
        'capabilities'  => 'mod/depthcontent:submitfeedback',
    ],
];
