<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * local_practice — the Application / Practice plane (the "N9 Plan-of-Love").
 *
 * The member-facing "living/doing" sibling of the doctrinal-knowing mastery
 * ledger (mod_depthcontent). Records that the suggested action at the end of a
 * course section was engaged, and surfaces the member's plan of checkpoints.
 *
 * See ~/central/PRACTICE-ACCOUNTABILITY-INTEGRATION-2026-07-19.md (Dimension 2)
 * and COURSES-SSC-N4-N9-DESIGN-2026-07-19.md Part B (the N9 engine).
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_practice';
$plugin->version   = 2026072002;       // v3.4: progression-visibility display layer (3-mode view + states + never-miss-twice + anchor plan).
$plugin->requires  = 2024041600;       // Moodle 4.4+
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.0';
