<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * S13 Phase 3 — Level C (per-slot-fit + fact-check) and Level D (re-trim).
 *
 * Records the event locally and forwards to AVC's clip-review signal
 * endpoint so the curator board sees the learner signal aggregated
 * alongside other Level A/B inputs.
 *
 *   LEGAL / CROSS-APP SURFACE — REQUIRES DPO REVIEW BEFORE ENABLING.
 *   forward_to_avc() below transmits a NAMED member's doctrine-level judgement
 *   (uid + exact learning point + free-text notes/rationale) to the clip-review
 *   signal endpoint. That makes the receiver a recipient of Art. 9 special-
 *   category data, and as of 2026-07-25 NO recipient appears in any DPIA, RoPA
 *   or privacy notice. Art. 30(1)(d) requires recipients be recorded even when
 *   they are our own other app.
 *
 *   THE `avc` NAMING HERE IS LEGACY AND MISLEADING. avc is DEFUNCT — it was a
 *   temporary step superseded by nwc, which now owns clip review via
 *   nwc_clip_review (same /api/clip-review/signal route, same LearnerSignal
 *   entity). So this forward reaches nwc, INSIDE the community boundary, or a
 *   decommissioned host. Art. 9(2)(d) ("not disclosed outside that body") is
 *   therefore NOT at risk — but do not restore the pre-2026-07-25 behaviour on
 *   that basis: it ran ungated, so a Trialing member's data was forwarded, and
 *   it ran with TLS peer verification disabled.
 *
 *   Recommended resolution is DELETION (see DECISIONS.md D10): nwc owns clip
 *   review, and the curator board's governance signal is the aggregate tally in
 *   depthcontent_fb_votes, which carries no userid and is unaffected. If kept
 *   instead: repoint + rename to nwc, send a salted pseudonym rather than
 *   user_id, and record nwc as a recipient in RoPA.md A2.2.
 *
 *   Until then the forward is OFF unless the operator explicitly opts in via
 *   the plugin setting `avc_signal_forward`. Fail-closed: absent setting = no
 *   transfer. Confirm what the URL is actually set to before enabling:
 *     php admin/cli/cfg.php --component=local_avc_copyright_sync \
 *         --name=avc_base_url
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP / Sacred Sources (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace mod_depthcontent\external;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/externallib.php');

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;

class feedback_full_annotation extends external_api {

    public static function submit_level_c_parameters(): external_function_parameters {
        return new external_function_parameters([
            'fb_state_id' => new external_value(PARAM_INT, 'Feedback state row id'),
            'slot_fit'    => new external_value(PARAM_INT, 'Per-slot fit score 0-10'),
            'authority_ok' => new external_value(PARAM_BOOL, 'Authority citation looks accurate'),
            'cross_ref'   => new external_value(PARAM_TEXT, 'Optional cross-reference suggestion', VALUE_DEFAULT, ''),
            'notes'       => new external_value(PARAM_TEXT, 'Free-text reviewer notes', VALUE_DEFAULT, ''),
        ]);
    }

    public static function submit_level_c(int $fbstateid, int $slotfit, bool $authorityok, string $crossref = '', string $notes = ''): array {
        global $DB, $USER;

        self::validate_parameters(self::submit_level_c_parameters(), [
            'fb_state_id' => $fbstateid,
            'slot_fit' => $slotfit,
            'authority_ok' => $authorityok,
            'cross_ref' => $crossref,
            'notes' => $notes,
        ]);

        $state = $DB->get_record('depthcontent_fb_state', ['id' => $fbstateid], '*', MUST_EXIST);

        $payload = [
            'slot_fit' => max(0, min(10, $slotfit)),
            'authority_ok' => (bool) $authorityok,
            'cross_ref' => $crossref,
            'notes' => $notes,
        ];

        // (ops#118) Art. 9 fail-closed gate — see lib.php and the class banner.
        require_once($GLOBALS['CFG']->dirroot . '/mod/depthcontent/lib.php');
        if (!depthcontent_may_keep_formation((int) $USER->id)) {
            return ['ok' => true];
        }

        $event = (object) [
            'fb_state_id' => (int) $state->id,
            'userid' => (int) $USER->id,
            'level' => 'C',
            'payload_json' => json_encode($payload),
            // Schema field is created_at (db/install.xml, db/upgrade.php); the
            // previous `timecreated` was an unknown column and threw on insert.
            'created_at' => time(),
        ];
        $DB->insert_record('depthcontent_fb_events', $event);

        $forwarded = self::forward_to_avc($state, $USER, 'C', $payload);

        return [
            'ok' => true,
            'avc_signal_id' => $forwarded['signal_id'] ?? null,
            'promoted_to' => $forwarded['promoted_to'] ?? null,
        ];
    }

    public static function submit_level_c_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, 'Success flag'),
            'avc_signal_id' => new external_value(PARAM_INT, 'AVC LearnerSignal id', VALUE_OPTIONAL),
            'promoted_to' => new external_value(PARAM_INT, 'Auto-promoted ClipSuggestion id', VALUE_OPTIONAL),
        ]);
    }

    public static function submit_level_d_parameters(): external_function_parameters {
        return new external_function_parameters([
            'fb_state_id' => new external_value(PARAM_INT, 'Feedback state row id'),
            'episode'     => new external_value(PARAM_INT, 'DIR episode number'),
            'start_s'     => new external_value(PARAM_FLOAT, 'Proposed start (seconds)'),
            'end_s'       => new external_value(PARAM_FLOAT, 'Proposed end (seconds)'),
            'rationale'   => new external_value(PARAM_TEXT, 'Why this trim is better'),
            'youtube_id'  => new external_value(PARAM_TEXT, 'YouTube id if known', VALUE_DEFAULT, ''),
        ]);
    }

    public static function submit_level_d(int $fbstateid, int $episode, float $starts, float $ends, string $rationale, string $youtubeid = ''): array {
        global $DB, $USER;

        self::validate_parameters(self::submit_level_d_parameters(), [
            'fb_state_id' => $fbstateid,
            'episode' => $episode,
            'start_s' => $starts,
            'end_s' => $ends,
            'rationale' => $rationale,
            'youtube_id' => $youtubeid,
        ]);

        if ($ends <= $starts) {
            throw new \invalid_parameter_exception('end_s must be greater than start_s');
        }

        $state = $DB->get_record('depthcontent_fb_state', ['id' => $fbstateid], '*', MUST_EXIST);

        $payload = [
            'episode' => $episode,
            'start_s' => $starts,
            'end_s' => $ends,
            'rationale' => $rationale,
            'youtube_id' => $youtubeid,
        ];

        // (ops#118) Art. 9 fail-closed gate — see lib.php and the class banner.
        require_once($GLOBALS['CFG']->dirroot . '/mod/depthcontent/lib.php');
        if (!depthcontent_may_keep_formation((int) $USER->id)) {
            return ['ok' => true];
        }

        $event = (object) [
            'fb_state_id' => (int) $state->id,
            'userid' => (int) $USER->id,
            'level' => 'D',
            'payload_json' => json_encode($payload),
            // Schema field is created_at, not timecreated (see submit_level_c).
            'created_at' => time(),
        ];
        $DB->insert_record('depthcontent_fb_events', $event);

        $forwarded = self::forward_to_avc($state, $USER, 'D', $payload);

        return [
            'ok' => true,
            'avc_signal_id' => $forwarded['signal_id'] ?? null,
            'promoted_to' => $forwarded['promoted_to'] ?? null,
        ];
    }

    public static function submit_level_d_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, 'Success flag'),
            'avc_signal_id' => new external_value(PARAM_INT, 'AVC LearnerSignal id', VALUE_OPTIONAL),
            'promoted_to' => new external_value(PARAM_INT, 'Auto-promoted ClipSuggestion id', VALUE_OPTIONAL),
        ]);
    }

    /**
     * Forward an event to AVC's /api/clip-review/signal endpoint.
     *
     * OFF BY DEFAULT — this is a disclosure of Art. 9 special-category data to a
     * recipient outside this site. See the class banner. Three fail-closed
     * conditions must ALL hold before a single byte leaves the boundary:
     *   1. the operator has explicitly set `avc_signal_forward` to 1;
     *   2. the member has current Art. 9 consent (checked by the callers);
     *   3. the endpoint presents a valid TLS certificate.
     */
    protected static function forward_to_avc(\stdClass $state, \stdClass $user, string $level, array $payload): array {
        // Fail-closed opt-in: an undisclosed recipient must never be reached by
        // default. Removing this check re-opens an unassessed Art. 9 transfer.
        if (!get_config('mod_depthcontent', 'avc_signal_forward')) {
            return [];
        }

        $base = get_config('local_avc_copyright_sync', 'avc_base_url');
        $token = get_config('local_avc_copyright_sync', 'avc_token');
        if (!$base || !$token) {
            return [];
        }

        $course_code = self::extract_course_code($state->pointid);
        $session_id = self::extract_session_id($state);
        $target = "lp:{$course_code}:{$session_id}:{$state->pointid}:{$state->depth}";

        $body = [
            'target' => $target,
            'level' => $level,
            'user_id' => (int) $user->id,
            'source' => 'mod_depthcontent',
            'payload' => $payload,
        ];

        $url = rtrim($base, '/') . '/api/clip-review/signal';
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => json_encode($body),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-Cross-Site-Token: ' . $token,
            ],
            CURLOPT_TIMEOUT => 5,
            // Art. 32 "encryption in transit" is worthless against an unverified
            // peer. This carried special-category data with verification OFF,
            // i.e. MITM-able; never relax these two again on this channel.
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
        if (!$resp) {
            return [];
        }
        $decoded = json_decode((string) $resp, true);
        return is_array($decoded) ? $decoded : [];
    }

    protected static function extract_course_code(string $pointid): string {
        if (preg_match('/^([A-Z]+\d+)\./', $pointid, $m)) {
            return $m[1];
        }
        return preg_replace('/\..*$/', '', $pointid);
    }

    protected static function extract_session_id(\stdClass $state): int {
        if (!empty($state->current_clip_json)) {
            $j = json_decode($state->current_clip_json, true);
            if (is_array($j) && isset($j['session'])) {
                return (int) $j['session'];
            }
        }
        return 1;
    }

}
