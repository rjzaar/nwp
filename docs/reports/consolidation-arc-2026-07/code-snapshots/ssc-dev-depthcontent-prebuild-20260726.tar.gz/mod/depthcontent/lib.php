<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library functions for mod_depthcontent.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/** Depth level constants. */
define('DEPTHCONTENT_DEPTH_SHORT', 'short');
define('DEPTHCONTENT_DEPTH_STANDARD', 'standard');
define('DEPTHCONTENT_DEPTH_LONGER', 'longer');
define('DEPTHCONTENT_DEPTH_DETAILED', 'detailed');
define('DEPTHCONTENT_DEPTH_ADVANCED', 'advanced');
define('DEPTHCONTENT_DEPTH_SCHOLAR', 'scholar');

/**
 * (ops#118) Art. 9 formation-data consent gate — fail-closed wrapper.
 *
 * mod_depthcontent's per-user rows (depthcontent_progress / _responses / _sr /
 * _mastery / _retrieval_log / _fb_events) are special-category religious-
 * formation data — the set is exactly the tables mod_depthcontent's
 * core_privacy provider erases (INSTANCE_TABLES + LEDGER_TABLES). A member who
 * has NOT given Art. 9 consent (Trialing) must not have that data persisted
 * cross-app on Moodle. The canonical decision lives in \auth_nwc\consent, fed by
 * the nwc `art9_consent` OIDC claim; this wrapper isolates depthcontent from a
 * hard symbol dependency and FAILS CLOSED if the consent subsystem is absent.
 *
 * MUST SHIP TOGETHER with the nwc consent-arc change that emits the claim — until
 * then every member reads as Trialing and formation writes are skipped (the safe
 * pre-rollout posture). Site admins are never gated (CLI seeding / tooling).
 *
 * @param int $userid
 * @return bool true if this member's formation data may be persisted.
 */
function depthcontent_may_keep_formation($userid): bool {
    if (!class_exists('\\auth_nwc\\consent')) {
        // Consent subsystem not installed -> cannot prove consent -> fail closed.
        return false;
    }
    return \auth_nwc\consent::may_keep_formation((int) $userid);
}

/**
 * Ordered list of depth levels.
 */
function depthcontent_get_depth_levels(): array {
    return [
        DEPTHCONTENT_DEPTH_SHORT,
        DEPTHCONTENT_DEPTH_STANDARD,
        DEPTHCONTENT_DEPTH_LONGER,
        DEPTHCONTENT_DEPTH_DETAILED,
        DEPTHCONTENT_DEPTH_ADVANCED,
        DEPTHCONTENT_DEPTH_SCHOLAR,
    ];
}

/**
 * Feature support.
 */
function depthcontent_supports($feature) {
    switch ($feature) {
        case FEATURE_MOD_ARCHETYPE:           return MOD_ARCHETYPE_RESOURCE;
        case FEATURE_MOD_INTRO:               return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS: return true;
        case FEATURE_GRADE_HAS_GRADE:         return false;
        case FEATURE_BACKUP_MOODLE2:          return true;
        case FEATURE_SHOW_DESCRIPTION:        return true;
        case FEATURE_MOD_PURPOSE:             return MOD_PURPOSE_CONTENT;
        default: return null;
    }
}

/**
 * Add a new depthcontent instance.
 */
function depthcontent_add_instance($data, $mform = null) {
    global $DB;

    $data->timemodified = time();
    $data->id = $DB->insert_record('depthcontent', $data);

    return $data->id;
}

/**
 * Update an existing depthcontent instance.
 */
function depthcontent_update_instance($data, $mform = null) {
    global $DB;

    $data->timemodified = time();
    $data->id = $data->instance;
    $DB->update_record('depthcontent', $data);

    return true;
}

/**
 * Delete a depthcontent instance.
 */
function depthcontent_delete_instance($id) {
    global $DB;

    if (!$DB->get_record('depthcontent', ['id' => $id])) {
        return false;
    }

    $DB->delete_records('depthcontent_progress', ['depthcontentid' => $id]);
    $DB->delete_records('depthcontent_responses', ['depthcontentid' => $id]);
    $DB->delete_records('depthcontent_sr', ['depthcontentid' => $id]);
    $DB->delete_records('depthcontent', ['id' => $id]);

    // NOTE: depthcontent_mastery and depthcontent_retrieval_log are keyed on the
    // PERMANENT pointid, not this instance id, and are deliberately NOT deleted
    // here — member formation state survives an activity delete / `--clear`
    // render rebuild (the durability litmus). Data-subject erasure of that state
    // is a separate explicit path (core_privacy provider, DELETE WHERE userid=?).

    return true;
}

/**
 * Mark the activity as viewed and trigger completion.
 */
function depthcontent_view($depthcontent, $course, $cm, $context) {
    // Trigger event.
    $event = \mod_depthcontent\event\course_module_viewed::create([
        'objectid' => $depthcontent->id,
        'context' => $context,
    ]);
    $event->add_record_snapshot('course_modules', $cm);
    $event->add_record_snapshot('course', $course);
    $event->add_record_snapshot('depthcontent', $depthcontent);
    $event->trigger();

    // Completion.
    $completion = new completion_info($course);
    $completion->set_module_viewed($cm);
}

/**
 * Get or create user progress record for a learning point.
 */
function depthcontent_get_progress($userid, $depthcontentid) {
    global $DB;

    $progress = $DB->get_record('depthcontent_progress', [
        'userid' => $userid,
        'depthcontentid' => $depthcontentid,
    ]);

    if (!$progress) {
        $progress = new stdClass();
        $progress->userid = $userid;
        $progress->depthcontentid = $depthcontentid;
        $progress->status = 'new';
        $progress->depth_viewed = 'standard';
        $progress->timecreated = time();
        $progress->timemodified = time();
        // ops#118 Art. 9 gate: only persist for consented members. A Trialing
        // member gets an ephemeral in-memory row (no id) — do NOT store.
        if (depthcontent_may_keep_formation($userid)) {
            $progress->id = $DB->insert_record('depthcontent_progress', $progress);
        } else {
            debugging('depthcontent: skipped depthcontent_progress persist for '
                . 'non-consented (Art.9/Trialing) userid=' . $userid, DEBUG_DEVELOPER);
        }
    }

    return $progress;
}

/**
 * Get user's preferred depth level.
 */
function depthcontent_get_user_depth($userid) {
    $depth = get_user_preferences('mod_depthcontent_depth', DEPTHCONTENT_DEPTH_STANDARD, $userid);
    $valid = depthcontent_get_depth_levels();
    return in_array($depth, $valid) ? $depth : DEPTHCONTENT_DEPTH_STANDARD;
}

/**
 * Set user's preferred depth level.
 *
 * @param int $userid
 * @param string $depth
 * @param bool $remember Whether to persist as the global default.
 */
function depthcontent_set_user_depth($userid, $depth, bool $remember = true) {
    $valid = depthcontent_get_depth_levels();
    if (in_array($depth, $valid)) {
        if ($remember) {
            set_user_preference('mod_depthcontent_depth', $depth, $userid);
        }
    }
}

/**
 * Check whether the user has enabled "remember my preference".
 *
 * Defaults to true so first-time users get persistence automatically.
 *
 * @param int $userid
 * @return bool
 */
function depthcontent_get_remember_preference($userid): bool {
    return (bool) get_user_preferences('mod_depthcontent_remember', 1, $userid);
}

/**
 * Set whether the user wants depth choices persisted globally.
 *
 * @param int $userid
 * @param bool $remember
 */
function depthcontent_set_remember_preference($userid, bool $remember): void {
    set_user_preference('mod_depthcontent_remember', $remember ? 1 : 0, $userid);
}

/**
 * Get a per-point depth override for a specific activity.
 *
 * @param int $userid
 * @param int $depthcontentid The activity instance id.
 * @return string|null The depth level override, or null if none set.
 */
function depthcontent_get_point_depth($userid, $depthcontentid): ?string {
    $key = 'mod_depthcontent_point_' . $depthcontentid;
    $depth = get_user_preferences($key, null, $userid);
    if ($depth !== null) {
        $valid = depthcontent_get_depth_levels();
        return in_array($depth, $valid) ? $depth : null;
    }
    return null;
}

/**
 * Set a per-point depth override for a specific activity.
 *
 * @param int $userid
 * @param int $depthcontentid The activity instance id.
 * @param string $depth The depth level.
 */
function depthcontent_set_point_depth($userid, $depthcontentid, $depth): void {
    $valid = depthcontent_get_depth_levels();
    if (in_array($depth, $valid)) {
        $key = 'mod_depthcontent_point_' . $depthcontentid;
        set_user_preference($key, $depth, $userid);
    }
}

/**
 * Clear a per-point depth override, reverting to the global preference.
 *
 * @param int $userid
 * @param int $depthcontentid The activity instance id.
 */
function depthcontent_clear_point_depth($userid, $depthcontentid): void {
    $key = 'mod_depthcontent_point_' . $depthcontentid;
    unset_user_preference($key, $userid);
}

/**
 * Resolve the effective depth for a user viewing a specific point.
 *
 * Priority: URL override > per-point override > global preference > default.
 *
 * @param int $userid
 * @param int $depthcontentid
 * @param string|null $urloverride Depth passed via URL parameter.
 * @return string The effective depth level.
 */
function depthcontent_resolve_effective_depth($userid, $depthcontentid, ?string $urloverride = null): string {
    $valid = depthcontent_get_depth_levels();

    // URL override takes first priority.
    if ($urloverride && in_array($urloverride, $valid)) {
        return $urloverride;
    }

    // Per-point override second.
    $pointdepth = depthcontent_get_point_depth($userid, $depthcontentid);
    if ($pointdepth !== null) {
        return $pointdepth;
    }

    // Global preference.
    return depthcontent_get_user_depth($userid);
}

/**
 * Get SM-2 spaced repetition state for a user+point.
 */
function depthcontent_get_sr_state($userid, $depthcontentid) {
    global $DB;

    return $DB->get_record('depthcontent_sr', [
        'userid' => $userid,
        'depthcontentid' => $depthcontentid,
    ]);
}

/**
 * Pure SM-2 step. Given the current scheduler state and a 0-5 quality grade,
 * returns the next scheduler state. No DB, no globals — unit-testable and
 * shared by both the legacy depthcontent_sr updater and the mastery-ledger
 * orchestrator.
 *
 * The ledger's attainment evaluators are defined over outcomes+timestamps only,
 * NOT over these scheduler internals, so this SM-2 core can be swapped for FSRS
 * with no change to the ledger.
 *
 * @param array $s {ease_factor, interval_days, repetitions, lapses}
 * @param int   $quality 0-5 SM-2 grade.
 * @return array {ease_factor, interval_days, repetitions, lapses}
 */
function depthcontent_sm2_step(array $s, int $quality): array {
    $ef   = (float) ($s['ease_factor'] ?? 2.50);
    $ivl  = (int) ($s['interval_days'] ?? 1);
    $reps = (int) ($s['repetitions'] ?? 0);
    $lapses = (int) ($s['lapses'] ?? 0);

    if ($quality >= 3) {
        // Correct response.
        if ($reps == 0) {
            $ivl = 1;
        } else if ($reps == 1) {
            $ivl = 6;
        } else {
            $ivl = (int) round($ivl * $ef);
        }
        $reps++;
    } else {
        // Incorrect — reset, and count the lapse (SR-signal repair: wrong
        // answers now reach the scheduler instead of being silently dropped).
        $reps = 0;
        $ivl = 1;
        $lapses++;
    }

    // EF' = EF + (0.1 - (5-q) * (0.08 + (5-q) * 0.02)), floored at 1.30.
    $ef = max(1.30, $ef + (0.1 - (5 - $quality) * (0.08 + (5 - $quality) * 0.02)));

    return [
        'ease_factor'   => $ef,
        'interval_days' => $ivl,
        'repetitions'   => $reps,
        'lapses'        => $lapses,
    ];
}

/**
 * Map a real outcome to an SM-2 quality grade (SR-signal repair, design §A.3).
 *
 * Replaces the old hardcoded quality=4. A wrong answer now yields a real
 * failing grade (1, or 2 if "near") so the scheduler resets and the lapse is
 * counted — the correct-only guard is removed at the call site.
 *
 *   correct + high confidence (3)                       => 5
 *   correct                                             => 4
 *   correct + guessing OR latency > 2x median           => 3
 *   wrong-but-near (fuzzy shortanswer / correct 2nd try) => 2
 *   wrong                                               => 1
 *
 * @param int      $correct 1 correct, 0 wrong.
 * @param int|null $confidence 1..3 (1=guessing) or null.
 * @param int|null $latencyms latency of this answer, or null.
 * @param int|null $medianlatency member median latency for this item type, or null.
 * @param bool     $near true if a wrong answer was fuzzy-close / correct on 2nd try.
 * @return int 1..5
 */
function depthcontent_grade_from_outcome(int $correct, ?int $confidence = null,
        ?int $latencyms = null, ?int $medianlatency = null, bool $near = false): int {
    if (!$correct) {
        return $near ? 2 : 1;
    }
    if ($confidence !== null && $confidence >= 3) {
        return 5;
    }
    $slow = ($latencyms !== null && $medianlatency !== null && $medianlatency > 0
             && $latencyms > 2 * $medianlatency);
    if (($confidence !== null && $confidence <= 1) || $slow) {
        return 3;
    }
    return 4;
}

/**
 * Update legacy SM-2 state (depthcontent_sr, instance-keyed) after a review.
 *
 * Retained for the existing daily due-queue (depthcontent_get_due_reviews)
 * until the Q-Q rekey migrates that queue onto depthcontent_mastery. The
 * correct-only guard that used to wrap the CALL to this function is removed
 * (see record_response) so wrong answers now reset the schedule here too.
 *
 * @param int $userid
 * @param int $depthcontentid
 * @param int $quality 0-5 response quality (SM-2 scale)
 */
function depthcontent_update_sr($userid, $depthcontentid, $quality) {
    global $DB;

    // ops#118 Art. 9 gate: a Trialing member's spaced-repetition schedule is not
    // persisted. Return an ephemeral, unsaved state so callers never break.
    if (!depthcontent_may_keep_formation($userid)) {
        debugging('depthcontent: skipped depthcontent_sr persist for non-consented '
            . '(Art.9/Trialing) userid=' . $userid, DEBUG_DEVELOPER);
        $sr = depthcontent_get_sr_state($userid, $depthcontentid);
        return $sr ?: false;
    }

    $sr = depthcontent_get_sr_state($userid, $depthcontentid);
    $now = time();

    if (!$sr) {
        $sr = new stdClass();
        $sr->userid = $userid;
        $sr->depthcontentid = $depthcontentid;
        $sr->ease_factor = 2.50;
        $sr->interval_days = 1;
        $sr->repetitions = 0;
        $sr->next_review = $now;
        $sr->last_reviewed = $now;
    }

    $next = depthcontent_sm2_step([
        'ease_factor'   => $sr->ease_factor,
        'interval_days' => $sr->interval_days,
        'repetitions'   => $sr->repetitions,
    ], (int) $quality);

    $sr->ease_factor   = $next['ease_factor'];
    $sr->interval_days = $next['interval_days'];
    $sr->repetitions   = $next['repetitions'];
    $sr->next_review   = $now + ($sr->interval_days * 86400);
    $sr->last_reviewed = $now;

    if (isset($sr->id)) {
        $DB->update_record('depthcontent_sr', $sr);
    } else {
        $sr->id = $DB->insert_record('depthcontent_sr', $sr);
    }

    return $sr;
}

/**
 * Pedagogy-owned completion thresholds, injected into the pure evaluators.
 *
 * These mirror the catalog `completion_defaults` block (schema.yaml). Admins
 * may override any value via mod_depthcontent config; nothing is hardcoded at a
 * call site. This is THE injection point for the ACT/HABIT/CHARACTER evaluators.
 *
 * @return array
 */
function depthcontent_get_completion_defaults(): array {
    $defaults = [
        'pass_threshold'        => 0.8,
        'habit_k'               => 3,
        'habit_gap_days'        => 3,
        'habit_span_floor_days' => 21,
        'probe_schedule'        => [30, 60, 120, 240, 365],
        'probe_budget'          => 20,
        'bank_floor'            => 4,
    ];
    // Allow admin override from plugin config (set via settings.php later).
    foreach (['pass_threshold', 'habit_k', 'habit_gap_days', 'habit_span_floor_days',
              'probe_budget', 'bank_floor'] as $key) {
        $val = get_config('mod_depthcontent', $key);
        if ($val !== false && $val !== null && $val !== '') {
            $defaults[$key] = is_numeric($val) ? $val + 0 : $val;
        }
    }
    return $defaults;
}

/**
 * Orchestrator (impure adapter): record one retrieval event, then recompute the
 * mastery-ledger row for its (userid, pointid) using the PURE evaluators.
 *
 * Appends to the append-only depthcontent_retrieval_log, runs SM-2 over the
 * mastery row's scheduler columns, then overlays the ACT/HABIT/CHARACTER
 * attainment fields derived by \mod_depthcontent\mastery\evaluator from the
 * full log for that (userid, pointid). Every surface (inline quiz, examination,
 * weekly quiz, monthly probe) funnels through here — one write path.
 *
 * GDPR: this table has no delete callback and no FKs; erasure of a member's
 * formation record is an explicit DELETE WHERE userid=? performed by the
 * depthcontent core_privacy provider (+ the ops#93 round-trip), NOT by Moodle
 * cascade and NOT by a `--clear` render rebuild. No per-(user,pointid)
 * confidence flag is stored: `confidence` is a transient signal on the log row
 * only, used in-request for the grade/anti-guess guard and later retention-pruned.
 *
 * @param array $e Event: {userid, pointid, item_id, outcome, item_type,
 *                  cognition, core_accountable, single_tag, confidence,
 *                  latency_ms, mode, context, grade, near, bank_size}
 * @return \stdClass The upserted mastery row.
 */
function depthcontent_apply_retrieval(array $e) {
    global $DB;

    $now = (int) ($e['ts'] ?? time());
    $userid = (int) $e['userid'];
    $pointid = (string) $e['pointid'];
    $correct = (int) ($e['outcome'] ?? 0);

    // ops#118 Art. 9 gate: for a Trialing (non-consented) member, do NOT append
    // to the append-only retrieval log and do NOT upsert the mastery ledger.
    // Return an ephemeral, unsaved mastery row so callers never break.
    if (!depthcontent_may_keep_formation($userid)) {
        debugging('depthcontent: skipped retrieval_log + mastery persist for '
            . 'non-consented (Art.9/Trialing) userid=' . $userid, DEBUG_DEVELOPER);
        return $DB->get_record('depthcontent_mastery',
            ['userid' => $userid, 'pointid' => $pointid])
            ?: (object) ['userid' => $userid, 'pointid' => $pointid, 'status' => 'new'];
    }

    $grade = isset($e['grade']) ? (int) $e['grade']
        : depthcontent_grade_from_outcome($correct, $e['confidence'] ?? null,
            $e['latency_ms'] ?? null, $e['median_latency'] ?? null, !empty($e['near']));

    // 1. APPEND the retrieval log (append-only; the FSRS training set).
    $log = (object) [
        'userid'           => $userid,
        'pointid'          => $pointid,
        'ts'               => $now,
        'outcome'          => $correct,
        'grade'            => $grade,
        'item_id'          => (string) ($e['item_id'] ?? ''),
        'item_type'        => $e['item_type'] ?? null,
        'cognition'        => $e['cognition'] ?? null,
        'core_accountable' => isset($e['core_accountable']) ? (int) $e['core_accountable'] : 1,
        'single_tag'       => isset($e['single_tag']) ? (int) $e['single_tag'] : 1,
        'confidence'       => $e['confidence'] ?? null,   // transient; retention-pruned.
        'latency_ms'       => $e['latency_ms'] ?? null,
        'mode'             => $e['mode'] ?? null,
        'context'          => $e['context'] ?? null,      // provenance only, never a key.
    ];
    $DB->insert_record('depthcontent_retrieval_log', $log);

    // 2. Load the full log for this (userid, pointid) and run the PURE evaluators.
    $rows = [];
    $recs = $DB->get_records('depthcontent_retrieval_log',
        ['userid' => $userid, 'pointid' => $pointid], 'ts ASC');
    foreach ($recs as $r) {
        $rows[] = [
            'ts'               => (int) $r->ts,
            'outcome'          => (int) $r->outcome,
            'item_id'          => (string) $r->item_id,
            'item_type'        => $r->item_type,
            'cognition'        => $r->cognition,
            'core_accountable' => (bool) $r->core_accountable,
            'single_tag'       => (bool) $r->single_tag,
            'confidence'       => isset($r->confidence) ? (int) $r->confidence : null,
        ];
    }
    $thresholds = depthcontent_get_completion_defaults();
    $banksize = isset($e['bank_size']) ? (int) $e['bank_size'] : null;
    $state = \mod_depthcontent\mastery\evaluator::evaluate($rows, $thresholds, $banksize);

    // 3. Upsert the mastery row: SM-2 scheduler + evaluator-derived attainment.
    $row = $DB->get_record('depthcontent_mastery', ['userid' => $userid, 'pointid' => $pointid]);
    $isnew = !$row;
    if ($isnew) {
        $row = (object) [
            'userid' => $userid, 'pointid' => $pointid,
            'ease_factor' => 2.50, 'interval_days' => 1, 'repetitions' => 0, 'lapses' => 0,
        ];
    }
    $next = depthcontent_sm2_step([
        'ease_factor'   => $row->ease_factor,
        'interval_days' => $row->interval_days,
        'repetitions'   => $row->repetitions,
        'lapses'        => $row->lapses,
    ], $grade);
    $row->ease_factor   = $next['ease_factor'];
    $row->interval_days = $next['interval_days'];
    $row->repetitions   = $next['repetitions'];
    $row->lapses        = $next['lapses'];
    $row->next_review   = $now + ($row->interval_days * 86400);
    $row->last_reviewed = $now;

    // Attainment (monotonic) — evaluators are the source of truth.
    $row->act_at            = (int) $state['act_at'];
    $row->act_confirmed     = $state['act_confirmed'] ? 1 : 0;
    if (empty($row->act_via) && $row->act_at > 0) {
        $row->act_via = $e['mode'] ?? 'inline';
    }
    $row->habit_at          = (int) $state['habit_at'];
    $row->habit_streak      = (int) $state['habit_streak'];
    $row->first_success_at  = (int) $state['first_success_at'];
    $row->last_success_at   = (int) $state['last_success_at'];
    $row->character_at       = (int) $state['character_at'];
    $row->char_window_start  = (int) $state['char_window_start'];
    $row->probes_answered    = (int) $state['probes_answered'];
    $row->distinct_items_correct = (int) $state['distinct_items_correct'];
    $row->last_transfer_ok   = $state['last_transfer_ok'] ? 1 : 0;
    $row->status             = $state['status'];
    $row->lapsed             = $state['lapsed'] ? 1 : 0;
    $row->timemodified       = $now;

    if ($isnew) {
        $row->id = $DB->insert_record('depthcontent_mastery', $row);
    } else {
        $DB->update_record('depthcontent_mastery', $row);
    }
    return $row;
}

/**
 * Get all learning points due for review for a user in a course.
 */
function depthcontent_get_due_reviews($userid, $courseid = 0) {
    global $DB;

    $now = time();
    $sql = "SELECT sr.*, dc.name, dc.pointid, dc.content_json, cm.id AS cmid
              FROM {depthcontent_sr} sr
              JOIN {depthcontent} dc ON dc.id = sr.depthcontentid
              JOIN {course_modules} cm ON cm.instance = dc.id
              JOIN {modules} m ON m.id = cm.module AND m.name = 'depthcontent'
             WHERE sr.userid = :userid
               AND sr.next_review <= :now
               AND sr.repetitions > 0";
    $params = ['userid' => $userid, 'now' => $now];

    if ($courseid > 0) {
        $sql .= " AND dc.course = :courseid";
        $params['courseid'] = $courseid;
    }

    $sql .= " ORDER BY sr.next_review ASC";

    return $DB->get_records_sql($sql, $params);
}
