<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The member-facing Plan-of-Love / Rule-of-Life surface.
 *
 * Lists the member's OWN checkpoints (their plan) with tick controls and
 * engagement history. SURFACING FIREWALL: only the member sees their own
 * detail — there is no path here to another member's plan. The member may
 * title their own plan ("Plan of Love" / "Rule of Life" / free text).
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');
require_once($CFG->dirroot . '/local/practice/lib.php');

require_login();
$context = context_system::instance();
require_capability('local/practice:use', $context);

$userid = $USER->id; // Always the current member — never a parameter (firewall).

$PAGE->set_url(new moodle_url('/local/practice/plan.php'));
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');

// The member's own plan title (a user preference; default from the naming config).
$plantitle = get_user_preferences('local_practice_plan_title', get_string('planoflove', 'local_practice'), $userid);

$PAGE->set_title($plantitle);
$PAGE->set_heading($plantitle);

// --- Handle a tick / untick (the ONE write path is engaged()). ---------------
$action = optional_param('action', '', PARAM_ALPHA);         // tick | untick | setview
$uid    = optional_param('uid', '', PARAM_RAW_TRIMMED);      // checkpoint_uid
if ($action && confirm_sesskey()) {
    if ($action === 'tick' && $uid) {
        // An explicit member tick (source=manual) — the only way to engage a habit.
        local_practice_engaged($uid, $userid, null, 'manual');
    } else if ($action === 'untick' && $uid) {
        // Untick-to-stay: a 'cleared' event beats any auto mark for today.
        local_practice_engaged($uid, $userid, null, 'cleared');
    } else if ($action === 'setview') {
        // Change the progression-view preference (DISPLAY only — never touches data).
        local_practice_set_progression_view($userid, optional_param('view', '', PARAM_ALPHA));
    }
    redirect($PAGE->url, get_string('changessaved'), 0);
}

// The member's own progression-view preference (full | gentle | quiet; default gentle).
$progressionview = local_practice_get_progression_view($userid);

$plan = local_practice_get_plan($userid);

echo $OUTPUT->header();

if (empty($plan)) {
    echo $OUTPUT->notification(get_string('noitems', 'local_practice'), 'info');
    echo $OUTPUT->footer();
    exit;
}

$typelabels = [
    'task'  => get_string('type_task', 'local_practice'),
    'skill' => get_string('type_skill', 'local_practice'),
    'habit' => get_string('type_habit', 'local_practice'),
];

$table = new html_table();
$table->head = [
    get_string('type_task', 'local_practice') . ' / ' .
        get_string('type_skill', 'local_practice') . ' / ' .
        get_string('type_habit', 'local_practice'),
    get_string('myplan', 'local_practice'),
    get_string('progressionview', 'local_practice'),
    get_string('lastengaged', 'local_practice'),
    '',
];
$table->attributes['class'] = 'generaltable local-practice-plan';

foreach ($plan as $item) {
    $typlabel = $typelabels[$item->type] ?? s($item->type);
    $statuslabel = get_string('status_' . $item->status, 'local_practice');

    $title = s($item->title);
    if (!empty($item->tombstoned)) {
        $title .= ' <span class="badge badge-secondary">' .
            get_string('retired', 'local_practice') . '</span>';
    }
    // Surface the member's if-then anchor (implementation intention) on the grid.
    if (!empty($item->anchor_plan)) {
        $title .= '<br><small class="text-muted"><em>' .
            get_string('anchorplan', 'local_practice') . ': ' . s($item->anchor_plan) . '</em></small>';
    }

    // Progression rendering, governed by the member's own progression-view mode.
    $prog = local_practice_progression_for($item, $userid);
    if (!empty($prog['suppressed'])) {
        // Quiet mode — the member just does the next thing (data still recorded).
        $progcell = '<span class="text-muted">·</span>';
    } else {
        $progcell = '<span title="' . s($prog['framing']) . '">' .
            s($prog['state_symbol']) . ' ' .
            get_string($prog['state_label_key'], 'local_practice') . '</span>';
        if (!empty($prog['renewal_due'])) {
            $progcell .= ' <span class="badge badge-info">' .
                get_string('renewaldue', 'local_practice') . '</span>';
        }
        if (isset($prog['lifetime_count'])) {
            // Full mode only — the fidelity LIFETIME count (never a resettable streak).
            $progcell .= '<br><small class="text-muted">' .
                get_string('lifetimecount', 'local_practice') . ': ' . (int) $prog['lifetime_count'] . '</small>';
        }
    }

    $last = $item->last_engaged_date
        ? userdate(strtotime((string) $item->last_engaged_date), get_string('strftimedate', 'langconfig'))
        : '—';

    // Controls: an explicit tick, and an untick (untick-to-stay). Retired
    // checkpoints accept no new marks (engaged() rejects them server-side too).
    $controls = '';
    if (empty($item->tombstoned)) {
        $tickurl = new moodle_url($PAGE->url,
            ['action' => 'tick', 'uid' => $item->checkpoint_uid, 'sesskey' => sesskey()]);
        $untickurl = new moodle_url($PAGE->url,
            ['action' => 'untick', 'uid' => $item->checkpoint_uid, 'sesskey' => sesskey()]);
        $controls = html_writer::link($tickurl, get_string('tick', 'local_practice'),
                ['class' => 'btn btn-sm btn-primary']) . ' ' .
            html_writer::link($untickurl, get_string('untick', 'local_practice'),
                ['class' => 'btn btn-sm btn-outline-secondary']);
    }

    $table->data[] = [
        $typlabel,
        $title . '<br><small class="text-muted">' . $statuslabel . '</small>',
        $progcell,
        $last,
        $controls,
    ];
}

echo html_writer::table($table);

// The grace/gratitude framing line (never performance framing) — shown unless quiet.
if ($progressionview !== 'quiet') {
    echo html_writer::tag('p',
        \local_practice\progression::grace_framing($progressionview),
        ['class' => 'text-muted small font-italic']);
}

// Progression-view chooser (DISPLAY only — all progress is always recorded).
$viewlinks = [];
foreach (\local_practice\progression::MODES as $mode) {
    $label = get_string('pview_' . $mode, 'local_practice');
    if ($mode === $progressionview) {
        $viewlinks[] = '<strong>' . $label . '</strong>';
    } else {
        $url = new moodle_url($PAGE->url,
            ['action' => 'setview', 'view' => $mode, 'sesskey' => sesskey()]);
        $viewlinks[] = html_writer::link($url, $label);
    }
}
echo html_writer::tag('p',
    get_string('progressionview', 'local_practice') . ': ' . implode(' · ', $viewlinks),
    ['class' => 'text-muted small']);

echo html_writer::tag('p',
    get_string('history', 'local_practice') . ': ' .
    html_writer::link(
        new moodle_url('/local/practice/plan.php'),
        get_string('myplan', 'local_practice')),
    ['class' => 'text-muted small']);

echo $OUTPUT->footer();
