<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Table-driven unit tests for the MENTOR FIREWALL (local_mentor, build #5).
 *
 * Runs WITHOUT a Moodle runtime:  php tests/firewall_test.php
 *
 * Proves the hard firewall (FORMATION-MASTER-DESIGN §4; ux §4.2/§4.5):
 *   - PUSH-ONLY: assemble_mentor_view() derives ONLY from stored (pushed) shares;
 *     an active grant with NO pushes shows nothing; the mentor cannot pull.
 *   - The choke point resolves to NO access the instant the grant is inactive
 *     (revoked/paused/expired/invited/covenant-less), regardless of stray shares.
 *   - FORBIDDEN-FIELD firewall: a mentor-visible payload contains NONE of the
 *     forbidden fields (tick grids, reflections, analytics, counts/streaks,
 *     timestamps, comparison) AND NONE of the doctrine-level knowing fields
 *     (belief/error/doctrine/quiz/mastery/knowing). Mirrors contains_comparison().
 *   - NO-AI / NO-DOCTRINAL-REACH invariant: the assembly path touches only shares
 *     + the coarse gentle view; a forbidden field can neither be BUILT into a share
 *     nor SURVIVE assembly (it is stripped on push, and trips a runtime guard).
 *   - Tier-scoped share building (coarse / engagement / detail) over REAL engine state.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
require_once(__DIR__ . '/../../practice/classes/engine.php');
require_once(__DIR__ . '/../../practice/classes/progression.php');
require_once(__DIR__ . '/../classes/mentor.php');

use local_mentor\mentor;
use local_practice\engine;
use local_practice\progression;

// ---- Tiny assertion harness ------------------------------------------------
$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
$GLOBALS['__fails'] = [];

function check(string $name, $expected, $actual): void {
    if ($expected === $actual) {
        $GLOBALS['__pass']++;
    } else {
        $GLOBALS['__fail']++;
        $GLOBALS['__fails'][] = sprintf("  FAIL: %s\n        expected=%s got=%s",
            $name, var_export($expected, true), var_export($actual, true));
    }
}

const BASE = 1700000000;
const DAY = 86400;
function e(int $ymd, string $source = 'manual', int $dayoffset = 0): array {
    return ['ts' => BASE + $dayoffset * DAY, 'localdate' => $ymd, 'source' => $source];
}

// Genuine recorded state via the REAL practice engine (never hand-faked numbers).
$fast = ['habit_form_count' => ['daily' => 3], 'habit_span_floor_days' => ['daily' => 3]];
$log3 = [e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260703, 'manual', 2)];
$heldstate = engine::derive($log3, ['type' => 'habit', 'cadence' => 'daily', 'on_consolidate' => 'keep'], $fast);
$formingstate = engine::derive([e(20260701, 'manual', 0)], ['type' => 'habit', 'cadence' => 'daily'], $fast);

// A member's plan the tests push from. One item is PERSONAL (default hidden).
$items = [
    ['uid' => 'B5.mp', 'title' => 'Mental prayer', 'rule_shape' => 'daily rule',
     'personal' => false, 'state' => $heldstate, 'note' => 'going slowly but daily'],
    ['uid' => 'B5.examen', 'title' => 'Examen', 'rule_shape' => 'daily rule',
     'personal' => false, 'state' => $formingstate],
    ['uid' => 'B5.secret', 'title' => 'A private struggle', 'rule_shape' => 'weekly practice',
     'personal' => true, 'state' => $formingstate],
    ['plan_note' => 'Trying to keep a quiet morning rhythm.'],
];

// A live, covenant-accepted, unexpired grant.
$active = mentor::accept_covenant(mentor::new_relationship(10, 20, 'engagement', 20260720, 20261018));

// ===========================================================================
// TIER-SCOPED SHARE BUILDING (the PUSH side) over real engine state
// ===========================================================================

$coarse = mentor::build_share_payload($items, 'coarse');
check('BUILD.coarse_has_rule_shape', true, array_key_exists('rule_shape', $coarse));
check('BUILD.coarse_shapes_deduped_sorted', ['daily rule', 'weekly practice'], $coarse['rule_shape']);
check('BUILD.coarse_has_notes', 'Trying to keep a quiet morning rhythm.', $coarse['notes']);
check('BUILD.coarse_no_items', false, array_key_exists('items', $coarse));     // no per-item at coarse.
check('BUILD.coarse_framing_grace', true, stripos($coarse['framing'], 'grace') !== false);

$eng = mentor::build_share_payload($items, 'engagement', [], 20260710);
check('BUILD.engagement_has_items', true, array_key_exists('items', $eng));
// Two visible items (mp + examen); the personal one is hidden by default.
check('BUILD.engagement_hides_personal', 2, count($eng['items']));
$uids = array_column($eng['items'], 'uid');
check('BUILD.engagement_shows_mp', true, in_array('B5.mp', $uids, true));
check('BUILD.engagement_hides_secret', false, in_array('B5.secret', $uids, true));
check('BUILD.engagement_has_private_flag', true, $eng['has_private']);
// Coarse STATE projected from the gentle view — state present, but NO count/growth.
$mpentry = $eng['items'][array_search('B5.mp', $uids, true)];
check('BUILD.engagement_item_has_state', true, array_key_exists('state', $mpentry));
check('BUILD.engagement_item_state_held', progression::STATE_HELD, $mpentry['state']);
check('BUILD.engagement_item_no_lifetime', false, array_key_exists('lifetime_count', $mpentry));
check('BUILD.engagement_item_no_growth', false, array_key_exists('growth', $mpentry));
check('BUILD.engagement_no_elected_note', false, array_key_exists('elected_note', $mpentry)); // detail-only.

// DETAIL tier: adds the member's per-item elected note; can show the personal item via override.
$detail = mentor::build_share_payload($items, 'detail', ['B5.secret' => 'show'], 20260710);
$duids = array_column($detail['items'], 'uid');
check('BUILD.detail_shows_secret_on_override', true, in_array('B5.secret', $duids, true));
$dmp = $detail['items'][array_search('B5.mp', $duids, true)];
check('BUILD.detail_has_elected_note', 'going slowly but daily', $dmp['elected_note']);

// ===========================================================================
// FORBIDDEN-FIELD FIREWALL — no built share carries a forbidden field
// ===========================================================================

check('FW.coarse_clean', false, mentor::contains_forbidden($coarse));
check('FW.engagement_clean', false, mentor::contains_forbidden($eng));
check('FW.detail_clean', false, mentor::contains_forbidden($detail));

// The guard actually DETECTS each forbidden category (proves it is not a no-op).
check('FW.detects_tickgrid', true, mentor::contains_forbidden(['tick_grid' => [1, 0, 1]]));
check('FW.detects_marks', true, mentor::contains_forbidden(['week_marks' => []]));
check('FW.detects_reflection', true, mentor::contains_forbidden(['reflection' => 'x']));
check('FW.detects_streak', true, mentor::contains_forbidden(['streak' => 9]));
check('FW.detects_count', true, mentor::contains_forbidden(['lifetime_count' => 9]));
check('FW.detects_timestamp', true, mentor::contains_forbidden(['tick_timestamp' => 1]));
check('FW.detects_comparison', true, mentor::contains_forbidden(['peer_percentile' => 90]));
check('FW.detects_nested', true, mentor::contains_forbidden(['ok' => 1, 'n' => ['leaderboard_rank' => 2]]));

// DOCTRINE-LEVEL knowing fields — NEVER shareable, even to a mentor.
check('FW.detects_belief', true, mentor::contains_forbidden(['belief_state' => 'held']));
check('FW.detects_error', true, mentor::contains_forbidden(['error_held' => true]));
check('FW.detects_doctrine', true, mentor::contains_forbidden(['doctrine_mastery' => 'act']));
check('FW.detects_quiz', true, mentor::contains_forbidden(['quiz_score' => 5]));
check('FW.detects_mastery', true, mentor::contains_forbidden(['mastery' => 'character']));
check('FW.detects_knowing', true, mentor::contains_forbidden(['knowing_ledger' => []]));

// strip_forbidden REMOVES a doctrine/tick field even if a caller injects one.
$dirty = ['tier' => 'coarse', 'belief' => 'held', 'tick_grid' => [1, 1],
          'items' => [['uid' => 'x', 'state' => 'held', 'quiz_score' => 3]]];
$clean = mentor::strip_forbidden($dirty);
check('FW.strip_removes_belief', false, array_key_exists('belief', $clean));
check('FW.strip_removes_tickgrid', false, array_key_exists('tick_grid', $clean));
check('FW.strip_removes_nested_quiz', false, array_key_exists('quiz_score', $clean['items'][0]));
check('FW.strip_keeps_legit', 'coarse', $clean['tier']);
check('FW.strip_keeps_nested_state', 'held', $clean['items'][0]['state']);
check('FW.strip_result_clean', false, mentor::contains_forbidden($clean));

// build_share_payload STRIPS a would-be-injected forbidden field structurally:
// the member's own title/note is free text (values), but a forbidden KEY cannot survive.
$inject = [['uid' => 'B5.mp', 'title' => 'Mental prayer', 'rule_shape' => 'daily rule',
    'personal' => false, 'state' => $heldstate, 'streak' => 40, 'reflection_body' => 'secret']];
$built = mentor::build_share_payload($inject, 'engagement');
check('FW.build_drops_injected_streak', false, mentor::contains_forbidden($built));

// ===========================================================================
// PUSH-ONLY CHOKE POINT — mentor view derives ONLY from stored shares
// ===========================================================================

// The share the member pushed (engagement tier).
$pushedpayload = mentor::build_share_payload($items, 'engagement', [], 20260710);
$shares = [
    ['menteeid' => 10, 'mentorid' => 20, 'tier' => 'engagement', 'shared_on' => 20260801, 'payload' => $pushedpayload],
];

$view = mentor::assemble_mentor_view($active, $shares, 20260901);
check('PUSH.access_granted', true, $view['access']);
check('PUSH.pushed_true', true, $view['pushed']);
check('PUSH.view_payload_is_the_pushed_one', $pushedpayload, $view['payload']);
check('PUSH.view_shared_on', 20260801, $view['shared_on']);
check('PUSH.view_never_forbidden', false, mentor::contains_forbidden($view['payload']));

// Latest snapshot wins when several are pushed.
$shares2 = [
    ['menteeid' => 10, 'mentorid' => 20, 'tier' => 'engagement', 'shared_on' => 20260801, 'payload' => ['tier' => 'engagement', 'notes' => 'old']],
    ['menteeid' => 10, 'mentorid' => 20, 'tier' => 'engagement', 'shared_on' => 20260815, 'payload' => ['tier' => 'engagement', 'notes' => 'new']],
];
check('PUSH.latest_snapshot_wins', 'new', mentor::assemble_mentor_view($active, $shares2, 20260901)['payload']['notes']);

// ACTIVE grant but NOTHING pushed => mentor sees nothing (cannot pull live state).
check('PUSH.active_but_no_push_shows_nothing', false, mentor::assemble_mentor_view($active, [], 20260901)['pushed']);
check('PUSH.active_but_no_push_empty_payload', [], mentor::assemble_mentor_view($active, [], 20260901)['payload']);

// Shares for a DIFFERENT pair are ignored (choke point filters by pair).
$otherpairshares = [
    ['menteeid' => 99, 'mentorid' => 20, 'tier' => 'engagement', 'shared_on' => 20260815, 'payload' => ['tier' => 'engagement', 'notes' => 'not yours']],
];
check('PUSH.other_pair_ignored', false, mentor::assemble_mentor_view($active, $otherpairshares, 20260901)['pushed']);

// ===========================================================================
// NO ACCESS the instant the grant is inactive — even with stray pushed shares
// ===========================================================================

$revoked = mentor::revoke($active, 'member');
check('NOACCESS.revoked_no_access', false, mentor::assemble_mentor_view($revoked, $shares, 20260901)['access']);
check('NOACCESS.revoked_view_is_only_access_false', ['access' => false],
    mentor::assemble_mentor_view($revoked, $shares, 20260901));

$paused = $active; $paused['status'] = mentor::STATUS_PAUSED;
check('NOACCESS.paused_no_access', false, mentor::assemble_mentor_view($paused, $shares, 20260901)['access']);

$expired = $active; // same grant, asof past renews_at.
check('NOACCESS.expired_no_access', false, mentor::assemble_mentor_view($expired, $shares, 20261101)['access']);

$invited = mentor::new_relationship(10, 20, 'engagement', 20260720, 20261018);
check('NOACCESS.invited_no_access', false, mentor::assemble_mentor_view($invited, $shares, 20260901)['access']);

$nocov = $active; $nocov['covenant_accepted'] = 0;
check('NOACCESS.covenantless_no_access', false, mentor::assemble_mentor_view($nocov, $shares, 20260901)['access']);

// ===========================================================================
// NO-AI / NO-DOCTRINAL-REACH runtime tripwire — a forbidden field FAILS CLOSED
// ===========================================================================

// A maliciously/mistakenly stored share carrying a doctrine field must NOT render:
// assemble_mentor_view() throws rather than leak it (fail closed).
$dirtyshare = [
    ['menteeid' => 10, 'mentorid' => 20, 'tier' => 'engagement', 'shared_on' => 20260815,
     'payload' => ['tier' => 'engagement', 'items' => [['uid' => 'x', 'belief_state' => 'held']]]],
];
$threw = false;
try {
    mentor::assemble_mentor_view($active, $dirtyshare, 20260901);
} catch (\RuntimeException $ex) {
    $threw = true;
}
check('NOAI.forbidden_share_fails_closed', true, $threw);

// The documented invariant, asserted structurally: the ONLY member-data inputs the
// choke point reads are (a) the shares array and (b) — on the push side — the
// coarse gentle view. Neither can carry a doctrine-level field: the gentle
// projection allowlists 4 coarse keys, and every stored share is stripped + guarded.
$engview = mentor::coarse_state_projection($heldstate, 20260710);
check('NOAI.gentle_projection_keys', ['state', 'state_symbol', 'milestones', 'renewal_due'], array_keys($engview));
check('NOAI.gentle_projection_no_count', false, array_key_exists('lifetime_count', $engview));
check('NOAI.gentle_projection_no_growth', false, array_key_exists('growth', $engview));
check('NOAI.gentle_projection_clean', false, mentor::contains_forbidden($engview));

// ---- Report ----------------------------------------------------------------
$total = $GLOBALS['__pass'] + $GLOBALS['__fail'];
echo "\nlocal_mentor firewall (push-only + forbidden-field + no-AI) tests\n";
echo str_repeat('-', 58) . "\n";
if ($GLOBALS['__fail'] > 0) {
    echo implode("\n", $GLOBALS['__fails']) . "\n";
}
printf("%d/%d checks passed (%d failed)\n", $GLOBALS['__pass'], $total, $GLOBALS['__fail']);
exit($GLOBALS['__fail'] === 0 ? 0 : 1);
