<?php

namespace format_tabbed\output\courseformat;

use core_courseformat\output\local\content as content_base;
use renderer_base;

class content extends content_base {

    protected $hasaddsection = true;

    public function export_for_template(renderer_base $output) {
        global $PAGE;
        // Load topics format JS (for reactive course editing).
        $PAGE->requires->js_call_amd('format_topics/mutations', 'init');
        $PAGE->requires->js_call_amd('format_topics/section', 'init');
        // Load our tabbed UI JS.
        $PAGE->requires->js_call_amd('format_tabbed/tabbed', 'init');
        return parent::export_for_template($output);
    }
}
