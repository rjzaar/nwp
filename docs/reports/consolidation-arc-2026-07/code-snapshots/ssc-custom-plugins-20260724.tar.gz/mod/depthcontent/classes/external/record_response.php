<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Record inline quiz response.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_depthcontent\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;

class record_response extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
            'quizitemid' => new external_value(PARAM_TEXT, 'Quiz item ID'),
            'response' => new external_value(PARAM_TEXT, 'User response'),
            'correct' => new external_value(PARAM_INT, '1 if correct, 0 if not'),
            // SR-signal repair inputs (all optional / backward-compatible).
            'confidence' => new external_value(PARAM_INT, 'Transient 1-tap confidence 1..3 (1=guessing)', VALUE_DEFAULT, 0),
            'latencyms' => new external_value(PARAM_INT, 'Answer latency in ms', VALUE_DEFAULT, 0),
            'itemtype' => new external_value(PARAM_ALPHA, 'multichoice|truefalse|shortanswer', VALUE_DEFAULT, ''),
            'cognition' => new external_value(PARAM_ALPHA, 'recall|apply|discern', VALUE_DEFAULT, ''),
            'coreaccountable' => new external_value(PARAM_INT, '1 if the item moves the ledger (MF-4)', VALUE_DEFAULT, 1),
            'singletag' => new external_value(PARAM_INT, '1 if the item tags exactly one pointid (MF-D)', VALUE_DEFAULT, 1),
        ]);
    }

    public static function execute(int $cmid, string $quizitemid, string $response, int $correct,
            int $confidence = 0, int $latencyms = 0, string $itemtype = '', string $cognition = '',
            int $coreaccountable = 1, int $singletag = 1): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'cmid' => $cmid,
            'quizitemid' => $quizitemid,
            'response' => $response,
            'correct' => $correct,
            'confidence' => $confidence,
            'latencyms' => $latencyms,
            'itemtype' => $itemtype,
            'cognition' => $cognition,
            'coreaccountable' => $coreaccountable,
            'singletag' => $singletag,
        ]);

        $cm = get_coursemodule_from_id('depthcontent', $params['cmid'], 0, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/depthcontent:view', $context);

        $record = new \stdClass();
        $record->userid = $USER->id;
        $record->depthcontentid = $cm->instance;
        $record->quizitemid = $params['quizitemid'];
        $record->response = json_encode($params['response']);
        $record->correct = $params['correct'];
        $record->timecreated = time();

        $DB->insert_record('depthcontent_responses', $record);

        // Update progress status to 'learning' if currently 'new'.
        $progress = $DB->get_record('depthcontent_progress', [
            'userid' => $USER->id,
            'depthcontentid' => $cm->instance,
        ]);
        if ($progress && $progress->status === 'new') {
            $progress->status = 'learning';
            $progress->timemodified = time();
            $DB->update_record('depthcontent_progress', $progress);
        }

        require_once($GLOBALS['CFG']->dirroot . '/mod/depthcontent/lib.php');

        // SR-signal repair: the old correct-only guard is GONE. Every outcome
        // (right OR wrong) now reaches the scheduler, mapped to a real grade.
        $conf = $params['confidence'] > 0 ? $params['confidence'] : null;
        $lat = $params['latencyms'] > 0 ? $params['latencyms'] : null;
        $grade = depthcontent_grade_from_outcome($params['correct'], $conf, $lat, null, false);

        // Legacy instance-keyed due-queue (repaired: wrong answers reset it too).
        depthcontent_update_sr($USER->id, $cm->instance, $grade);

        // Mastery ledger (pointid-keyed). Resolve the permanent pointid from the
        // activity instance; the orchestrator appends the retrieval log and runs
        // the pure ACT/HABIT/CHARACTER evaluators.
        $dc = $DB->get_record('depthcontent', ['id' => $cm->instance], 'id, pointid', MUST_EXIST);
        depthcontent_apply_retrieval([
            'userid' => $USER->id,
            'pointid' => $dc->pointid,
            'item_id' => $params['quizitemid'],
            'outcome' => $params['correct'],
            'grade' => $grade,
            'item_type' => $params['itemtype'] !== '' ? $params['itemtype'] : null,
            'cognition' => $params['cognition'] !== '' ? $params['cognition'] : null,
            'core_accountable' => $params['coreaccountable'],
            'single_tag' => $params['singletag'],
            'confidence' => $conf,
            'latency_ms' => $lat,
            'mode' => 'inline',
            'context' => 'course:' . $cm->course,
        ]);

        return ['success' => true];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Whether the response was recorded'),
        ]);
    }
}
