INSERT INTO mdl_user VALUES (2,'admin1@school.io');
INSERT INTO mdl_user VALUES (5,'admin2@school.io');
INSERT INTO mdl_user VALUES (9,'user9@example.com');
