<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Table-driven unit tests for the pure mastery evaluators + SR grade mapping.
 *
 * Runs WITHOUT a Moodle runtime:  php tests/mastery_evaluator_test.php
 *
 * We satisfy the MOODLE_INTERNAL guard, load the pure classes/helpers (which
 * make no DB calls at load time), feed synthetic retrieval sequences, and
 * assert the ACT/HABIT/CHARACTER transitions + that the anti-gaming fixes
 * (MF-A span floor, MF-B anti-guess, MF-D single-tag, MF-G band) trip.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
require_once(__DIR__ . '/../classes/mastery/evaluator.php');
require_once(__DIR__ . '/../lib.php');

use mod_depthcontent\mastery\evaluator;

// ---- Tiny assertion harness (no PHPUnit / no Moodle needed) ----------------
$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
$GLOBALS['__fails'] = [];

function check(string $name, $expected, $actual): void {
    if ($expected === $actual) {
        $GLOBALS['__pass']++;
    } else {
        $GLOBALS['__fail']++;
        $GLOBALS['__fails'][] = sprintf("  FAIL: %s\n        expected=%s got=%s",
            $name, var_export($expected, true), var_export($actual, true));
    }
}

const DAY = 86400;
const BASE = 1700000000;

/**
 * Build a retrieval-log row. $day is days since BASE.
 */
function r(int $day, int $outcome, array $opts = []): array {
    static $n = 0;
    $n++;
    return array_merge([
        'ts'               => BASE + $day * DAY,
        'outcome'          => $outcome,
        'item_id'          => $opts['item_id'] ?? ('q' . $n),
        'item_type'        => 'multichoice',
        'cognition'        => 'recall',
        'core_accountable' => true,
        'single_tag'       => true,
        'confidence'       => null,
    ], $opts);
}

$T = evaluator::defaults();

// ===========================================================================
// ACT
// ===========================================================================

// ACT fires on first correct core-accountable item; provisional (lucky MC).
$s = evaluator::evaluate([r(0, 1)], $T);
check('ACT.fires', BASE, $s['act_at']);
check('ACT.provisional_status', 'act', $s['status']);
check('ACT.provisional_not_confirmed', false, $s['act_confirmed']);

// MF-B: a single lucky multichoice GUESS (confidence=1) must NOT confirm ACT.
$s = evaluator::evaluate([r(0, 1, ['confidence' => 1])], $T);
check('MF-B.guess_sets_act_at', BASE, $s['act_at']);
check('MF-B.guess_NOT_confirmed', false, $s['act_confirmed']);

// MF-B: shortanswer (non-guessable) correct confirms ACT immediately.
$s = evaluator::evaluate([r(0, 1, ['item_type' => 'shortanswer'])], $T);
check('MF-B.shortanswer_confirms', true, $s['act_confirmed']);

// MF-B: high confidence (sure=3) confirms ACT immediately.
$s = evaluator::evaluate([r(0, 1, ['confidence' => 3])], $T);
check('MF-B.confidence_sure_confirms', true, $s['act_confirmed']);

// MF-B: provisional guess later CONFIRMED by a second spaced success (streak>=2).
$s = evaluator::evaluate([r(0, 1, ['confidence' => 1]), r(4, 1)], $T);
check('MF-B.second_spaced_confirms', true, $s['act_confirmed']);

// ===========================================================================
// HABIT
// ===========================================================================

// Clean HABIT: d0/d7/d22 spaced successes -> habit at d22 (span 22 >= 21).
$s = evaluator::evaluate([r(0, 1), r(7, 1), r(22, 1)], $T);
check('HABIT.clean_streak', 3, $s['habit_streak']);
check('HABIT.clean_attained_at', BASE + 22 * DAY, $s['habit_at']);
check('HABIT.clean_status', 'habit', $s['status']);

// MF-A: d0/d3/d6 are each >=3d apart (streak reaches 3) but span only 6d
//       => HABIT must NOT be granted (the 6-day gaming vector is closed).
$s = evaluator::evaluate([r(0, 1), r(3, 1), r(6, 1)], $T);
check('MF-A.streak3_but_short_span', 3, $s['habit_streak']);
check('MF-A.no_habit_within_6_days', 0, $s['habit_at']);

// MF-A: a 4th counted success at d21 extends the span to 21 -> HABIT granted.
$s = evaluator::evaluate([r(0, 1), r(3, 1), r(6, 1), r(21, 1)], $T);
check('MF-A.span_reached_grants_habit', BASE + 21 * DAY, $s['habit_at']);

// Anti-cram: d0/d1/d2 (gaps < 3d) count only once -> streak stays 1.
$s = evaluator::evaluate([r(0, 1), r(1, 1), r(2, 1)], $T);
check('HABIT.anticram_streak1', 1, $s['habit_streak']);
check('HABIT.anticram_no_habit', 0, $s['habit_at']);

// MF-D: three spaced successes on a MULTI-TAG item must NOT pump HABIT
//       (single_tag=false) — but ACT may still be written.
$multi = ['single_tag' => false];
$s = evaluator::evaluate([r(0, 1, $multi), r(7, 1, $multi), r(22, 1, $multi)], $T);
check('MF-D.multitag_no_habit', 0, $s['habit_at']);
check('MF-D.multitag_streak_zero', 0, $s['habit_streak']);
check('MF-D.multitag_still_acts', BASE, $s['act_at']);

// Lapse: after HABIT, a miss resets streak, flags lapsed, regresses live status
//        to 'act' — but habit_at (the attainment) is NOT cleared.
$s = evaluator::evaluate([r(0, 1), r(7, 1), r(22, 1), r(30, 0)], $T);
check('LAPSE.habit_at_retained', BASE + 22 * DAY, $s['habit_at']);
check('LAPSE.streak_reset', 0, $s['habit_streak']);
check('LAPSE.flag_set', true, $s['lapsed']);
check('LAPSE.status_regressed_to_act', 'act', $s['status']);

// MF-4 firewall: a NON-core-accountable correct item moves nothing.
$s = evaluator::evaluate([r(0, 1, ['core_accountable' => false])], $T);
check('MF-4.non_core_no_act', 0, $s['act_at']);

// ===========================================================================
// CHARACTER
// ===========================================================================

/**
 * A clean character-eligible sequence: habit by d22, then probes spanning
 * >365d with >=3 distinct items, a >=60d lag, a transfer item, and >=2
 * shortanswer correct.
 */
function character_sequence(): array {
    return [
        // Habit pump.
        r(0, 1, ['item_id' => 'qh']),
        r(7, 1, ['item_id' => 'qh']),
        r(22, 1, ['item_id' => 'qh']),          // habit_at here; window_start=d22.
        // Probes.
        r(52,  1, ['item_id' => 'qa', 'item_type' => 'shortanswer']),                 // short #1
        r(112, 1, ['item_id' => 'qb', 'item_type' => 'shortanswer']),                 // short #2, lag 60d
        r(200, 1, ['item_id' => 'qc', 'cognition' => 'apply']),                       // transfer
        r(300, 1, ['item_id' => 'qd']),
        r(390, 1, ['item_id' => 'qe', 'cognition' => 'discern']),                     // span 368d
    ];
}

// Full pass with an adequate bank (>=4).
$s = evaluator::evaluate(character_sequence(), $T, 6);
check('CHAR.attained_at', BASE + 390 * DAY, $s['character_at']);
check('CHAR.status', 'character', $s['status']);
check('CHAR.distinct_items', 6, $s['distinct_items_correct']);
check('CHAR.transfer_ok', true, $s['last_transfer_ok']);
check('CHAR.window_unchanged', BASE + 22 * DAY, $s['char_window_start']);

// MF-C: bank floor. Same sequence, but only 3 distinct items in the bank
//       -> CHARACTER is unsatisfiable, capped at HABIT.
$s = evaluator::evaluate(character_sequence(), $T, 3);
check('MF-C.bank_below_floor_no_character', 0, $s['character_at']);
check('MF-C.bank_ineligible_flag', false, $s['bank_eligible']);
check('MF-C.capped_at_habit', 'habit', $s['status']);

// MF-G (band): an ISOLATED miss extends the window (does NOT reset it) ->
//              character still attained, window_start unchanged.
$seq = character_sequence();
array_splice($seq, 6, 0, [r(250, 0, ['item_id' => 'qx'])]); // one miss between d200 and d300.
$s = evaluator::evaluate($seq, $T, 6);
check('MF-G.isolated_miss_still_attains', BASE + 390 * DAY, $s['character_at']);
check('MF-G.isolated_miss_window_unchanged', BASE + 22 * DAY, $s['char_window_start']);

// MF-G (band): TWO CONSECUTIVE misses RESET the window to the second miss and
//              clear counters -> not attained; char_window_start moves.
$seq = [
    r(0, 1, ['item_id' => 'qh']),
    r(7, 1, ['item_id' => 'qh']),
    r(22, 1, ['item_id' => 'qh']),                       // habit; window_start=d22.
    r(52,  1, ['item_id' => 'qa', 'item_type' => 'shortanswer']),
    r(112, 1, ['item_id' => 'qb', 'item_type' => 'shortanswer']),
    r(150, 0, ['item_id' => 'qc']),                      // miss 1 (isolated so far).
    r(160, 0, ['item_id' => 'qd']),                      // miss 2 -> RESET to d160.
    r(200, 1, ['item_id' => 'qe']),
];
$s = evaluator::evaluate($seq, $T, 6);
check('MF-G.two_consecutive_reset_window', BASE + 160 * DAY, $s['char_window_start']);
check('MF-G.two_consecutive_no_character', 0, $s['character_at']);

// CHARACTER needs a shortanswer floor: an all-multichoice probe set (no
// shortanswer) must NOT attain even with span+distinct+transfer satisfied.
$seq = [
    r(0, 1, ['item_id' => 'qh']), r(7, 1, ['item_id' => 'qh']), r(22, 1, ['item_id' => 'qh']),
    r(52,  1, ['item_id' => 'qa']),
    r(112, 1, ['item_id' => 'qb']),                       // lag 60d
    r(200, 1, ['item_id' => 'qc', 'cognition' => 'apply']),
    r(300, 1, ['item_id' => 'qd']),
    r(390, 1, ['item_id' => 'qe', 'cognition' => 'discern']),
];
$s = evaluator::evaluate($seq, $T, 6);
check('CHAR.no_shortanswer_blocks', 0, $s['character_at']);

// ===========================================================================
// SR-signal repair: grade mapping + SM-2 lapse counting
// ===========================================================================

check('GRADE.correct_sure=5', 5, depthcontent_grade_from_outcome(1, 3));
check('GRADE.correct_default=4', 4, depthcontent_grade_from_outcome(1, null));
check('GRADE.correct_guessing=3', 3, depthcontent_grade_from_outcome(1, 1));
check('GRADE.correct_slow=3', 3, depthcontent_grade_from_outcome(1, 2, 5000, 2000));
check('GRADE.wrong_near=2', 2, depthcontent_grade_from_outcome(0, null, null, null, true));
check('GRADE.wrong=1', 1, depthcontent_grade_from_outcome(0, null));

// The repaired scheduler counts a lapse on a wrong answer (old guard dropped it).
$st = depthcontent_sm2_step(['ease_factor' => 2.5, 'interval_days' => 15, 'repetitions' => 3, 'lapses' => 0], 1);
check('SM2.wrong_resets_reps', 0, $st['repetitions']);
check('SM2.wrong_resets_interval', 1, $st['interval_days']);
check('SM2.wrong_counts_lapse', 1, $st['lapses']);
$st = depthcontent_sm2_step(['ease_factor' => 2.5, 'interval_days' => 6, 'repetitions' => 2, 'lapses' => 0], 5);
check('SM2.correct_grows_interval', 15, $st['interval_days']);

// ---- Report ----------------------------------------------------------------
$total = $GLOBALS['__pass'] + $GLOBALS['__fail'];
echo "\nMastery evaluator unit tests\n";
echo str_repeat('-', 40) . "\n";
if ($GLOBALS['__fail'] > 0) {
    echo implode("\n", $GLOBALS['__fails']) . "\n";
}
printf("%d/%d checks passed (%d failed)\n", $GLOBALS['__pass'], $total, $GLOBALS['__fail']);
exit($GLOBALS['__fail'] === 0 ? 0 : 1);
