<?php
/**
 * Upgrade script for local_nwc_copyright_sync.
 *
 * @package    local_nwc_copyright_sync
 * @copyright  2026 NWC
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade the plugin.
 *
 * @param int $oldversion the version we are upgrading from
 * @return bool result
 */
function xmldb_local_nwc_copyright_sync_upgrade($oldversion) {
    global $DB;

    // 2026052000 — plugin renamed from local_avc_copyright_sync.
    // Migrate any existing config_plugins rows.
    if ($oldversion < 2026052000) {
        $DB->execute(
            "UPDATE {config_plugins} SET plugin = 'local_nwc_copyright_sync' WHERE plugin = 'local_avc_copyright_sync'"
        );
        upgrade_plugin_savepoint(true, 2026052000, 'local', 'nwc_copyright_sync');
    }

    return true;
}
