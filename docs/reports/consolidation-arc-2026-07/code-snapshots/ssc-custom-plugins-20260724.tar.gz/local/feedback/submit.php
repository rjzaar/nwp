<?php
/**
 * local_feedback — AJAX submit endpoint.
 * Receives a POST from the widget, validates + persists, returns JSON.
 */
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/filelib.php');
require_once(__DIR__ . '/classes/forwarder.php');

header('Content-Type: application/json; charset=utf-8');

function respond($success, $message = '', $extra = []) {
    echo json_encode(array_merge(['success' => (bool)$success, 'message' => $message], $extra));
    exit;
}

// Require POST + sesskey (CSRF)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    respond(false, 'POST required');
}

require_login(null, false, null, false, true);

$sesskey = required_param('sesskey', PARAM_RAW);
if (!confirm_sesskey($sesskey)) {
    respond(false, 'Invalid session key');
}

$context = context_system::instance();
require_capability('local/feedback:submit', $context);

$type       = optional_param('type', 'suggestion', PARAM_ALPHA);
$title      = required_param('title', PARAM_TEXT);
$body       = optional_param('body', '', PARAM_RAW);
$target_url = optional_param('target_url', '', PARAM_TEXT);

if (!in_array($type, ['suggestion', 'question', 'issue', 'praise'], true)) {
    $type = 'suggestion';
}
$title = trim(substr($title, 0, 255));
if ($title === '') {
    respond(false, 'Title is required');
}
$body = trim($body);
$target_url = trim(substr($target_url, 0, 512));

global $USER, $DB;
$now = time();

$record = (object)[
    'type'             => $type,
    'title'            => $title,
    'body'             => $body,
    'target_url'       => $target_url,
    'userid'           => $USER->id,
    'username'         => fullname($USER),
    'email'            => $USER->email,
    'user_agent'       => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512),
    'ipaddress'        => substr(getremoteaddr(), 0, 64),
    'status'           => 'pending',
    'reviewer_userid'  => null,
    'reviewer_comment' => null,
    'reviewed_at'      => null,
    'gitlab_issue_url' => null,
    'gitlab_issue_iid' => null,
    'avc_logged_at'    => null,
    'avc_score_awarded'=> 0,
    'timecreated'      => $now,
    'timemodified'     => $now,
];

try {
    $record->id = $DB->insert_record('local_feedback', $record);
} catch (Exception $e) {
    debugging('local_feedback submit insert failed: ' . $e->getMessage(), DEBUG_DEVELOPER);
    respond(false, 'Could not save feedback');
}

// Fire-and-forget forwarding (errors logged but don't block the user).
try {
    \local_feedback\forwarder::forward_submission($record);
} catch (Throwable $t) {
    debugging('local_feedback forwarder failed: ' . $t->getMessage(), DEBUG_DEVELOPER);
}

// Moodle event class deferred — see classes/event/feedback_submitted.php
// (to be created). Once that exists, uncomment:
// if (class_exists('\\local_feedback\\event\\feedback_submitted')) {
//     $ev = \local_feedback\event\feedback_submitted::create([
//         'context'  => $context,
//         'objectid' => $record->id,
//         'other'    => ['type' => $type, 'title' => $title],
//     ]);
//     $ev->trigger();
// }

respond(true, '', ['id' => $record->id]);
