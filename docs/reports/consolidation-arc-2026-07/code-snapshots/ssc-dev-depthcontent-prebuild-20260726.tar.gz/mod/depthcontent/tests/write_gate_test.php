<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * ops#93 suite: the mod_depthcontent Art. 9 write-gate (skip-persist) logic.
 *
 * Runs WITHOUT a Moodle runtime:  php mod/depthcontent/tests/write_gate_test.php
 *
 * Proves, against the REAL lib.php write paths with a recording fake $DB:
 *   G* depthcontent_may_keep_formation(): fail-closed when the consent
 *      subsystem is absent; delegates to \auth_nwc\consent when present.
 *   P* depthcontent_get_progress(): non-consented member -> EPHEMERAL row
 *      (no insert, no id); consented -> row persisted.
 *   S* depthcontent_update_sr(): non-consented -> ZERO writes, ephemeral
 *      return; consented -> scheduler row inserted/updated.
 *   A* depthcontent_apply_retrieval(): non-consented -> NO retrieval-log
 *      append and NO mastery upsert, ephemeral 'new' row returned;
 *      consented -> log appended + mastery ledger written.
 *   Admin bypass: writes always persist for siteadmins (CLI seeding).
 *
 * ORDER MATTERS: the consent-subsystem-ABSENT case runs BEFORE consent.php is
 * loaded (a class cannot be unloaded), then the class is required and the
 * consented / non-consented behaviour cases run.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
if (!defined('DEBUG_DEVELOPER')) {
    define('DEBUG_DEVELOPER', 32767);
}

// ---- Moodle stubs (global namespace) ---------------------------------------

$GLOBALS['__prefs'] = [];
$GLOBALS['__config'] = [];
$GLOBALS['__admins'] = [];
$GLOBALS['__guests'] = [];
$GLOBALS['__debugging'] = [];

function get_user_preferences($name, $default = null, $userid = 0) {
    return $GLOBALS['__prefs'][$userid][$name] ?? $default;
}
function set_user_preference($name, $value, $userid = 0) {
    $GLOBALS['__prefs'][$userid][$name] = (string) $value;
}
function unset_user_preference($name, $userid = 0) {
    unset($GLOBALS['__prefs'][$userid][$name]);
}
function get_config($component, $name = null) {
    return $GLOBALS['__config']["$component/$name"] ?? false;
}
function is_siteadmin($userid = null) {
    return in_array($userid, $GLOBALS['__admins'], true);
}
function isguestuser($userid = null) {
    return in_array($userid, $GLOBALS['__guests'], true);
}
function debugging($message = '', $level = null, $from = null) {
    $GLOBALS['__debugging'][] = $message;
    return true;
}

/**
 * Recording fake of the tiny slice of $DB the write paths touch.
 * Rows live in-memory per table; every write is journalled in ->writes.
 */
class fake_db {
    public $rows = [];    // [table][] => stdClass with ->id.
    public $writes = [];  // ['insert:table', 'update:table', ...].
    private $nextid = 1;

    public function insert_record($table, $record) {
        $rec = (object) (array) $record;
        $rec->id = $this->nextid++;
        $this->rows[$table][$rec->id] = $rec;
        $this->writes[] = "insert:$table";
        return $rec->id;
    }
    public function update_record($table, $record) {
        $rec = (object) (array) $record;
        $this->rows[$table][$rec->id] = $rec;
        $this->writes[] = "update:$table";
        return true;
    }
    public function get_record($table, array $conditions, $fields = '*', $strictness = 0) {
        foreach ($this->rows[$table] ?? [] as $r) {
            if ($this->matches($r, $conditions)) {
                return clone $r;
            }
        }
        return false;
    }
    public function get_records($table, array $conditions = [], $sort = '', $fields = '*') {
        $out = [];
        foreach ($this->rows[$table] ?? [] as $id => $r) {
            if ($this->matches($r, $conditions)) {
                $out[$id] = clone $r;
            }
        }
        return $out;
    }
    public function count($table) {
        return count($this->rows[$table] ?? []);
    }
    public function writes_for($table) {
        return array_values(array_filter($this->writes,
            fn($w) => str_ends_with($w, ":$table")));
    }
    private function matches($r, array $conditions): bool {
        foreach ($conditions as $k => $v) {
            if (!isset($r->$k) || (string) $r->$k !== (string) $v) {
                return false;
            }
        }
        return true;
    }
}

global $DB;
$DB = new fake_db();

require_once __DIR__ . '/../lib.php';
require_once __DIR__ . '/../classes/mastery/evaluator.php';

// ---- Tiny assertion harness ------------------------------------------------

$pass = 0; $fail = 0;
function check($name, $got, $want) {
    global $pass, $fail;
    if ($got === $want) { echo "  ok   $name\n"; $pass++; }
    else {
        echo "  FAIL $name (got " . var_export($got, true)
            . ", want " . var_export($want, true) . ")\n";
        $fail++;
    }
}

const U_NOCONSENT = 7;   // Member, consent never carried / withheld.
const U_CONSENT   = 8;   // Member with carried Art. 9 consent.
const U_ADMIN     = 9;   // Siteadmin (never gated).

// ============================================================================
// G. Gate wrapper — consent subsystem ABSENT (must run before consent.php).
// ============================================================================
echo "-- gate wrapper: consent subsystem absent\n";
check('G1 precondition: auth_nwc\\consent not loaded',
    class_exists('\\auth_nwc\\consent', false), false);
check('G2 subsystem absent -> fail-closed (member)',
    depthcontent_may_keep_formation(U_CONSENT), false);
check('G3 subsystem absent -> fail-closed even for admin id',
    depthcontent_may_keep_formation(U_ADMIN), false);

// Behaviour with the subsystem absent: viewing must still be EPHEMERAL.
$DB = new fake_db();
$row = depthcontent_get_progress(U_CONSENT, 301);
check('G4 get_progress w/o subsystem -> ephemeral row (no id)', isset($row->id), false);
check('G5 get_progress w/o subsystem -> zero inserts', $DB->count('depthcontent_progress'), 0);

// ---- Load the real consent subsystem and wire the members ------------------
require_once __DIR__ . '/../../../auth/nwc/classes/consent.php';
$GLOBALS['__admins'] = [U_ADMIN];
\auth_nwc\consent::store(U_CONSENT, true);
\auth_nwc\consent::store(U_NOCONSENT, false);

echo "-- gate wrapper: consent subsystem present\n";
check('G6 delegates: consented member -> true',
    depthcontent_may_keep_formation(U_CONSENT), true);
check('G7 delegates: non-consented member -> false',
    depthcontent_may_keep_formation(U_NOCONSENT), false);
check('G8 delegates: never-carried member -> false',
    depthcontent_may_keep_formation(999), false);
check('G9 delegates: admin -> true', depthcontent_may_keep_formation(U_ADMIN), true);

// ============================================================================
// P. depthcontent_get_progress — persist vs ephemeral.
// ============================================================================
echo "-- get_progress: persist vs ephemeral\n";
$DB = new fake_db();

$row = depthcontent_get_progress(U_NOCONSENT, 42);
check('P1 non-consented: row still returned (callers never break)',
    is_object($row) && $row->status === 'new', true);
check('P2 non-consented: row is EPHEMERAL (no id)', isset($row->id), false);
check('P3 non-consented: 0 rows in depthcontent_progress',
    $DB->count('depthcontent_progress'), 0);
check('P4 non-consented: skip was debug-logged',
    (bool) preg_grep('/skipped depthcontent_progress persist/', $GLOBALS['__debugging']), true);

$row = depthcontent_get_progress(U_CONSENT, 42);
check('P5 consented: row persisted (has id)', isset($row->id), true);
check('P6 consented: 1 row in depthcontent_progress',
    $DB->count('depthcontent_progress'), 1);

$row2 = depthcontent_get_progress(U_CONSENT, 42);
check('P7 consented: second view reuses the row (no duplicate insert)',
    $DB->count('depthcontent_progress'), 1);

$row = depthcontent_get_progress(U_ADMIN, 42);
check('P8 admin: row persisted (never gated)', isset($row->id), true);

// ============================================================================
// S. depthcontent_update_sr — scheduler persist vs ephemeral.
// ============================================================================
echo "-- update_sr: persist vs ephemeral\n";
$DB = new fake_db();

$sr = depthcontent_update_sr(U_NOCONSENT, 42, 5);
check('S1 non-consented, no prior state -> false (ephemeral contract)', $sr, false);
check('S2 non-consented: ZERO writes to depthcontent_sr',
    $DB->writes_for('depthcontent_sr'), []);

$sr = depthcontent_update_sr(U_CONSENT, 42, 5);
check('S3 consented: scheduler row inserted', $DB->writes_for('depthcontent_sr'), ['insert:depthcontent_sr']);
check('S4 consented: row has id + advanced schedule',
    isset($sr->id) && $sr->repetitions === 1, true);

$sr = depthcontent_update_sr(U_CONSENT, 42, 5);
check('S5 consented: second review UPDATES (no dup insert)',
    $DB->writes_for('depthcontent_sr'), ['insert:depthcontent_sr', 'update:depthcontent_sr']);

// Pre-existing row (e.g. consent later withdrawn): reads allowed, writes not.
$sr = depthcontent_update_sr(U_NOCONSENT, 42, 5);
check('S6 withdrawal case: existing OTHER-user rows untouched, still no writes for non-consented',
    count($DB->writes_for('depthcontent_sr')), 2);

// ============================================================================
// A. depthcontent_apply_retrieval — log append + mastery upsert vs nothing.
// ============================================================================
echo "-- apply_retrieval: persist vs ephemeral\n";
$DB = new fake_db();

$event = [
    'userid'  => U_NOCONSENT, 'pointid' => 'course1.p1',
    'item_id' => 'q1', 'outcome' => 1, 'ts' => 1700000000,
];
$m = depthcontent_apply_retrieval($event);
check('A1 non-consented: retrieval log NOT appended',
    $DB->count('depthcontent_retrieval_log'), 0);
check('A2 non-consented: mastery ledger NOT written',
    $DB->count('depthcontent_mastery'), 0);
check('A3 non-consented: ephemeral mastery row returned (status new)',
    is_object($m) && ($m->status ?? '') === 'new' && !isset($m->id), true);

$event['userid'] = U_CONSENT;
$m = depthcontent_apply_retrieval($event);
check('A4 consented: retrieval log appended (append-only)',
    $DB->count('depthcontent_retrieval_log'), 1);
check('A5 consented: mastery ledger row upserted',
    $DB->count('depthcontent_mastery'), 1);
check('A6 consented: mastery row persisted with id', isset($m->id), true);

$event['ts'] = 1700000100;
$m = depthcontent_apply_retrieval($event);
check('A7 consented: second retrieval appends (2 log rows, still 1 mastery row)',
    [$DB->count('depthcontent_retrieval_log'), $DB->count('depthcontent_mastery')], [2, 1]);

$event['userid'] = U_ADMIN;
depthcontent_apply_retrieval($event);
check('A8 admin: retrieval persists (never gated)',
    $DB->count('depthcontent_retrieval_log'), 3);

echo "== $pass passed, $fail failed ==\n";
exit($fail === 0 ? 0 : 1);
