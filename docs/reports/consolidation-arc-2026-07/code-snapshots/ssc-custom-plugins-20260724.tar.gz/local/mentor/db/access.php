<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Capabilities for local_mentor.
 *
 * Deliberately minimal, and deliberately NOT a read grant. There is NO capability
 * that lets a mentor READ a mentee's practice detail: a mentor sees ONLY what the
 * member PUSHED (local_mentor_share), gated by the per-relationship consent grant —
 * never by a Moodle capability. Capabilities here only govern who may PARTICIPATE
 * in the accompaniment feature at all (be a companion / initiate an invite).
 *
 * NOTE: eligibility to be a companion is a floor, not a grant — the actual
 * visibility is the member's consented grant, and is further constrained by the
 * hard role-exclusivity rule (classes/mentor.php::can_mentor): the one who gates a
 * member's advancement may NOT be their mentor, whatever capabilities they hold.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$capabilities = [

    // Be eligible to be chosen as a companion (mentor) and see one's own mentor
    // dashboard of PUSHED snapshots. Adults-only v1 is enforced in the invite path.
    'local/mentor:bementor' => [
        'captype'      => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'user' => CAP_ALLOW,
        ],
    ],

    // Initiate a companion invitation for one's OWN plan (member-initiated only —
    // there is no soliciting surface for a would-be mentor).
    'local/mentor:invite' => [
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'user' => CAP_ALLOW,
        ],
    ],
];
