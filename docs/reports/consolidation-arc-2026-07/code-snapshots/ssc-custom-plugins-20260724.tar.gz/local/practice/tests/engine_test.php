<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Table-driven unit tests for the pure practice-state engine.
 *
 * Runs WITHOUT a Moodle runtime:  php tests/engine_test.php
 *
 * Proves the two load-bearing rules:
 *   - TICK-NOT-CALENDAR streak behaviour (a miss is a blank, never a break;
 *     calendar pacing DOES reset on a gap).
 *   - THE MF-2 FIREWALL: a view/scroll-sourced engage on a HABIT checkpoint
 *     does NOT tick it; an explicit member (manual) tick does.
 * Plus the per-type lifecycle (task/skill/habit) and untick precedence.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
require_once(__DIR__ . '/../classes/engine.php');

use local_practice\engine;

// ---- Tiny assertion harness (no PHPUnit / no Moodle needed) ----------------
$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
$GLOBALS['__fails'] = [];

function check(string $name, $expected, $actual): void {
    if ($expected === $actual) {
        $GLOBALS['__pass']++;
    } else {
        $GLOBALS['__fail']++;
        $GLOBALS['__fails'][] = sprintf("  FAIL: %s\n        expected=%s got=%s",
            $name, var_export($expected, true), var_export($actual, true));
    }
}

const BASE = 1700000000;
const DAY = 86400;

/**
 * Build an engagement-log row. $day = days since day 0; $ymd = the YYYYMMDD bucket.
 */
function e(int $ymd, string $source = 'manual', int $dayoffset = 0): array {
    return ['ts' => BASE + $dayoffset * DAY, 'localdate' => $ymd, 'source' => $source];
}

$task  = ['type' => 'task',  'pacing' => 'tick'];
$skill = ['type' => 'skill', 'pacing' => 'tick'];
$habit = ['type' => 'habit', 'pacing' => 'tick'];
$grpcal = ['type' => 'habit', 'pacing' => 'calendar']; // group book-study flag.

// ===========================================================================
// MF-2 FIREWALL  (the load-bearing proof)
// ===========================================================================

// A VIEW-sourced engage on a HABIT does NOT tick it.
$s = engine::derive([e(20260701, 'view'), e(20260702, 'scroll')], $habit);
check('MF2.habit_view_does_not_engage', 0, $s['engaged_days']);
check('MF2.habit_view_status_todo', 'todo', $s['status']);
check('MF2.habit_view_streak_zero', 0, $s['streak']);

// An explicit MANUAL tick on a HABIT DOES tick it.
$s = engine::derive([e(20260701, 'manual')], $habit);
check('MF2.habit_manual_engages', 1, $s['engaged_days']);
check('MF2.habit_manual_status_active', 'active', $s['status']);

// The predicate directly: view/scroll never permitted for a habit; manual is.
check('MF2.pred_view_habit', false, engine::source_permitted('habit', 'view'));
check('MF2.pred_scroll_habit', false, engine::source_permitted('habit', 'scroll'));
check('MF2.pred_manual_habit', true,  engine::source_permitted('habit', 'manual'));
// A content-consumption (task) checkpoint MAY auto-engage on view/scroll.
check('MF2.pred_view_task', true, engine::source_permitted('task', 'view'));

// Mixed: a habit with a manual tick AND a same-day view — still one engagement,
// and it is the manual one (the view is dropped, not additive).
$s = engine::derive([e(20260701, 'view'), e(20260701, 'manual')], $habit);
check('MF2.habit_mixed_one_engagement', 1, $s['engaged_days']);

// ===========================================================================
// TICK-NOT-CALENDAR  (a miss is a blank, never a broken streak)
// ===========================================================================

// Three engaged days with a GAP (d0, d1, then d5) — tick pacing keeps the
// streak growing across the missed days 2,3,4 (a blank, not a break).
$log = [e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260706, 'manual', 5)];
$s = engine::derive($log, $habit);
check('TICK.streak_survives_gap', 3, $s['streak']);
check('TICK.engaged_days', 3, $s['engaged_days']);
check('TICK.last_engaged_date', 20260706, $s['last_engaged_date']);

// CALENDAR pacing (group book-study): the SAME log resets on the gap — the
// trailing consecutive run is just the single day d5.
$s = engine::derive($log, $grpcal);
check('CALENDAR.streak_resets_on_gap', 1, $s['streak']);
check('CALENDAR.engaged_days_still_counted', 3, $s['engaged_days']);

// CALENDAR pacing with NO gap (d0,d1,d2) — the run is all three.
$log2 = [e(20260701, 'manual', 0), e(20260702, 'manual', 1), e(20260703, 'manual', 2)];
$s = engine::derive($log2, $grpcal);
check('CALENDAR.contiguous_run', 3, $s['streak']);

// Same-day double engagement counts once (idempotent per day).
$s = engine::derive([e(20260701, 'manual'), e(20260701, 'manual')], $task);
check('TICK.same_day_counts_once', 1, $s['engaged_days']);

// ===========================================================================
// UNTICK precedence:  manual > cleared > auto(view|scroll)
// ===========================================================================

// A task auto-ticked by view, then CLEARED the same day => blank (untick-to-stay).
$s = engine::derive([e(20260701, 'view'), e(20260701, 'cleared')], $task);
check('UNTICK.clear_beats_auto', 0, $s['engaged_days']);
check('UNTICK.clear_status_todo', 'todo', $s['status']);

// A manual tick after a clear on the same day re-ticks (member hand is authoritative).
$s = engine::derive([e(20260701, 'view'), e(20260701, 'cleared'), e(20260701, 'manual')], $task);
check('UNTICK.manual_beats_clear', 1, $s['engaged_days']);
check('UNTICK.manual_reticks_done', 'done', $s['status']);

// ===========================================================================
// PER-TYPE LIFECYCLE
// ===========================================================================

// TASK: completes on first engagement.
$s = engine::derive([e(20260701, 'manual')], $task);
check('TASK.done_on_first', 'done', $s['status']);

// SKILL: todo -> started (1) -> consolidated (>=3 engaged days).
$s = engine::derive([e(20260701, 'manual')], $skill);
check('SKILL.started', 'started', $s['status']);
$s = engine::derive([e(20260701, 'manual'), e(20260702, 'manual'), e(20260703, 'manual')], $skill);
check('SKILL.consolidated', 'consolidated', $s['status']);

// A task auto-ticked purely by view (allowed for a task) engages.
$s = engine::derive([e(20260701, 'view')], $task);
check('TASK.view_autoticks', 'done', $s['status']);

// Empty log => todo, nothing engaged.
$s = engine::derive([], $habit);
check('EMPTY.todo', 'todo', $s['status']);
check('EMPTY.no_days', 0, $s['engaged_days']);

// ---- Report ----------------------------------------------------------------
$total = $GLOBALS['__pass'] + $GLOBALS['__fail'];
echo "\nlocal_practice engine unit tests\n";
echo str_repeat('-', 40) . "\n";
if ($GLOBALS['__fail'] > 0) {
    echo implode("\n", $GLOBALS['__fails']) . "\n";
}
printf("%d/%d checks passed (%d failed)\n", $GLOBALS['__pass'], $total, $GLOBALS['__fail']);
exit($GLOBALS['__fail'] === 0 ? 0 : 1);
