<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy (GDPR) provider for local_mentor.
 *
 * WHY ERASURE IS TRIVIAL HERE — AND WHY IT IS BIDIRECTIONAL. Both tables are
 * FK-free with NO delete callbacks (see db/install.xml). A data-subject erasure is
 * therefore a small set of explicit DELETEs — but because a person can appear as
 * EITHER the mentee (menteeid) OR the mentor (mentorid), erasing a member deletes
 * their grants and shares in BOTH directions (design §4.5: "erasing a member
 * deletes their grants both directions"). This joins the ops#93 nwc<->ssc erasure
 * round-trip.
 *
 * Accompaniment data is a scoped, consented disclosure of Art. 9 special-category
 * (religious-practice) state to a named person. NO-AI: nothing here (including
 * export) may be routed to any AI/LLM system.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_mentor\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use context_user;

defined('MOODLE_INTERNAL') || die();

/**
 * Privacy provider: describes and erases local_mentor data (both directions).
 */
class provider implements
        \core_privacy\local\metadata\provider,
        \core_privacy\local\request\core_userlist_provider,
        \core_privacy\local\request\plugin\provider {

    /**
     * Describe the data this plugin stores.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('local_mentor_relationship', [
            'menteeid'          => 'privacy:metadata:local_mentor_relationship:menteeid',
            'mentorid'          => 'privacy:metadata:local_mentor_relationship:mentorid',
            'status'            => 'privacy:metadata:local_mentor_relationship:status',
            'tier'              => 'privacy:metadata:local_mentor_relationship:tier',
            'covenant_accepted' => 'privacy:metadata:local_mentor_relationship:covenant_accepted',
        ], 'privacy:metadata:local_mentor_relationship');

        $collection->add_database_table('local_mentor_share', [
            'menteeid'  => 'privacy:metadata:local_mentor_share:menteeid',
            'mentorid'  => 'privacy:metadata:local_mentor_share:mentorid',
            'tier'      => 'privacy:metadata:local_mentor_share:tier',
            'payload'   => 'privacy:metadata:local_mentor_share:payload',
            'shared_on' => 'privacy:metadata:local_mentor_share:shared_on',
        ], 'privacy:metadata:local_mentor_share');

        return $collection;
    }

    /**
     * All data lives in the user's own context — reported if the user appears as
     * EITHER mentee or mentor in either table.
     *
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        global $DB;
        $contextlist = new contextlist();
        if (self::user_has_data($userid)) {
            $contextlist->add_user_context($userid);
        }
        return $contextlist;
    }

    /**
     * Find users with data in the given (user) context — mentee OR mentor.
     *
     * @param userlist $userlist
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();
        if (!$context instanceof context_user) {
            return;
        }
        if (self::user_has_data($context->instanceid)) {
            $userlist->add_user($context->instanceid);
        }
    }

    /**
     * Export a data subject's accompaniment record (for their own SAR) — both the
     * grants they own and the grants where they are the companion.
     *
     * @param approved_contextlist $contextlist
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if (!$context instanceof context_user || $context->instanceid != $userid) {
                continue;
            }
            $data = (object) [
                'as_mentee_relationships' => array_values($DB->get_records('local_mentor_relationship', ['menteeid' => $userid])),
                'as_mentor_relationships' => array_values($DB->get_records('local_mentor_relationship', ['mentorid' => $userid])),
                'as_mentee_shares'        => array_values($DB->get_records('local_mentor_share', ['menteeid' => $userid])),
                'as_mentor_shares'        => array_values($DB->get_records('local_mentor_share', ['mentorid' => $userid])),
            ];
            writer::with_context($context)->export_data(
                [get_string('pluginname', 'local_mentor')], $data);
        }
    }

    /**
     * Erase all data in a context. Only a user context is meaningful here.
     *
     * @param \context $context
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        if (!$context instanceof context_user) {
            return;
        }
        self::erase_user($context->instanceid);
    }

    /**
     * Erase the given data subject's accompaniment record (both directions).
     *
     * @param approved_contextlist $contextlist
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context instanceof context_user && $context->instanceid == $userid) {
                self::erase_user($userid);
                return;
            }
        }
    }

    /**
     * Erase the approved users in the given context.
     *
     * @param approved_userlist $userlist
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        $context = $userlist->get_context();
        if (!$context instanceof context_user) {
            return;
        }
        foreach ($userlist->get_userids() as $userid) {
            if ($userid == $context->instanceid) {
                self::erase_user($userid);
            }
        }
    }

    /**
     * Does this user appear (as mentee OR mentor) in either table?
     *
     * @param int $userid
     * @return bool
     */
    protected static function user_has_data(int $userid): bool {
        global $DB;
        foreach (['local_mentor_relationship', 'local_mentor_share'] as $table) {
            if ($DB->record_exists_select($table, 'menteeid = :m OR mentorid = :n',
                    ['m' => $userid, 'n' => $userid])) {
                return true;
            }
        }
        return false;
    }

    /**
     * THE erasure primitive: explicit BIDIRECTIONAL DELETEs per FK-free table.
     * Removing a member deletes every grant and every pushed snapshot in which they
     * are either the mentee or the companion — no cascade, no orphan-hunting.
     *
     * @param int $userid
     */
    protected static function erase_user(int $userid) {
        global $DB;
        foreach (['local_mentor_relationship', 'local_mentor_share'] as $table) {
            $DB->delete_records_select($table, 'menteeid = :m OR mentorid = :n',
                ['m' => $userid, 'n' => $userid]);
        }
    }
}
