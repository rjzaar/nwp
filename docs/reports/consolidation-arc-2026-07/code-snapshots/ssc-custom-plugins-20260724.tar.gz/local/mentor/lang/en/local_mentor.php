<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for local_mentor.
 *
 * Member-facing copy calls the feature a "companion"; code calls it a mentor.
 * All copy is gentle, confided, and never surveillance-shaped.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Companion';

// Capabilities.
$string['mentor:bementor'] = 'Be chosen as a companion and see your companion dashboard';
$string['mentor:invite'] = 'Invite a companion to your own Plan of Love';

// The feature, member-facing.
$string['companion'] = 'Companion';
$string['mydashboard'] = 'People I walk with';
$string['invitecompanion'] = 'Invite a companion';
$string['nocompanions'] = 'You have not invited a companion. Accompaniment is always your choice, and always something you can end.';
$string['noshareyet'] = 'Nothing has been shared with you yet.';
$string['someprivate'] = 'Some items are kept private.';

// The 3 consent tiers (member-facing names).
$string['tier_coarse'] = 'How I\'m going';
$string['tier_coarse_desc'] = 'A coarse sense of your rhythm — the shape of your rule and any note you write. No item names, no marks.';
$string['tier_engagement'] = 'My plan';
$string['tier_engagement_desc'] = 'Your plan outline and where each shared item is in forming — never the day-by-day, never a count.';
$string['tier_detail'] = 'My plan, in more detail';
$string['tier_detail_desc'] = 'Your plan plus anything extra you choose to elect, item by item. Still no marks, no timestamps, no reflections.';
$string['tierdefault'] = 'How I\'m going';

// Consent flow copy.
$string['consent_heading'] = 'What {$a} will be able to see';
$string['consent_pushonly'] = 'Your companion only ever sees what you choose to share. They can never look in on your own — nothing is pulled live.';
$string['consent_revocable'] = 'You can change or end this at any time. Ending it removes everything you shared, at once.';
$string['consent_noai'] = 'No automated system reads or summarises what you share — only the person you chose.';
$string['consent_never'] = 'Never shared, at any level: your day-by-day marks, your reflections, your streaks or counts, your timestamps, and anything from your doctrine study. These stay yours.';
$string['term'] = 'For how long';
$string['term_help'] = 'Accompaniment is renewed, not forever — a chance to ask "is this still serving me?" The default is 90 days; renewing is a fresh choice, never automatic.';
$string['term_90'] = '90 days (recommended)';
$string['term_30'] = '30 days';
$string['term_365'] = 'A year';

// The covenant (mentor accepts before any grant activates).
$string['covenant_heading'] = 'The companion covenant';
$string['covenant_text'] = 'What you see here is confided to you. Hold it in confidence; never discuss it with others or raise it publicly; encourage privately; celebrate quietly; when someone is quiet, reach out as a friend, never to chase compliance. If you see something beyond you, help them find the right help. No automated system reads or summarises what you are shown — only you, the person they chose.';
$string['covenant_accept'] = 'I accept the companion covenant';
$string['covenant_required'] = 'You must accept the covenant before you can begin walking with someone.';

// Dashboard copy (nudge, not nag).
$string['whatfor'] = 'What a companion is for';
$string['whatfor_text'] = 'Notice the patterns they asked you to help see; encourage privately; celebrate what has taken root; when they are quiet, reach out as a friend. A companion is not for chasing compliance.';
$string['checkin'] = 'Check in';
$string['checkin_hint'] = 'You last checked in {$a} — a gentle, human pace is best.';
$string['quietchip'] = 'Quiet {$a}';
$string['activechip'] = 'Active this week';
$string['onaplan'] = 'On a plan';

// Status labels.
$string['status_invited'] = 'Invited';
$string['status_active'] = 'Walking together';
$string['status_paused'] = 'Paused';
$string['status_revoked'] = 'Ended';

// Invite-path refusal reasons.
$string['err_adults_only'] = 'Companion accompaniment is for adults in this first version.';
$string['err_self'] = 'You cannot be your own companion.';
$string['err_gating_role'] = 'This person helps decide your advancement or recognition, so they cannot also be your companion — the one who sees the interior life does not vote on it.';
$string['err_mentee_cap'] = 'This person is already walking with as many people as they can carry right now.';
$string['err_mentor_cap'] = 'You already have the most companions allowed. End one first if you would like to invite another.';

// Privacy (GDPR) metadata strings.
$string['privacy:metadata:local_mentor_relationship'] = 'A member-initiated, revocable mentor (companion) grant: who accompanies whom, at what consent tier, and the accepted covenant. A scoped disclosure of religious-practice special-category data to a named person.';
$string['privacy:metadata:local_mentor_relationship:menteeid'] = 'The member who initiated and owns the grant.';
$string['privacy:metadata:local_mentor_relationship:mentorid'] = 'The chosen companion.';
$string['privacy:metadata:local_mentor_relationship:status'] = 'The lifecycle status of the grant (invited, active, paused, revoked).';
$string['privacy:metadata:local_mentor_relationship:tier'] = 'The consent tier chosen by the member.';
$string['privacy:metadata:local_mentor_relationship:covenant_accepted'] = 'Whether the companion accepted the confidentiality covenant.';
$string['privacy:metadata:local_mentor_share'] = 'The coarse snapshots a member chose to PUSH to a companion — the only thing a companion ever sees. Never a live pull; never day-by-day marks, reflections, counts, timestamps, or doctrine-level knowing. Never exposed to any AI system.';
$string['privacy:metadata:local_mentor_share:menteeid'] = 'The member who pushed the snapshot.';
$string['privacy:metadata:local_mentor_share:mentorid'] = 'The companion the snapshot was pushed to.';
$string['privacy:metadata:local_mentor_share:tier'] = 'The consent tier the snapshot was composed at.';
$string['privacy:metadata:local_mentor_share:payload'] = 'The coarse payload the member elected to send (rule shape, member notes, and at the engagement tier the coarse progression states).';
$string['privacy:metadata:local_mentor_share:shared_on'] = 'The date the member pushed the snapshot.';
