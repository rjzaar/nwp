/**
 * Tabbed course format - renders section activities as swipeable tabs.
 *
 * @module format_tabbed/tabbed
 */
define(['jquery'], function($) {
    return {
        init: function() {
            // Wait for DOM and Moodle's reactive components to be ready.
            $(document).ready(function() {
                // Small delay to ensure Moodle's reactive course format renders.
                setTimeout(run, 500);
            });
        }
    };

    function run() {
        // Find all course sections with activities.
        $('[data-for="section"][data-number]').each(function() {
            var section = $(this);
            var sectionNum = parseInt(section.data('number'), 10);

            // Skip section 0 (General).
            if (sectionNum === 0) return;

            // Find page and quiz activities within this section.
            var pageAct = section.find('.modtype_page').first();
            var quizAct = section.find('.modtype_quiz').first();

            if (!pageAct.length) return;

            // Get the page URL.
            var pageLink = pageAct.find('a[href*="/mod/page/"]').first();
            if (!pageLink.length) return;
            var pageUrl = pageLink.attr('href');

            // Get quiz URL.
            var quizUrl = '';
            if (quizAct.length) {
                var quizLink = quizAct.find('a[href*="/mod/quiz/"]').first();
                if (quizLink.length) quizUrl = quizLink.attr('href');
            }

            // Create loading placeholder.
            var container = $('<div class="tabbed-session">' +
                '<div class="tabbed-loading">Loading...</div></div>');

            // Insert before the content area.
            var contentArea = section.find('.course-content-item-content, .content').first();
            if (!contentArea.length) return;
            contentArea.before(container);

            // Hide original activities.
            pageAct.hide();
            if (quizAct.length) quizAct.hide();

            // Fetch page content.
            fetchPageContent(pageUrl, function(html) {
                var tabs = parsePageContent(html, quizUrl);
                if (tabs.length > 0) {
                    var tabbedUI = buildTabbedUI(tabs);
                    container.replaceWith(tabbedUI);
                } else {
                    container.remove();
                    pageAct.show();
                    if (quizAct.length) quizAct.show();
                }
            });
        });
    }

    function fetchPageContent(url, callback) {
        $.ajax({
            url: url,
            dataType: 'html',
            success: function(html) {
                var doc = $('<div>').append($.parseHTML(html));
                // The page content is inside .generalbox .no-overflow
                var content = doc.find('.no-overflow').first();
                if (!content.length) {
                    content = doc.find('.box.generalbox').first();
                }
                if (!content.length) {
                    content = doc.find('[role="main"]').first();
                }
                callback(content.length ? content.html() : '');
            },
            error: function() {
                callback('');
            }
        });
    }

    function parsePageContent(html, quizUrl) {
        var tabs = [];
        // Create a flat list of elements from the HTML.
        var tempDiv = $('<div>').html(html);
        var currentTab = null;

        // Walk all elements at every depth to find h3 headers.
        // Build a flat ordered list of [h3, content, h3, content, ...].
        var allElements = tempDiv.children();

        allElements.each(function() {
            var el = $(this);

            // Check if this element IS an h3.
            if (el.is('h3')) {
                var tabInfo = mapHeaderToTab(el.text().trim());
                if (tabInfo) {
                    if (currentTab) tabs.push(currentTab);
                    currentTab = {
                        id: tabInfo.id,
                        label: tabInfo.label,
                        icon: tabInfo.icon,
                        content: ''
                    };
                    return;
                }
            }

            // Check if this element CONTAINS an h3 as a direct child.
            var innerH3 = el.find('> h3').first();
            if (innerH3.length) {
                var tabInfo2 = mapHeaderToTab(innerH3.text().trim());
                if (tabInfo2) {
                    if (currentTab) tabs.push(currentTab);
                    currentTab = {
                        id: tabInfo2.id,
                        label: tabInfo2.label,
                        icon: tabInfo2.icon,
                        content: ''
                    };
                    // Include content from this element after the h3.
                    var clone = el.clone();
                    clone.find('> h3').first().remove();
                    var remaining = clone.html().trim();
                    if (remaining) {
                        currentTab.content += '<div>' + remaining + '</div>';
                    }
                    return;
                }
            }

            // Skip leading elements before first h3 (session header).
            if (!currentTab && tabs.length === 0) return;

            if (currentTab) {
                currentTab.content += el.prop('outerHTML');
            }
        });

        if (currentTab) tabs.push(currentTab);

        // Insert Quiz tab after Learn (first tab).
        if (quizUrl && tabs.length > 0) {
            var quizTab = {
                id: 'quiz',
                label: 'Quiz',
                icon: '&#9998;',
                content: '<div class="tabbed-quiz-embed">' +
                    '<iframe class="tabbed-quiz-iframe" src="' + quizUrl + '" ' +
                    'frameborder="0" allowfullscreen></iframe></div>',
                isQuiz: true
            };
            tabs.splice(1, 0, quizTab);
        }

        return tabs;
    }

    function mapHeaderToTab(title) {
        var lower = title.toLowerCase();
        if (lower.indexOf('learn') === 0) return {id: 'learn', label: 'Learn', icon: '&#128214;'};
        if (lower.indexOf('video') !== -1 || lower.indexOf('watch') !== -1) return {id: 'learn', label: 'Learn', icon: '&#128214;'};
        if (lower.indexOf('engage') === 0) return {id: 'engage', label: 'Engage', icon: '&#128172;'};
        if (lower.indexOf('today') !== -1 || lower.indexOf('practice') !== -1) return {id: 'practice', label: 'Practice', icon: '&#128591;'};
        if (lower.indexOf('review') === 0) return {id: 'review', label: 'Review', icon: '&#128260;'};
        if (lower.indexOf('quiz') !== -1 || lower.indexOf('final') !== -1) return {id: 'quiz', label: 'Quiz', icon: '&#9998;'};
        if (lower.indexOf('recommend') !== -1) return {id: 'next', label: 'Next', icon: '&#10140;'};
        return null;
    }

    function buildTabbedUI(tabs) {
        var container = $('<div class="tabbed-session">');
        var tabBar = $('<div class="tabbed-bar" role="tablist">');
        var panelsWrap = $('<div class="tabbed-panels-wrap">');

        tabs.forEach(function(tab, index) {
            var activeClass = index === 0 ? ' tabbed-tab--active' : '';
            var btn = $('<button class="tabbed-tab' + activeClass + '" role="tab" data-index="' + index + '">' +
                '<span class="tabbed-tab-icon">' + tab.icon + '</span>' +
                '<span class="tabbed-tab-label">' + tab.label + '</span></button>');
            tabBar.append(btn);

            var panelClass = index === 0 ? ' tabbed-panel--active' : '';
            var panel = $('<div class="tabbed-panel' + panelClass + '" role="tabpanel" data-index="' + index + '">').html(tab.content);
            panelsWrap.append(panel);

            btn.on('click', function() {
                switchTab(container, index);
            });
        });

        container.append(tabBar).append(panelsWrap);

        // Dot indicators.
        var dots = $('<div class="tabbed-dots">');
        tabs.forEach(function(tab, index) {
            var dotClass = index === 0 ? ' tabbed-dot--active' : '';
            var dot = $('<span class="tabbed-dot' + dotClass + '">');
            dot.on('click', function() { switchTab(container, index); });
            dots.append(dot);
        });
        container.append(dots);
        container.data('activeIndex', 0);

        addSwipeSupport(panelsWrap, container, tabs.length);

        // Set up quiz iframes.
        container.find('.tabbed-quiz-iframe').each(function() {
            setupQuizIframe($(this));
        });

        return container;
    }

    function switchTab(container, index) {
        container.find('.tabbed-tab').each(function(i) {
            $(this).toggleClass('tabbed-tab--active', i === index)
                   .attr('aria-selected', i === index ? 'true' : 'false');
        });
        container.find('.tabbed-panel').each(function(i) {
            $(this).toggleClass('tabbed-panel--active', i === index);
        });
        container.find('.tabbed-dot').each(function(i) {
            $(this).toggleClass('tabbed-dot--active', i === index);
        });
        container.data('activeIndex', index);
        var activeBtn = container.find('.tabbed-tab').eq(index);
        if (activeBtn.length) {
            activeBtn[0].scrollIntoView({behavior: 'smooth', block: 'nearest', inline: 'center'});
        }
    }

    function setupQuizIframe(iframe) {
        iframe.on('load', function() {
            try {
                var doc = iframe[0].contentDocument || iframe[0].contentWindow.document;
                var style = doc.createElement('style');
                style.textContent =
                    '#page-header, .navbar, #nav-drawer, .drawer, ' +
                    '#page-footer, .footer-content-debugging, ' +
                    '.activity-navigation, .secondary-navigation, ' +
                    '#page-navbar, .breadcrumb, ' +
                    '.course-content-header, .drawer-toggler, ' +
                    '#usernavigation, .primary-navigation, ' +
                    '#topofscroll > nav, .moremenu { display: none !important; } ' +
                    '#page { margin-top: 0 !important; padding-top: 0 !important; } ' +
                    '#page-wrapper { padding-top: 0 !important; } ' +
                    '#region-main { padding: 0 !important; } ' +
                    '#page.drawers { margin-left: 0 !important; padding-left: 0 !important; } ' +
                    '#page.drawers .main-inner { max-width: 100% !important; }';
                doc.head.appendChild(style);
                resizeIframe(iframe);
                var observer = new MutationObserver(function() { resizeIframe(iframe); });
                observer.observe(doc.body, {childList: true, subtree: true, attributes: true});
            } catch (e) {
                iframe.css('min-height', '600px');
            }
        });
    }

    function resizeIframe(iframe) {
        try {
            var doc = iframe[0].contentDocument || iframe[0].contentWindow.document;
            var height = doc.documentElement.scrollHeight;
            if (height > 100) {
                iframe.css('height', height + 'px');
            }
        } catch (e) {}
    }

    function addSwipeSupport(panelsWrap, container, tabCount) {
        var startX = 0, startY = 0, threshold = 50;
        panelsWrap.on('touchstart', function(e) {
            startX = e.originalEvent.touches[0].clientX;
            startY = e.originalEvent.touches[0].clientY;
        });
        panelsWrap.on('touchend', function(e) {
            var diffX = e.originalEvent.changedTouches[0].clientX - startX;
            var diffY = e.originalEvent.changedTouches[0].clientY - startY;
            if (Math.abs(diffX) < threshold || Math.abs(diffY) > Math.abs(diffX)) return;
            var current = container.data('activeIndex') || 0;
            if (diffX < 0 && current < tabCount - 1) switchTab(container, current + 1);
            else if (diffX > 0 && current > 0) switchTab(container, current - 1);
        });
    }
});
