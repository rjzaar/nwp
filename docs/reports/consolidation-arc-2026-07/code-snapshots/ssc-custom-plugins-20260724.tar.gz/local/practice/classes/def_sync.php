<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Checkpoint DEFINITION sync from the built catalog JSON into local_practice_def.
 *
 * DEFINITION data only (no member PII). Reads build/json/<pointid>.json, pulls
 * every LP-level `checkpoints:` entry (and any `application` atom carrying a
 * checkpoint), and UPSERTS a local_practice_def row keyed on the canonical
 * checkpoint_uid. A checkpoint that has DISAPPEARED from the catalog is
 * TOMBSTONED (active=0, tombstoned=1) — NEVER hard-deleted — so a member's
 * state row never orphans; it simply renders "retired".
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_practice;

defined('MOODLE_INTERNAL') || die();

/**
 * Definition synchroniser.
 */
class def_sync {

    /**
     * Allowed checkpoint types (schema allowed_checkpoint_types, v3.3 6-type model).
     * `counsel` is NOT here — it is an authoring disposition that mints no checkpoint,
     * so it is SKIPPED exactly like a TODO_pedagogy scaffold.
     */
    const TYPES = ['task', 'challenge', 'habit', 'rule', 'skill', 'suggested'];

    /** Types on the manual-only side of MF-2: autotick is forced to none. */
    const MANUAL_ONLY_TYPES = ['habit', 'rule', 'challenge', 'skill'];

    /**
     * Build the canonical checkpoint_uid = <course>.<pointid>.<key>, collapsing
     * the course prefix when pointid already carries it.
     *
     * @param string $course  e.g. B5
     * @param string $pointid e.g. B5.03
     * @param string $key     e.g. mental_prayer
     * @return string e.g. B5.03.mental_prayer
     */
    public static function make_uid(string $course, string $pointid, string $key): string {
        if ($course !== '' && strpos($pointid . '.', $course . '.') === 0) {
            return $pointid . '.' . $key; // pointid already begins with "<course>.".
        }
        return $course . '.' . $pointid . '.' . $key;
    }

    /**
     * Extract checkpoint definition rows from one decoded LP JSON payload.
     *
     * Supports two authoring shapes (both compile to the same registry):
     *   1. LP-level `checkpoints:` list (book-studies / N9 §5.1).
     *   2. `application` atoms carrying a `checkpoint:` block (§2.3), found under
     *      the LP's `variants` / `application` slots.
     *
     * @param array $lp Decoded LP JSON (must carry `id`).
     * @return array List of def arrays {checkpoint_uid, course, pointid, ckey,
     *               type, title, autotick, pacing, prompt_self, prompt_self_text}
     */
    public static function extract(array $lp): array {
        $pointid = (string) ($lp['id'] ?? '');
        if ($pointid === '') {
            return [];
        }
        $course = explode('.', $pointid)[0];
        $defs = [];

        // Shape 1: LP-level checkpoints[].
        foreach (($lp['checkpoints'] ?? []) as $cp) {
            $row = self::normalise_checkpoint($course, $pointid, $cp);
            if ($row) {
                $defs[$row['checkpoint_uid']] = $row;
            }
        }

        // Shape 2: application atoms with a checkpoint: block.
        foreach (self::iter_application_atoms($lp) as $atom) {
            if (!isset($atom['checkpoint']) || !is_array($atom['checkpoint'])) {
                continue;
            }
            $cp = $atom['checkpoint'];
            // An application atom's checkpoint may carry prompt_self from the atom.
            if (!isset($cp['prompt_self']) && isset($atom['prompt_self'])) {
                $cp['prompt_self'] = $atom['prompt_self'];
            }
            $row = self::normalise_checkpoint($course, $pointid, $cp);
            if ($row) {
                $defs[$row['checkpoint_uid']] = $row;
            }
        }

        return array_values($defs);
    }

    /**
     * Yield all application-slot atoms on an LP (variants + application arrays).
     *
     * @param array $lp
     * @return \Generator
     */
    protected static function iter_application_atoms(array $lp): \Generator {
        foreach (['application', 'variants', 'contributed'] as $slot) {
            if (!isset($lp[$slot]) || !is_array($lp[$slot])) {
                continue;
            }
            foreach ($lp[$slot] as $atom) {
                if (!is_array($atom)) {
                    continue;
                }
                if ($slot === 'application' || ($atom['slot'] ?? '') === 'application') {
                    yield $atom;
                }
            }
        }
    }

    /**
     * Normalise one checkpoint spec into a def row.
     *
     * @param string $course
     * @param string $pointid
     * @param array  $cp Raw checkpoint spec.
     * @return array|null Def row, or null if invalid (no key/type).
     */
    protected static function normalise_checkpoint(string $course, string $pointid, array $cp): ?array {
        $key = (string) ($cp['key'] ?? '');
        $type = (string) ($cp['type'] ?? '');
        if ($key === '' || !in_array($type, self::TYPES, true)) {
            // A TODO_pedagogy scaffold, a `counsel` disposition, or a keyless
            // entry: not yet (or never) a live def. def_sync SKIPS it.
            return null;
        }
        // MF-2 default: habit/rule/challenge/skill autotick is forced to none — a
        // view never marks a prayer/discipline/devotion done.
        $autotick = (string) ($cp['autotick'] ?? 'none');
        if (in_array($type, self::MANUAL_ONLY_TYPES, true) && $autotick !== 'none') {
            $autotick = 'none';
        }
        // A suggested checkpoint MUST carry an adopts_as (default task).
        $adoptsas = null;
        if ($type === 'suggested') {
            $adoptsas = (string) ($cp['adopts_as'] ?? 'task');
        }
        $season = $cp['season'] ?? null;
        return [
            'checkpoint_uid'   => self::make_uid($course, $pointid, $key),
            'course'           => $course,
            'pointid'          => $pointid,
            'ckey'             => $key,
            'type'             => $type,
            'title'            => (string) ($cp['title'] ?? $cp['label'] ?? $key),
            'autotick'         => $autotick,
            'pacing'           => (string) ($cp['pacing'] ?? 'tick'),
            'cadence'          => (string) ($cp['cadence'] ?? engine::default_cadence($type)),
            'adopts_as'        => $adoptsas,
            'on_consolidate'   => ($type === 'habit') ? (string) ($cp['on_consolidate'] ?? 'keep') : null,
            'contributes_to'   => isset($cp['contributes_to']) ? (string) $cp['contributes_to'] : null,
            'review_after_days' => isset($cp['review_after_days']) ? (int) $cp['review_after_days'] : null,
            'season_window'    => is_array($season) && isset($season['window']) ? (string) $season['window'] : null,
            'season_completes_at' => is_array($season) && isset($season['completes_at']) ? (string) $season['completes_at'] : null,
            'condition_text'   => isset($cp['condition_text']) ? (string) $cp['condition_text'] : null,
            'prompt_self'      => !empty($cp['prompt_self']) ? 1 : 0,
            'prompt_self_text' => isset($cp['prompt_self_text']) ? (string) $cp['prompt_self_text'] : null,
        ];
    }

    /**
     * Build `type: rule` def rows from the discipline registry (disciplines.yaml,
     * decoded to an array). The ~8 canonical Rules are minted ONCE here (uid =
     * "rule.<uid>"), never re-minted per LP — LP checkpoints reach them via
     * contributes_to. Each registry entry: {uid, title, cadence}.
     *
     * @param array $registry Decoded disciplines.yaml (its `disciplines:` list).
     * @return array Def rows (same shape as normalise_checkpoint()).
     */
    public static function disciplines_from_registry(array $registry): array {
        $rows = [];
        foreach (($registry['disciplines'] ?? []) as $d) {
            if (!is_array($d) || empty($d['uid'])) {
                continue;
            }
            $uid = (string) $d['uid'];
            $rows[] = [
                'checkpoint_uid'   => 'rule.' . $uid,
                'course'           => 'rule',
                'pointid'          => 'rule',
                'ckey'             => $uid,
                'type'             => 'rule',
                'title'            => (string) ($d['title'] ?? $uid),
                'autotick'         => 'none',
                'pacing'           => 'tick',
                'cadence'          => (string) ($d['cadence'] ?? 'daily'),
                'adopts_as'        => null,
                'on_consolidate'   => null,
                'contributes_to'   => null,
                'review_after_days' => null,
                'season_window'    => null,
                'season_completes_at' => null,
                'condition_text'   => null,
                'prompt_self'      => 0,
                'prompt_self_text' => null,
            ];
        }
        return $rows;
    }

    /**
     * Upsert a batch of def rows and tombstone anything no longer present.
     *
     * @param array $rows      Def rows (from extract()), across all LPs.
     * @param bool  $dryrun    If true, report only; write nothing.
     * @param string|null $coursefilter Only reconcile this course's defs.
     * @param array $protectcourses Course codes to NEVER tombstone in this sweep
     *              (e.g. ['rule'] when the Rule registry was not part of this sync,
     *              so an LP-only sync never sweeps the canonical Rules).
     * @return array {upserted, tombstoned, unchanged}
     */
    public static function upsert_all(array $rows, bool $dryrun = false, ?string $coursefilter = null,
            array $protectcourses = []): array {
        global $DB;
        $now = time();
        $seen = [];
        $upserted = 0;
        $unchanged = 0;

        foreach ($rows as $r) {
            $seen[$r['checkpoint_uid']] = true;
            $existing = $DB->get_record('local_practice_def', ['checkpoint_uid' => $r['checkpoint_uid']]);
            if ($existing) {
                $changed = ($existing->type !== $r['type'])
                    || ($existing->title !== $r['title'])
                    || ($existing->autotick !== $r['autotick'])
                    || ($existing->pacing !== $r['pacing'])
                    || ((string) ($existing->cadence ?? '') !== (string) ($r['cadence'] ?? ''))
                    || ((string) ($existing->adopts_as ?? '') !== (string) ($r['adopts_as'] ?? ''))
                    || ((string) ($existing->on_consolidate ?? '') !== (string) ($r['on_consolidate'] ?? ''))
                    || ((string) ($existing->contributes_to ?? '') !== (string) ($r['contributes_to'] ?? ''))
                    || ((int) ($existing->review_after_days ?? 0) !== (int) ($r['review_after_days'] ?? 0))
                    || ((string) ($existing->season_window ?? '') !== (string) ($r['season_window'] ?? ''))
                    || ((string) ($existing->season_completes_at ?? '') !== (string) ($r['season_completes_at'] ?? ''))
                    || ((int) $existing->prompt_self !== (int) $r['prompt_self'])
                    || (int) $existing->active !== 1
                    || (int) $existing->tombstoned !== 0;
                if ($changed) {
                    if (!$dryrun) {
                        $existing->type = $r['type'];
                        $existing->title = $r['title'];
                        $existing->autotick = $r['autotick'];
                        $existing->pacing = $r['pacing'];
                        $existing->cadence = $r['cadence'];
                        $existing->adopts_as = $r['adopts_as'];
                        $existing->on_consolidate = $r['on_consolidate'];
                        $existing->contributes_to = $r['contributes_to'];
                        $existing->review_after_days = $r['review_after_days'];
                        $existing->season_window = $r['season_window'];
                        $existing->season_completes_at = $r['season_completes_at'];
                        $existing->condition_text = $r['condition_text'];
                        $existing->prompt_self = $r['prompt_self'];
                        $existing->prompt_self_text = $r['prompt_self_text'];
                        $existing->active = 1;       // resurrect if previously tombstoned.
                        $existing->tombstoned = 0;
                        $existing->timemodified = $now;
                        $DB->update_record('local_practice_def', $existing);
                    }
                    $upserted++;
                } else {
                    $unchanged++;
                }
            } else {
                if (!$dryrun) {
                    $DB->insert_record('local_practice_def', (object) array_merge($r, [
                        'active'       => 1,
                        'tombstoned'   => 0,
                        'timemodified' => $now,
                    ]));
                }
                $upserted++;
            }
        }

        // Tombstone (never delete) any live def not present in this sync.
        $conditions = ['tombstoned' => 0];
        if ($coursefilter) {
            $conditions['course'] = $coursefilter;
        }
        $tombstoned = 0;
        foreach ($DB->get_records('local_practice_def', $conditions) as $def) {
            if (in_array($def->course, $protectcourses, true)) {
                continue; // e.g. Rule defs during an LP-only sync — never swept.
            }
            if (!isset($seen[$def->checkpoint_uid])) {
                if (!$dryrun) {
                    $def->active = 0;
                    $def->tombstoned = 1;
                    $def->timemodified = $now;
                    $DB->update_record('local_practice_def', $def);
                }
                $tombstoned++;
            }
        }

        return ['upserted' => $upserted, 'tombstoned' => $tombstoned, 'unchanged' => $unchanged];
    }
}
