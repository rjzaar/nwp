@local @local_feedback @lp_target
Feature: Feedback submissions attach to a learning-point target (Approach A)
  In order to route feedback to the right session/depth in the AVC reviewer queue
  As the local_feedback plugin
  I encode the LP target as a string "lp:<course>:<session>:<depth>" in the cross-site payload

  Background:
    Given the local_feedback plugin is configured to forward to AVC
    And mock AVC endpoint capture is reset
    And course "saint-school-A1" with session "1" and depth levels 1-6 exists
    And the following "users" exist:
      | username  | firstname | lastname  | email             |
      | alice     | Alice     | Tester    | alice@example.com |

  @javascript
  Scenario: A feedback submission from within a depth-content widget tags the target
    Given I log in as "alice"
    And I visit the depth-3 view of "saint-school-A1" session 1
    When I open the feedback widget
    And I select type "suggestion"
    And I set the field "Brief title..." to "Reword sentence 2"
    And I click "Submit"
    Then the mock AVC endpoint should have received a request with:
      | type           | suggestion          |
      | target_url     | (a URL containing course=saint-school-A1 + session=1 + depth=3) |
    And the payload includes a "lp_target" field equal to "lp:saint-school-A1:1:3"

  Scenario: Submissions outside a depth-content context omit lp_target
    Given I log in as "alice"
    And I visit the site dashboard
    When I open the feedback widget
    And I submit a title "General site comment"
    Then the mock AVC endpoint should have received a request without "lp_target"
