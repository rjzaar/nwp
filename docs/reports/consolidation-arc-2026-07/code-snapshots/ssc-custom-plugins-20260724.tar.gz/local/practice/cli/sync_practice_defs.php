<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * CLI: sync checkpoint DEFINITIONS from the built catalog JSON into
 * local_practice_def. Definition data only (no member state is touched).
 *
 * Reads build/json/<pointid>.json (the same artefacts populate_courses.php
 * consumes), UPSERTS a def per LP-level `checkpoints:` entry / application-atom
 * checkpoint, and TOMBSTONES (never deletes) any def no longer in the catalog.
 *
 * Usage:
 *   php sync_practice_defs.php --jsondir=/path/to/build/json
 *   php sync_practice_defs.php --jsondir=/path/to/build/json --course=B5
 *   php sync_practice_defs.php --jsondir=/path/to/build/json --dry-run
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('CLI_SCRIPT', true);

require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/clilib.php');
require_once($CFG->dirroot . '/local/practice/lib.php');

use local_practice\def_sync;

list($options, $unrecognised) = cli_get_params([
    'jsondir'      => '',
    'course'       => '',
    'disciplines'  => '',
    'dry-run'      => false,
    'help'         => false,
], [
    'j' => 'jsondir',
    'c' => 'course',
    'd' => 'disciplines',
    'n' => 'dry-run',
    'h' => 'help',
]);

if ($options['help'] || empty($options['jsondir'])) {
    cli_writeln(<<<EOT
Sync practice checkpoint definitions from built catalog JSON.

Options:
  --jsondir=PATH      Directory of built LP JSON files (required, e.g. build/json)
  --course=CODE       Only sync this course's checkpoints (e.g. B5)
  --disciplines=PATH  Also sync the Rule registry (catalog/disciplines.yaml)
  --dry-run, -n       Report what would change; write nothing
  -h, --help          Show this help
EOT);
    exit(0);
}

$jsondir = $options['jsondir'];
if (!is_dir($jsondir)) {
    cli_error("JSON directory not found: $jsondir");
}
$dryrun = !empty($options['dry-run']);
$coursefilter = $options['course'] ?: null;

$files = glob("$jsondir/*.json");
if (empty($files)) {
    cli_error("No JSON files found in $jsondir");
}

$rows = [];
$withcheckpoints = 0;
foreach ($files as $file) {
    $basename = basename($file, '.json');
    $course = explode('.', $basename)[0];
    if ($coursefilter && $course !== $coursefilter) {
        continue;
    }
    $lp = json_decode(file_get_contents($file), true);
    if (!is_array($lp)) {
        cli_writeln("  WARN: invalid JSON in " . basename($file));
        continue;
    }
    $defs = def_sync::extract($lp);
    if ($defs) {
        $withcheckpoints++;
        foreach ($defs as $d) {
            $rows[] = $d;
        }
    }
}

cli_writeln("Found " . count($rows) . " checkpoint def(s) across $withcheckpoints learning point(s).");

// The discipline registry: the ~8 canonical Rules minted ONCE (uid = rule.<uid>).
// LP checkpoints reach them via contributes_to (never re-minted per LP). Only synced
// when a --disciplines path is given (and never filtered out by --course).
if (!empty($options['disciplines']) && !$coursefilter) {
    $dpath = $options['disciplines'];
    if (!is_readable($dpath)) {
        cli_error("Disciplines registry not readable: $dpath");
    }
    // A tiny YAML shim is avoided: disciplines.yaml is simple; rely on the Symfony
    // YAML that ships with Moodle if present, else a minimal parse is not attempted.
    if (class_exists('\\Symfony\\Component\\Yaml\\Yaml')) {
        $registry = \Symfony\Component\Yaml\Yaml::parseFile($dpath);
    } else {
        require_once($CFG->libdir . '/spout/src/Spout/Autoloader/autoload.php'); // noop guard
        $registry = null;
    }
    if (is_array($registry)) {
        $rulerows = def_sync::disciplines_from_registry($registry);
        foreach ($rulerows as $rr) {
            $rows[] = $rr;
        }
        cli_writeln("Added " . count($rulerows) . " Rule def(s) from the discipline registry.");
    } else {
        cli_writeln("  WARN: could not parse the discipline registry (no YAML parser available).");
    }
}

// If the Rule registry was NOT part of this sync, protect course='rule' from the
// tombstone sweep (an LP-only sync must never sweep the canonical Rules).
$protect = empty($options['disciplines']) ? ['rule'] : [];
$result = def_sync::upsert_all($rows, $dryrun, $coursefilter, $protect);

cli_writeln("\n=== Summary ===");
cli_writeln("Upserted:   {$result['upserted']}");
cli_writeln("Unchanged:  {$result['unchanged']}");
cli_writeln("Tombstoned: {$result['tombstoned']}  (removed from catalog; member state preserved)");
if ($dryrun) {
    cli_writeln("(Dry run — no changes written)");
}
