<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy (GDPR) provider for local_practice.
 *
 * WHY ERASURE IS TRIVIAL HERE. The local_practice_* member tables were built
 * FK-free, string-keyed on the canonical checkpoint_uid, with NO delete
 * callbacks (see db/install.xml). There is therefore NO cascade to unwind: a
 * data-subject erasure is a single explicit `DELETE WHERE userid = ?` per
 * member table. This provider is that explicit path (it is NOT a Moodle
 * cascade and NOT a `--clear` render rebuild — a rebuild deliberately
 * PRESERVES member state; only this erasure deletes it).
 *
 * Practice/checkpoint state is GDPR Art. 9 special-category data (religious
 * practice). This provider joins the nwc<->ssc erasure round-trip (ops#93) so
 * one "delete my formation record" request clears the practice ledger too.
 *
 * NO-AI-ACCESS: nothing here (including export) may be routed to any AI/LLM
 * system. Export is for the data subject's own Subject-Access Request only.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_practice\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use context_system;
use context_user;

defined('MOODLE_INTERNAL') || die();

/**
 * Privacy provider: describes and erases local_practice member data.
 */
class provider implements
        \core_privacy\local\metadata\provider,
        \core_privacy\local\request\core_userlist_provider,
        \core_privacy\local\request\plugin\provider {

    /**
     * Describe the member data this plugin stores.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('local_practice_state', [
            'userid'            => 'privacy:metadata:local_practice_state:userid',
            'checkpoint_uid'    => 'privacy:metadata:local_practice_state:checkpoint_uid',
            'status'            => 'privacy:metadata:local_practice_state:status',
            'streak'            => 'privacy:metadata:local_practice_state:streak',
            'last_engaged_at'   => 'privacy:metadata:local_practice_state:last_engaged_at',
        ], 'privacy:metadata:local_practice_state');

        $collection->add_database_table('local_practice_log', [
            'userid'         => 'privacy:metadata:local_practice_log:userid',
            'checkpoint_uid' => 'privacy:metadata:local_practice_log:checkpoint_uid',
            'ts'             => 'privacy:metadata:local_practice_log:ts',
            'source'         => 'privacy:metadata:local_practice_log:source',
        ], 'privacy:metadata:local_practice_log');

        $collection->add_database_table('local_practice_reflection', [
            'userid'         => 'privacy:metadata:local_practice_reflection:userid',
            'checkpoint_uid' => 'privacy:metadata:local_practice_reflection:checkpoint_uid',
            'body'           => 'privacy:metadata:local_practice_reflection:body',
            'ts'             => 'privacy:metadata:local_practice_reflection:ts',
        ], 'privacy:metadata:local_practice_reflection');

        return $collection;
    }

    /**
     * All member data lives in the user's own context.
     *
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();
        // Member state is not attached to a course/module context (FK-free); it
        // belongs to the user. Report the user context if any row exists.
        global $DB;
        $tables = ['local_practice_state', 'local_practice_log', 'local_practice_reflection'];
        foreach ($tables as $table) {
            if ($DB->record_exists($table, ['userid' => $userid])) {
                $contextlist->add_user_context($userid);
                break;
            }
        }
        return $contextlist;
    }

    /**
     * Find users with data in the given (user) context.
     *
     * @param userlist $userlist
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();
        if (!$context instanceof context_user) {
            return;
        }
        $userid = $context->instanceid;
        global $DB;
        $tables = ['local_practice_state', 'local_practice_log', 'local_practice_reflection'];
        foreach ($tables as $table) {
            if ($DB->record_exists($table, ['userid' => $userid])) {
                $userlist->add_user($userid);
                return;
            }
        }
    }

    /**
     * Export a data subject's practice record (for their own SAR).
     *
     * @param approved_contextlist $contextlist
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if (!$context instanceof context_user || $context->instanceid != $userid) {
                continue;
            }
            $data = (object) [
                'state'       => array_values($DB->get_records('local_practice_state', ['userid' => $userid])),
                'log'         => array_values($DB->get_records('local_practice_log', ['userid' => $userid])),
                'reflections' => array_values($DB->get_records('local_practice_reflection', ['userid' => $userid])),
            ];
            writer::with_context($context)->export_data(
                [get_string('pluginname', 'local_practice')], $data);
        }
    }

    /**
     * Erase all data in a context. Only a user context is meaningful here.
     *
     * @param \context $context
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        if (!$context instanceof context_user) {
            return;
        }
        self::erase_user($context->instanceid);
    }

    /**
     * Erase the given data subject's practice record across the approved contexts.
     *
     * @param approved_contextlist $contextlist
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context instanceof context_user && $context->instanceid == $userid) {
                self::erase_user($userid);
                return;
            }
        }
    }

    /**
     * Erase the approved users in the given context.
     *
     * @param approved_userlist $userlist
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        $context = $userlist->get_context();
        if (!$context instanceof context_user) {
            return;
        }
        foreach ($userlist->get_userids() as $userid) {
            if ($userid == $context->instanceid) {
                self::erase_user($userid);
            }
        }
    }

    /**
     * THE erasure primitive: a trivial explicit DELETE per FK-free member table.
     *
     * This is the whole reason the tables were built FK-free and string-keyed:
     * no cascade, no orphan-hunting — three unconditional deletes fully remove
     * a member's Art. 9 practice record.
     *
     * @param int $userid
     */
    protected static function erase_user(int $userid) {
        global $DB;
        $DB->delete_records('local_practice_state', ['userid' => $userid]);
        $DB->delete_records('local_practice_log', ['userid' => $userid]);
        $DB->delete_records('local_practice_reflection', ['userid' => $userid]);
        // local_practice_def holds NO member data (definition data only) — untouched.
    }
}
