<?php
/**
 * local_feedback — admin/mentor view: list of all feedback submissions.
 * Submitters see only their own; Tester Guild mentors see everything.
 */
require_once(__DIR__ . '/../../config.php');

require_login();

$context = context_system::instance();
$can_review = has_capability('local/feedback:review', $context);
$can_view   = has_capability('local/feedback:viewboard', $context);
if (!$can_review && !$can_view) {
    throw new moodle_exception('nopermissions', 'error', '', get_string('feedback:viewboard', 'local_feedback'));
}

$status_filter = optional_param('status', 'all', PARAM_ALPHA);
$type_filter   = optional_param('type', 'all', PARAM_ALPHA);

$PAGE->set_url(new moodle_url('/local/feedback/index.php'));
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_title(get_string('index_title', 'local_feedback'));
$PAGE->set_heading(get_string('index_title', 'local_feedback'));

global $DB, $USER, $OUTPUT;

// Build query: mentors see all; others see only their own.
$where = [];
$params = [];
if (!$can_review) {
    $where[] = 'userid = :uid';
    $params['uid'] = $USER->id;
}
if ($status_filter !== 'all') {
    $where[] = 'status = :st';
    $params['st'] = $status_filter;
}
if ($type_filter !== 'all') {
    $where[] = 'type = :tp';
    $params['tp'] = $type_filter;
}
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$items = $DB->get_records_sql("
    SELECT id, type, title, status, userid, username, target_url, gitlab_issue_url,
           avc_score_awarded, timecreated, timemodified
      FROM {local_feedback}
      $where_sql
     ORDER BY timecreated DESC
     LIMIT 200
", $params);

echo $OUTPUT->header();
?>
<div class="local-feedback-board" style="max-width:980px;margin:20px auto;padding:0 16px;">
    <p style="color:#555;line-height:1.6;"><?php echo s(get_string('index_intro', 'local_feedback')); ?></p>

    <form method="get" action="" style="margin:18px 0;padding:14px;background:#f5f5f5;border-radius:6px;display:flex;gap:14px;flex-wrap:wrap;">
        <label>Status:
            <select name="status" onchange="this.form.submit()">
                <?php foreach (['all','pending','approved','rejected','implemented','duplicate'] as $s): ?>
                    <option value="<?php echo $s; ?>" <?php echo $status_filter === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Type:
            <select name="type" onchange="this.form.submit()">
                <?php foreach (['all','suggestion','question','issue','praise'] as $t): ?>
                    <option value="<?php echo $t; ?>" <?php echo $type_filter === $t ? 'selected' : ''; ?>><?php echo ucfirst($t); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <span style="margin-left:auto;color:#777;font-size:0.92em;align-self:center;"><?php echo count($items); ?> items</span>
    </form>

    <?php if (empty($items)): ?>
        <p style="color:#888;text-align:center;padding:40px 0;">No feedback yet.</p>
    <?php else: ?>
        <table class="generaltable" style="width:100%;background:#fff;border-radius:6px;overflow:hidden;">
            <thead style="background:#2E7D32;color:#fff;">
                <tr>
                    <th style="padding:10px;text-align:left;">When</th>
                    <th style="padding:10px;text-align:left;">Type</th>
                    <th style="padding:10px;text-align:left;">Title</th>
                    <th style="padding:10px;text-align:left;">From</th>
                    <th style="padding:10px;text-align:left;">Status</th>
                    <th style="padding:10px;text-align:right;">Score</th>
                    <th style="padding:10px;"></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($items as $item):
                $viewurl = new moodle_url('/local/feedback/view.php', ['id' => $item->id]);
                $type_colors = [
                    'suggestion' => '#2E7D32', 'question' => '#1565C0',
                    'issue' => '#C62828', 'praise' => '#F9A825',
                ];
                $status_colors = [
                    'pending' => '#FFA000', 'approved' => '#2E7D32', 'rejected' => '#C62828',
                    'implemented' => '#1565C0', 'duplicate' => '#888',
                ];
            ?>
                <tr style="border-bottom:1px solid #eee;">
                    <td style="padding:8px 10px;font-size:0.88em;color:#666;"><?php echo userdate($item->timecreated, '%Y-%m-%d %H:%M'); ?></td>
                    <td style="padding:8px 10px;"><span style="background:<?php echo $type_colors[$item->type] ?? '#666'; ?>;color:#fff;padding:2px 8px;border-radius:3px;font-size:0.82em;"><?php echo s($item->type); ?></span></td>
                    <td style="padding:8px 10px;"><a href="<?php echo $viewurl; ?>" style="color:#222;font-weight:500;text-decoration:none;"><?php echo s($item->title); ?></a></td>
                    <td style="padding:8px 10px;font-size:0.92em;color:#555;"><?php echo s($item->username ?? '—'); ?></td>
                    <td style="padding:8px 10px;"><span style="color:<?php echo $status_colors[$item->status] ?? '#888'; ?>;font-weight:500;font-size:0.88em;"><?php echo s(get_string('status_' . $item->status, 'local_feedback')); ?></span></td>
                    <td style="padding:8px 10px;text-align:right;font-weight:500;color:#2E7D32;"><?php echo $item->avc_score_awarded ? '+' . (int)$item->avc_score_awarded : '—'; ?></td>
                    <td style="padding:8px 10px;"><a href="<?php echo $viewurl; ?>" class="btn btn-sm btn-outline-secondary">View</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php
echo $OUTPUT->footer();
