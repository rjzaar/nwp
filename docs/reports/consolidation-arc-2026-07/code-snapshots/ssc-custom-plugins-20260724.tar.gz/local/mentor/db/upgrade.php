<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for local_mentor.
 *
 * v1.0 baseline: no upgrade steps yet (schema created by db/install.xml). New
 * member/relationship tables are FK-free by design (GDPR erasure posture); any
 * future column must stay NULLable or DEFAULTed and FK-free.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade the local_mentor plugin.
 *
 * @param int $oldversion the version we are upgrading from
 * @return bool
 */
function xmldb_local_mentor_upgrade($oldversion) {
    // No upgrade steps yet — v1.0 is the install baseline.
    return true;
}
