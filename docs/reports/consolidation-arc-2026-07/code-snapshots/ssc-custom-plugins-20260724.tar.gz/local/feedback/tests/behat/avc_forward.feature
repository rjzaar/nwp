@local @local_feedback @local_feedback_avc
Feature: SS forwards feedback events to AVC for Tester Guild scoring
  In order to credit AVC Tester Guild members for SS feedback
  As the local_feedback plugin
  I need to POST each submission and each mentor decision to AVC

  Background:
    # The mock AVC endpoint is a tiny PHP responder that writes any POST
    # body to a file we can read back in the steps below.
    Given the following config values are set as admin:
      | enabled  | 1                                                                        | local_feedback |
      | avc_url  | https://ss-dev.ddev.site/local/feedback/tests/fixtures/mock_avc.php      | local_feedback |
      | avc_token| test-bearer-token                                                        | local_feedback |
      | avc_score_default | 10                                                              | local_feedback |
    And the following "users" exist:
      | username  | firstname | lastname  | email             |
      | submitter | Sub       | Mitter    | sub@example.com   |
      | mentor    | Test      | Mentor    | mentor@example.com|
    And the following "role assigns" exist:
      | user   | role    | contextlevel | reference |
      | mentor | manager | System       |           |
    And the mock AVC endpoint capture file is reset

  @javascript
  Scenario: Submitting a suggestion POSTs status=submitted with score=null
    Given I log in as "submitter"
    And I am on homepage
    When I click on ".local-feedback-trigger" "css_element"
    And I set the field "Brief title..." to "Test forward to AVC"
    And I click on ".local-feedback-popup__submit" "css_element"
    Then the mock AVC endpoint should have received a request with:
      | type       | suggestion          |
      | title      | Test forward to AVC |
      | status     | submitted           |
      | score      | null                |

  Scenario: Approving a feedback POSTs status=approved with default score
    Given the following "local_feedback" entries exist:
      | type       | title              | userid     | status  |
      | suggestion | Pending review     | submitter  | pending |
    And I log in as "mentor"
    When I navigate to "/local/feedback/index.php"
    And I follow "Pending review"
    And I press "Approve"
    Then the mock AVC endpoint should have received a request with:
      | title  | Pending review |
      | status | approved       |
      | score  | 10             |

  Scenario: Marking implemented gives 1.5x bonus score
    Given the following "local_feedback" entries exist:
      | type       | title         | userid     | status  |
      | suggestion | Did the thing | submitter  | pending |
    And I log in as "mentor"
    When I navigate to "/local/feedback/index.php"
    And I follow "Did the thing"
    And I press "Mark implemented"
    Then the mock AVC endpoint should have received a request with:
      | title  | Did the thing |
      | status | implemented   |
      | score  | 15            |
