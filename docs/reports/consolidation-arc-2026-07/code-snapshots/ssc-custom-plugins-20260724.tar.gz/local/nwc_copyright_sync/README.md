# local_nwc_copyright_sync

Saint School Moodle plugin that **receives** canonical legal-text
updates from NWC's `nwc_copyright` Drupal module and publishes new
versions in Moodle's native `tool_policy`.

## What it is

A single HTTPS POST endpoint at `/local/nwc_copyright_sync/policy_set.php`
guarded by a Bearer token. NWC's `MoodleToolPolicySync` PHP service
POSTs to this endpoint with the new policy body + version metadata;
this plugin writes a fresh row into `{tool_policy_versions}` and
points `currentversionid` at it. Moodle's tool_policy then forces
re-acceptance for every user on next login.

## Why

The NWC side is the canonical source for every user-facing legal
document (`nwc_copyright/canonical-text/*.md`). When the operator
bumps a policy version, one drush command propagates the new text to
both sites. This plugin is the SS-side receiver.

## Install

The plugin is installed automatically by the v3 build pipeline (see
`~/dir/courses_v3/plugins/manifest.yaml` — added 2026-05-17). For a
manual install:

```bash
cp -r ~/dir/courses_v3/plugins/local/nwc_copyright_sync \
      $MOODLE_ROOT/local/nwc_copyright_sync
php $MOODLE_ROOT/admin/cli/upgrade.php
```

## Configure

In Moodle admin → Site administration → Plugins → Local plugins →
NWC Copyright Sync:

| Setting | Value |
|---------|-------|
| Enable NWC → SS sync | ☑ |
| Shared bearer token | Same value as NWC's `nwc_copyright.settings:moodle:admin_token`. Generate once with `openssl rand -base64 32`. |
| Allowed source IPs (optional) | The NWC server's IP, comma-separated. Empty = any IP. |

## Test from the command line

```bash
curl -X POST https://ss.nwpcode.org/local/nwc_copyright_sync/policy_set.php \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "policy_name": "site_terms",
    "title": "Site Terms of Use",
    "type": "site",
    "version": 2,
    "effective_date": "2026-05-17",
    "change_summary": "test bump",
    "body_md": "# Test\n\nThis is a test version."
  }'
```

Expected: `200 {"ok":true,"ss_version_id":<int>}`.

## Behaviour

| `status`/event | Action |
|----------------|--------|
| First POST for a policy_name | Create new `{tool_policy}` row + first version |
| Subsequent POST with new version | Insert new `{tool_policy_versions}` row + bump `currentversionid` |
| Invalid token | 401 |
| Source IP not in allowlist | 403 (if allowlist configured) |
| Disabled in admin | 503 |
| Malformed body | 400 with `details` |
| DB or server error | 500 |

## Policy name mapping

| NWC canonical doc | SS policy_name | tool_policy type |
|---|---|---|
| terms | `site_terms` | site |
| privacy | `privacy_policy` | privacy |
| aup | `aup` | other |
| copyright-notice | `copyright_notice` | other |
| beta-community-cc0-agreement | (NOT propagated to SS) | n/a |

The beta-community agreement is NWC-only (admission gate); SS doesn't
host it.

## Related

- NWC side: `~/nwp/sites/nwc/dev/html/profiles/custom/nwc/modules/nwc_features/nwc_copyright/`
- Spec: `~/central/IMPLEMENTATION-PLAN.md` §2.5
- Cross-site auth pattern: same Bearer-token shape as `local_feedback` →
  NWC `nwc_feedback.cross_site_log` route
