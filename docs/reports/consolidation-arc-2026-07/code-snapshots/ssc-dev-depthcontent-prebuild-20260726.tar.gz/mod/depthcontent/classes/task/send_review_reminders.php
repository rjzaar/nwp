<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Scheduled task: send daily review reminders to users with due items.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_depthcontent\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Send review reminder notifications to users who have due spaced-repetition items.
 */
class send_review_reminders extends \core\task\scheduled_task {

    /**
     * Return the task name.
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_sendreviewreminders', 'mod_depthcontent');
    }

    /**
     * Execute the task.
     */
    public function execute() {
        global $DB;

        $now = time();

        // Find all users with due review items.
        $sql = "SELECT sr.userid, COUNT(*) AS duecount
                  FROM {depthcontent_sr} sr
                 WHERE sr.next_review <= :now
                   AND sr.repetitions > 0
              GROUP BY sr.userid";
        $users = $DB->get_records_sql($sql, ['now' => $now]);

        if (empty($users)) {
            mtrace('No users with due review items.');
            return;
        }

        $sent = 0;
        foreach ($users as $record) {
            $user = $DB->get_record('user', ['id' => $record->userid, 'deleted' => 0, 'suspended' => 0]);
            if (!$user) {
                continue;
            }

            $duecount = (int) $record->duecount;
            $estimatedminutes = $duecount * 2;

            $message = new \core\message\message();
            $message->component = 'mod_depthcontent';
            $message->name = 'reviewreminder';
            $message->userfrom = \core_user::get_noreply_user();
            $message->userto = $user;
            $message->subject = get_string('remindersubject', 'mod_depthcontent', $duecount);
            $message->fullmessage = get_string('reminderbody', 'mod_depthcontent', (object) [
                'count' => $duecount,
                'minutes' => $estimatedminutes,
            ]);
            $message->fullmessageformat = FORMAT_PLAIN;
            $message->fullmessagehtml = get_string('reminderbodyhtml', 'mod_depthcontent', (object) [
                'count' => $duecount,
                'minutes' => $estimatedminutes,
            ]);
            $message->smallmessage = get_string('remindersmall', 'mod_depthcontent', $duecount);
            $message->notification = 1;
            $message->contexturl = new \moodle_url('/my/');
            $message->contexturlname = get_string('reviewdeck', 'mod_depthcontent');

            message_send($message);
            $sent++;
        }

        mtrace("Sent review reminders to {$sent} users.");
    }
}
