<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * local_practice library — the ONE write path (engaged()) + read helpers.
 *
 * SECURITY / GDPR (NWC-LEDGER-GDPR-DESIGN-2026-07-20, Art. 9): the
 * local_practice_* member tables record the religious PRACTICE of named
 * members. They carry NO foreign keys and NO delete callbacks (see
 * db/install.xml), so a data-subject erasure is a trivial explicit
 * DELETE WHERE userid=? (classes/privacy/provider.php + ops#93). A `--clear`
 * render rebuild deliberately PRESERVES this state — `--clear` != erasure.
 *
 * NO-AI-ACCESS MANDATE: this store must NEVER be exposed to, exported to, or
 * used as context for ANY AI/LLM system. No read path here may feed an
 * assistant, RAG index, or training set.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use local_practice\engine;
use local_practice\progression;

/**
 * THE one write path. Record that a member engaged a checkpoint on a date.
 *
 * Pipeline: enforce the MF-2 firewall -> append to local_practice_log ->
 * recompute derived state via the pure engine -> upsert local_practice_state.
 *
 * MF-2 FIREWALL (hard): a HABIT checkpoint can ONLY be engaged by an explicit
 * member tick (source=manual). A view/scroll (auto) engage on a habit-typed
 * checkpoint is REJECTED here — it is neither logged as an engagement nor
 * allowed to move state. (The pure engine drops it too; this is the outer,
 * authoritative guard so a view event can never even reach the log as an
 * engagement.) Viewing a guide never marks a prayer done.
 *
 * @param string   $checkpointuid Canonical checkpoint key <course>.<pointid>.<key>.
 * @param int      $userid        Moodle user id.
 * @param int|null $date          YYYYMMDD in the member's tz. Null => today (member tz).
 * @param string   $source        manual | view | scroll | cleared | adopt | paused | resumed. Default manual.
 * @param int|null $ts            Event unix ts. Null => now.
 * @return array|false Derived state array, or false if the engage was rejected
 *                     (MF-2 firewall, or no such active def).
 */
function local_practice_engaged(string $checkpointuid, int $userid, ?int $date = null,
        string $source = 'manual', ?int $ts = null) {
    global $DB;

    $ts = $ts ?? time();
    if ($date === null) {
        // Member-timezone day bucket (tick-not-calendar).
        $date = (int) userdate($ts, '%Y%m%d', 99, false);
    }

    // Resolve the definition (needed for the type -> firewall decision).
    $def = $DB->get_record('local_practice_def', ['checkpoint_uid' => $checkpointuid]);
    if (!$def || empty($def->active) || !empty($def->tombstoned)) {
        // No live checkpoint to engage (a retired checkpoint accepts no new marks).
        return false;
    }

    // Lifecycle control verbs (adopt/paused/resumed) are logged as-is; they are
    // never engagements (the engine drops them from the day resolver).
    $controlverbs = ['adopt', 'paused', 'resumed', 'cleared'];

    // Resolve the EFFECTIVE type for the firewall decision: a suggested checkpoint
    // engages per its adopts_as, but ONLY once adopted. Pre-adoption, nothing but
    // an explicit 'adopt' verb may be logged (tap-accept, never scroll-accept).
    $efftype = $def->type;
    if ($def->type === 'suggested') {
        $isadopted = $DB->record_exists('local_practice_log',
            ['userid' => $userid, 'checkpoint_uid' => $checkpointuid, 'source' => 'adopt']);
        if ($source !== 'adopt' && !$isadopted && !in_array($source, ['paused', 'resumed'], true)) {
            // An un-adopted suggestion carries zero state pressure — reject any
            // engagement until the member explicitly taps to adopt it.
            return false;
        }
        $efftype = (string) ($def->adopts_as ?? 'task');
    }

    // MF-2 firewall at the write boundary: an auto (view/scroll) source may never
    // engage a habit/rule/challenge (or an adopted-as-such suggestion). Control
    // verbs are allowed through (they are not engagements).
    if (!in_array($source, $controlverbs, true) && !engine::source_permitted($efftype, $source)) {
        // Rejected — the view event does not tick it and is not logged.
        return false;
    }

    // Append to the immutable engagement log.
    $logrow = (object) [
        'userid'         => $userid,
        'checkpoint_uid' => $checkpointuid,
        'ts'             => $ts,
        'localdate'      => $date,
        'source'         => $source,
    ];
    $DB->insert_record('local_practice_log', $logrow);

    // GATEWAY fan-out (contributes_to): a manual tick on a gateway checkpoint also
    // marks the linked rule/discipline for the SAME day — one act, one tick,
    // surfaced once. The fan-out source is 'manual', so MF-2 is preserved (the
    // rule is manual-only and this is a real member tick). Never fans out control
    // verbs, and never recurses (a rule has no contributes_to).
    if ($source === 'manual' && !empty($def->contributes_to)) {
        $ruleuid = 'rule.' . $def->contributes_to;
        if ($DB->record_exists('local_practice_def', ['checkpoint_uid' => $ruleuid, 'active' => 1])) {
            local_practice_engaged($ruleuid, $userid, $date, 'manual', $ts);
        }
    }

    // Recompute derived state from the whole log for this (user, checkpoint).
    return local_practice_recompute_state($checkpointuid, $userid, $def);
}

/**
 * Tap-adopt a `suggested` checkpoint (the explicit accept — never scroll-accept).
 * Logs an 'adopt' verb; from here the checkpoint behaves as its adopts_as type.
 *
 * Optionally captures an if-then implementation-intention ANCHOR at adoption
 * ("after X, I will Y") — the strongest positive adherence lever (d=0.65). The
 * anchor is stored on the member's state row and surfaced on the plan grid; it is
 * DISPLAY/support only and never gates state.
 *
 * @param string      $checkpointuid
 * @param int         $userid
 * @param int|null    $ts
 * @param string|null $anchor Optional "after X, I will Y" implementation intention.
 * @return array|false Derived state after adoption, or false if not a suggestion.
 */
function local_practice_adopt(string $checkpointuid, int $userid, ?int $ts = null, ?string $anchor = null) {
    global $DB;
    $def = $DB->get_record('local_practice_def', ['checkpoint_uid' => $checkpointuid]);
    if (!$def || $def->type !== 'suggested' || empty($def->active) || !empty($def->tombstoned)) {
        return false;
    }
    $state = local_practice_engaged($checkpointuid, $userid, null, 'adopt', $ts);
    if ($state !== false && $anchor !== null) {
        local_practice_set_anchor($checkpointuid, $userid, $anchor);
    }
    return $state;
}

/**
 * Store (or clear) the member's if-then implementation-intention anchor for a
 * checkpoint. Display/support only — the anchor never affects recorded state.
 *
 * @param string      $checkpointuid
 * @param int         $userid
 * @param string|null $anchor "after X, I will Y" (null/empty clears it).
 * @return void
 */
function local_practice_set_anchor(string $checkpointuid, int $userid, ?string $anchor): void {
    global $DB;
    $clean = progression::sanitise_anchor($anchor);
    $now = time();
    $existing = $DB->get_record('local_practice_state',
        ['userid' => $userid, 'checkpoint_uid' => $checkpointuid]);
    if ($existing) {
        $existing->anchor_plan = $clean;
        $existing->timemodified = $now;
        $DB->update_record('local_practice_state', $existing);
    } else {
        // No state row yet (anchor set at/around adoption): seed a minimal row.
        $DB->insert_record('local_practice_state', (object) [
            'userid'             => $userid,
            'checkpoint_uid'     => $checkpointuid,
            'status'             => 'todo',
            'streak'             => 0,
            'engaged_days'       => 0,
            'last_engaged_at'    => 0,
            'last_engaged_date'  => 0,
            'first_engaged_date' => 0,
            'retired_by_member'  => 0,
            'anchor_plan'        => $clean,
            'timecreated'        => $now,
            'timemodified'       => $now,
        ]);
    }
}

/**
 * Recompute and upsert local_practice_state from the engagement log.
 *
 * @param string        $checkpointuid
 * @param int           $userid
 * @param stdClass|null $def Optional preloaded def.
 * @return array The derived state array.
 */
function local_practice_recompute_state(string $checkpointuid, int $userid, $def = null): array {
    global $DB;

    if ($def === null) {
        $def = $DB->get_record('local_practice_def', ['checkpoint_uid' => $checkpointuid]);
    }
    // Pass the FULL def shape the v3.3 engine understands (type + the lifecycle
    // fields). All numbers stay injected via local_practice_thresholds().
    $defarr = [
        'type'              => $def->type ?? 'task',
        'pacing'            => $def->pacing ?? 'tick',
        'cadence'          => $def->cadence ?? null,
        'adopts_as'         => $def->adopts_as ?? null,
        'on_consolidate'    => $def->on_consolidate ?? null,
        'review_after_days' => isset($def->review_after_days) ? (int) $def->review_after_days : null,
        'season'            => (!empty($def->season_completes_at)) ? [
            'window'       => $def->season_window ?? null,
            'completes_at' => $def->season_completes_at,
        ] : null,
    ];

    $log = $DB->get_records('local_practice_log',
        ['userid' => $userid, 'checkpoint_uid' => $checkpointuid], 'ts ASC',
        'id, ts, localdate, source');
    $rows = [];
    foreach ($log as $r) {
        $rows[] = ['ts' => (int) $r->ts, 'localdate' => (int) $r->localdate, 'source' => $r->source];
    }

    $state = engine::derive($rows, $defarr, local_practice_thresholds());

    $now = time();
    $existing = $DB->get_record('local_practice_state',
        ['userid' => $userid, 'checkpoint_uid' => $checkpointuid]);
    $consolidatedat = ($state['on_consolidate'] !== null) ? ($state['last_engaged_at'] ?: $now) : null;
    if ($existing) {
        $existing->status             = $state['status'];
        $existing->streak             = $state['streak'];
        $existing->engaged_days       = $state['engaged_days'];
        $existing->last_engaged_at    = $state['last_engaged_at'];
        $existing->last_engaged_date  = $state['last_engaged_date'];
        $existing->first_engaged_date = $state['first_engaged_date'];
        $existing->adopted_as         = $state['adopted_as'];
        if (!empty($state['adopted']) && empty($existing->adopted_at)) {
            $existing->adopted_at = $now;
        }
        if ($consolidatedat !== null && empty($existing->consolidated_at)) {
            $existing->consolidated_at = $consolidatedat;
        }
        $existing->timemodified       = $now;
        $DB->update_record('local_practice_state', $existing);
    } else {
        $DB->insert_record('local_practice_state', (object) [
            'userid'             => $userid,
            'checkpoint_uid'     => $checkpointuid,
            'status'             => $state['status'],
            'streak'             => $state['streak'],
            'engaged_days'       => $state['engaged_days'],
            'last_engaged_at'    => $state['last_engaged_at'],
            'last_engaged_date'  => $state['last_engaged_date'],
            'first_engaged_date' => $state['first_engaged_date'],
            'adopted_at'         => !empty($state['adopted']) ? $now : null,
            'adopted_as'         => $state['adopted_as'],
            'consolidated_at'    => $consolidatedat,
            'retired_by_member'  => 0,
            'timecreated'        => $now,
            'timemodified'       => $now,
        ]);
    }

    return $state;
}

/**
 * Injected engine thresholds (Pedagogy-owned `practice_defaults`; the runtime
 * seam mirroring catalog/schema.yaml). A later phase reads these from site config;
 * for now they mirror the ratified defaults, plus today's date for season-window
 * completion. Cadence-keyed values are resolved per-def inside the engine.
 *
 * @return array
 */
function local_practice_thresholds(): array {
    return [
        'skill_consolidate_days' => 3,
        'habit_form_count'       => ['daily' => 21, 'weekly' => 8, 'situational' => 5],
        'habit_span_floor_days'  => ['daily' => 30, 'weekly' => 60, 'situational' => 21],
        'challenge_window_days'  => ['daily' => 30, 'weekly' => 56, 'situational' => 21],
        // Today (member-tz-agnostic UTC day bucket) drives season-window completion.
        'as_of_date'             => (int) userdate(time(), '%Y%m%d', 99, false),
    ];
}

/**
 * Return a member's plan: their state rows joined to the live definitions.
 *
 * Only the member's OWN checkpoints (surfacing firewall — a member sees only
 * their own detail). Retired (tombstoned) defs are surfaced flagged, never
 * dropped, so no state orphans.
 *
 * @param int $userid
 * @return array List of plan-item objects (def fields + state fields).
 */
function local_practice_get_plan(int $userid): array {
    global $DB;

    $sql = "SELECT s.id, s.checkpoint_uid, s.status, s.streak, s.engaged_days,
                   s.last_engaged_at, s.last_engaged_date, s.first_engaged_date,
                   s.adopted_at, s.adopted_as, s.consolidated_at, s.retired_by_member,
                   s.anchor_plan,
                   d.type, d.title, d.pacing, d.cadence, d.autotick, d.prompt_self,
                   d.prompt_self_text, d.contributes_to, d.on_consolidate,
                   d.review_after_days, d.season_window, d.season_completes_at,
                   d.condition_text, d.active, d.tombstoned
              FROM {local_practice_state} s
              JOIN {local_practice_def} d ON d.checkpoint_uid = s.checkpoint_uid
             WHERE s.userid = :userid
          ORDER BY d.tombstoned ASC, d.type ASC, d.title ASC";
    return array_values($DB->get_records_sql($sql, ['userid' => $userid]));
}

/**
 * Get a member's progression-view preference (full | gentle | quiet).
 *
 * DISPLAY ONLY — this preference governs what renders; ALL progression data is
 * always recorded regardless (hiding is never a data operation). Default = Gentle.
 *
 * @param int $userid
 * @return string one of progression::MODES.
 */
function local_practice_get_progression_view(int $userid): string {
    $pref = get_user_preferences('local_practice_progression_view',
        progression::default_mode(), $userid);
    return progression::normalise_mode($pref);
}

/**
 * Set a member's progression-view preference. This is the ONLY thing the setting
 * touches — it never reads, writes, or gates recorded state.
 *
 * @param int    $userid
 * @param string $mode full | gentle | quiet.
 * @return void
 */
function local_practice_set_progression_view(int $userid, string $mode): void {
    set_user_preference('local_practice_progression_view',
        progression::normalise_mode($mode), $userid);
}

/**
 * Build the render-ready progression payload for one plan item, governed by the
 * member's own progression-view preference. Pure display over recorded state.
 *
 * @param object $item   A plan item (from local_practice_get_plan()).
 * @param int    $userid
 * @param int    $asof   YYYYMMDD "today" for renewal detection (0 => use today).
 * @return array The progression::view() payload.
 */
function local_practice_progression_for($item, int $userid, int $asof = 0): array {
    if ($asof <= 0) {
        $asof = (int) userdate(time(), '%Y%m%d', 99, false);
    }
    $state = [
        'status'            => $item->status,
        'engaged_days'      => (int) $item->engaged_days,
        'last_engaged_date' => (int) $item->last_engaged_date,
        'on_consolidate'    => $item->on_consolidate ?? null,
        'anchor_plan'       => $item->anchor_plan ?? null,
    ];
    return progression::view($state, local_practice_get_progression_view($userid), $asof);
}
