<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Spaced repetition review dashboard.
 *
 * Shows the user's daily review queue across all courses, upcoming reviews,
 * and mastery statistics.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');
require_once($CFG->dirroot . '/mod/depthcontent/lib.php');

$courseid = optional_param('course', 0, PARAM_INT);

require_login();
$userid = $USER->id;

if ($courseid) {
    $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
    $context = context_course::instance($courseid);
    $PAGE->set_context($context);
    $PAGE->set_course($course);
    $PAGE->set_url('/mod/depthcontent/dashboard.php', ['course' => $courseid]);
    $PAGE->set_title($course->shortname . ': ' . get_string('reviewdashboard', 'depthcontent'));
    $PAGE->set_heading($course->fullname);
} else {
    $context = context_system::instance();
    $PAGE->set_context($context);
    $PAGE->set_url('/mod/depthcontent/dashboard.php');
    $PAGE->set_title(get_string('reviewdashboard', 'depthcontent'));
    $PAGE->set_heading(get_string('reviewdashboard', 'depthcontent'));
}

$PAGE->set_pagelayout('standard');
$PAGE->requires->css('/mod/depthcontent/styles.css');

// Get due reviews.
$duereviews = depthcontent_get_due_reviews($userid, $courseid);

// Get mastery stats.
$sql = "SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN p.status = 'new' THEN 1 ELSE 0 END) AS new_count,
            SUM(CASE WHEN p.status = 'learning' THEN 1 ELSE 0 END) AS learning_count,
            SUM(CASE WHEN p.status = 'review' THEN 1 ELSE 0 END) AS review_count,
            SUM(CASE WHEN p.status = 'mastered' THEN 1 ELSE 0 END) AS mastered_count
        FROM {depthcontent_progress} p
        JOIN {depthcontent} dc ON dc.id = p.depthcontentid
        WHERE p.userid = :userid";
$params = ['userid' => $userid];
if ($courseid) {
    $sql .= " AND dc.course = :courseid";
    $params['courseid'] = $courseid;
}
$stats = $DB->get_record_sql($sql, $params);

// Get upcoming reviews (next 7 days).
$nextweek = time() + (7 * 86400);
$sql = "SELECT sr.next_review, dc.name, dc.pointid, cm.id AS cmid
          FROM {depthcontent_sr} sr
          JOIN {depthcontent} dc ON dc.id = sr.depthcontentid
          JOIN {course_modules} cm ON cm.instance = dc.id
          JOIN {modules} m ON m.id = cm.module AND m.name = 'depthcontent'
         WHERE sr.userid = :userid
           AND sr.next_review > :now
           AND sr.next_review <= :nextweek
           AND sr.repetitions > 0";
$params = ['userid' => $userid, 'now' => time(), 'nextweek' => $nextweek];
if ($courseid) {
    $sql .= " AND dc.course = :courseid";
    $params['courseid'] = $courseid;
}
$sql .= " ORDER BY sr.next_review ASC LIMIT 20";
$upcoming = $DB->get_records_sql($sql, $params);

echo $OUTPUT->header();

// Link to examination mode.
if ($courseid) {
    $reviewurl = new moodle_url('/mod/depthcontent/review.php', ['course' => $courseid]);
    echo '<div class="dc-dashboard-actions">';
    echo '<a href="' . $reviewurl . '" class="btn btn-outline-primary mb-3">';
    echo get_string('reviewmode', 'depthcontent') . ' &mdash; ' . get_string('reviewmode_desc', 'depthcontent');
    echo '</a>';
    echo '</div>';
}

// Stats cards.
$total = $stats->total ?? 0;
$mastered = $stats->mastered_count ?? 0;
$learning = $stats->learning_count ?? 0;
$inreview = $stats->review_count ?? 0;

echo '<div class="dc-review-dashboard">';

echo '<div class="dc-stats-row">';
echo '<div class="dc-stat-card"><div class="dc-stat-number">' . count($duereviews) . '</div><div class="dc-stat-label">' . get_string('duetoday', 'depthcontent') . '</div></div>';
echo '<div class="dc-stat-card"><div class="dc-stat-number">' . $learning . '</div><div class="dc-stat-label">' . get_string('status_learning', 'depthcontent') . '</div></div>';
echo '<div class="dc-stat-card"><div class="dc-stat-number">' . $inreview . '</div><div class="dc-stat-label">' . get_string('status_review', 'depthcontent') . '</div></div>';
echo '<div class="dc-stat-card dc-stat-mastered"><div class="dc-stat-number">' . $mastered . '</div><div class="dc-stat-label">' . get_string('status_mastered', 'depthcontent') . '</div></div>';
echo '</div>';

// Due reviews list.
if (!empty($duereviews)) {
    echo '<h3>' . get_string('reviewqueue', 'depthcontent') . '</h3>';
    echo '<div class="dc-review-list">';
    foreach ($duereviews as $review) {
        $url = new moodle_url('/mod/depthcontent/view.php', ['id' => $review->cmid]);
        echo '<div class="dc-review-item">';
        echo '<a href="' . $url . '" class="dc-review-link">';
        echo '<span class="dc-review-point">' . s($review->pointid) . '</span> ';
        echo '<span class="dc-review-name">' . s($review->name) . '</span>';
        echo '</a>';
        echo '</div>';
    }
    echo '</div>';
    echo '<div class="dc-review-action">';
    if (!empty($duereviews)) {
        $first = reset($duereviews);
        $url = new moodle_url('/mod/depthcontent/view.php', ['id' => $first->cmid]);
        echo '<a href="' . $url . '" class="btn btn-primary">' . get_string('startreview', 'depthcontent') . '</a>';
    }
    echo '</div>';
} else {
    echo '<div class="dc-review-empty">';
    echo '<p>' . get_string('noreviewsdue', 'depthcontent') . '</p>';
    echo '</div>';
}

// Upcoming reviews.
if (!empty($upcoming)) {
    echo '<h3>' . get_string('upcomingreview', 'depthcontent') . '</h3>';
    echo '<div class="dc-upcoming-list">';
    $currentday = '';
    foreach ($upcoming as $item) {
        $day = userdate($item->next_review, get_string('strftimedatefull'));
        if ($day !== $currentday) {
            if ($currentday !== '') {
                echo '</div>';
            }
            echo '<div class="dc-upcoming-day">';
            echo '<h4 class="dc-upcoming-date">' . $day . '</h4>';
            $currentday = $day;
        }
        echo '<div class="dc-upcoming-item">';
        echo '<span class="dc-upcoming-point">' . s($item->pointid) . '</span> ';
        echo s($item->name);
        echo '</div>';
    }
    echo '</div>';
}

// Mastery progress bar.
if ($total > 0) {
    echo '<h3>' . get_string('masteryprogress', 'depthcontent') . '</h3>';
    $pct_mastered = round(($mastered / $total) * 100);
    $pct_review = round(($inreview / $total) * 100);
    $pct_learning = round(($learning / $total) * 100);
    echo '<div class="dc-mastery-bar">';
    echo '<div class="dc-mastery-segment dc-mastery-mastered" style="width:' . $pct_mastered . '%">' . ($pct_mastered > 5 ? $pct_mastered . '%' : '') . '</div>';
    echo '<div class="dc-mastery-segment dc-mastery-review" style="width:' . $pct_review . '%">' . ($pct_review > 5 ? $pct_review . '%' : '') . '</div>';
    echo '<div class="dc-mastery-segment dc-mastery-learning" style="width:' . $pct_learning . '%">' . ($pct_learning > 5 ? $pct_learning . '%' : '') . '</div>';
    echo '</div>';
    echo '<div class="dc-mastery-legend">';
    echo '<span class="dc-legend-mastered">' . get_string('status_mastered', 'depthcontent') . '</span>';
    echo '<span class="dc-legend-review">' . get_string('status_review', 'depthcontent') . '</span>';
    echo '<span class="dc-legend-learning">' . get_string('status_learning', 'depthcontent') . '</span>';
    echo '</div>';
}

echo '</div>';
echo $OUTPUT->footer();
