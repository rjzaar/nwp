<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026030900;
$plugin->requires  = 2024041600;
$plugin->component = 'format_tabbed';
