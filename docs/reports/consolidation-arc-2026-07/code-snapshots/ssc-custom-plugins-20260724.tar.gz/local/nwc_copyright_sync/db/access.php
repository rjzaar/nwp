<?php
defined('MOODLE_INTERNAL') || die();

$capabilities = [
    // Only admins manage the bearer token / config.
    'local/nwc_copyright_sync:manage' => [
        'riskbitmask'  => RISK_CONFIG,
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => [
            'manager' => CAP_ALLOW,
        ],
    ],
];
