<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Table-driven unit tests for the ACCOMPANIMENT consent + covenant + guards
 * (local_mentor, build #5).
 *
 * Runs WITHOUT a Moodle runtime:  php tests/mentor_test.php
 *
 * Proves (FORMATION-MASTER-DESIGN §4; FORMATION-plan-of-love-ux.md §4):
 *   - 3 consent tiers, default = the LOWEST (coarse); normalisation.
 *   - Per-item override resolution (an override wins over the tier default,
 *     regardless of tier; personal items default hidden).
 *   - The covenant: a grant CANNOT go active without accepting it.
 *   - is_active resolution (invited/paused/revoked/expired/covenant-less => no access).
 *   - Role-EXCLUSIVITY: the advancement-gate holder cannot mentor; self excluded.
 *   - Adults-only v1 + the ~12-mentees/mentor cap + 2-mentors/mentee cap.
 *   - Instant + retroactive revocation purges pushed shares.
 *
 * @package    local_mentor
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

if (!defined('MOODLE_INTERNAL')) {
    define('MOODLE_INTERNAL', true);
}
require_once(__DIR__ . '/../../practice/classes/engine.php');       // progression uses engine.
require_once(__DIR__ . '/../../practice/classes/progression.php');  // engagement-tier coarse states.
require_once(__DIR__ . '/../classes/mentor.php');

use local_mentor\mentor;

// ---- Tiny assertion harness (no PHPUnit / no Moodle needed) ----------------
$GLOBALS['__pass'] = 0;
$GLOBALS['__fail'] = 0;
$GLOBALS['__fails'] = [];

function check(string $name, $expected, $actual): void {
    if ($expected === $actual) {
        $GLOBALS['__pass']++;
    } else {
        $GLOBALS['__fail']++;
        $GLOBALS['__fails'][] = sprintf("  FAIL: %s\n        expected=%s got=%s",
            $name, var_export($expected, true), var_export($actual, true));
    }
}

// A gating-role checker that says "mentor 900 gates everyone; nobody else does".
$gate900 = function (int $mentorid, int $menteeid): bool {
    return $mentorid === 900;
};
$nogate = function (int $mentorid, int $menteeid): bool {
    return false;
};

// ===========================================================================
// CONSENT TIERS — default = LOWEST (coarse); normalisation; ordering
// ===========================================================================

check('TIER.default_coarse', 'coarse', mentor::default_tier());
check('TIER.default_is_lowest_rank', 0, mentor::tier_rank(mentor::default_tier()));
check('TIER.normalise_unknown_to_coarse', 'coarse', mentor::normalise_tier('sideways'));
check('TIER.normalise_null_to_coarse', 'coarse', mentor::normalise_tier(null));
check('TIER.normalise_engagement', 'engagement', mentor::normalise_tier(' ENGAGEMENT '));
check('TIER.normalise_detail', 'detail', mentor::normalise_tier('detail'));
check('TIER.rank_order_coarse', 0, mentor::tier_rank('coarse'));
check('TIER.rank_order_engagement', 1, mentor::tier_rank('engagement'));
check('TIER.rank_order_detail', 2, mentor::tier_rank('detail'));
check('TIER.detail_atleast_coarse', true, mentor::tier_at_least('detail', 'coarse'));
check('TIER.coarse_not_atleast_engagement', false, mentor::tier_at_least('coarse', 'engagement'));
check('TIER.engagement_atleast_engagement', true, mentor::tier_at_least('engagement', 'engagement'));

// ===========================================================================
// PER-ITEM OVERRIDE RESOLUTION — override wins over tier, regardless of tier
// ===========================================================================

// coarse tier: NO per-item visibility at all (coarse is rule-shape aggregate only)...
check('OVR.coarse_no_item', false, mentor::item_visible('coarse', [], 'B5.mp'));
// ...UNLESS the member explicitly elects to show that item (override wins).
check('OVR.coarse_override_show_wins', true, mentor::item_visible('coarse', ['B5.mp' => 'show'], 'B5.mp'));

// engagement tier: non-personal visible by default; personal hidden by default.
check('OVR.engagement_default_visible', true, mentor::item_visible('engagement', [], 'B5.mp'));
check('OVR.engagement_personal_hidden', false, mentor::item_visible('engagement', [], 'B5.secret', true));
// override HIDE wins even on a non-personal item at a higher tier.
check('OVR.engagement_override_hide_wins', false, mentor::item_visible('engagement', ['B5.mp' => 'hide'], 'B5.mp'));
// override SHOW un-hides a personal item.
check('OVR.detail_override_show_personal', true, mentor::item_visible('detail', ['B5.secret' => 'show'], 'B5.secret', true));
// garbage override values are ignored (fall through to tier default).
check('OVR.garbage_override_ignored', true, mentor::item_visible('engagement', ['B5.mp' => 'maybe'], 'B5.mp'));
check('OVR.normalise_keeps_only_showhide', ['a' => 'show', 'b' => 'hide'],
    mentor::normalise_overrides(['a' => 'SHOW', 'b' => ' hide ', 'c' => 'peek', 'd' => 5]));

// ===========================================================================
// THE COVENANT — no active grant without it
// ===========================================================================

$rel = mentor::new_relationship(10, 20, 'coarse', 20260720, 20261018);
check('COV.new_is_invited', mentor::STATUS_INVITED, $rel['status']);
check('COV.new_covenant_unaccepted', 0, $rel['covenant_accepted']);
check('COV.new_default_tier_when_blank', 'coarse', mentor::new_relationship(10, 20, 'x', 20260720)['tier']);

// Not active until covenant accepted, even if we force status.
$forced = $rel;
$forced['status'] = 'active';
check('COV.forced_active_without_covenant_not_active', false, mentor::is_active($forced, 20260721));

$accepted = mentor::accept_covenant($rel);
check('COV.accept_sets_flag', 1, $accepted['covenant_accepted']);
check('COV.accept_records_version', mentor::COVENANT_VERSION, $accepted['covenant_vid']);
check('COV.accept_activates', mentor::STATUS_ACTIVE, $accepted['status']);
check('COV.covenant_text_nonempty', true, strlen(mentor::covenant_text()) > 40);
check('COV.covenant_confidence', true, stripos(mentor::covenant_text(), 'confidence') !== false);
check('COV.covenant_no_ai', true, stripos(mentor::covenant_text(), 'no automated') !== false);
check('COV.covenant_not_compliance', true, stripos(mentor::covenant_text(), 'never to chase compliance') !== false);

// ===========================================================================
// is_active RESOLUTION — invited/paused/revoked/expired => no access
// ===========================================================================

check('ACT.active_unexpired', true, mentor::is_active($accepted, 20260901));
check('ACT.active_exactly_at_expiry_ok', true, mentor::is_active($accepted, 20261018)); // asof == renews_at.
check('ACT.expired_no_access', false, mentor::is_active($accepted, 20261019));           // one day past term.
check('ACT.no_asof_ignores_expiry', true, mentor::is_active($accepted, 0));

$invited = mentor::new_relationship(10, 20, 'coarse', 20260720, 20261018);
check('ACT.invited_no_access', false, mentor::is_active($invited, 20260721));

$paused = $accepted;
$paused['status'] = mentor::STATUS_PAUSED;
check('ACT.paused_no_access', false, mentor::is_active($paused, 20260721));

$revoked = mentor::revoke($accepted, 'member');
check('ACT.revoked_status', mentor::STATUS_REVOKED, $revoked['status']);
check('ACT.revoked_ended_by', 'member', $revoked['ended_by']);
check('ACT.revoked_no_access', false, mentor::is_active($revoked, 20260721));

// ===========================================================================
// ROLE-EXCLUSIVITY — the advancement-gate holder cannot mentor; self excluded
// ===========================================================================

check('ROLE.non_gating_may_mentor', true, mentor::can_mentor(20, 10, $nogate));
check('ROLE.gating_holder_excluded', false, mentor::can_mentor(900, 10, $gate900));
check('ROLE.self_excluded', false, mentor::can_mentor(10, 10, $nogate));
check('ROLE.self_excluded_even_if_nongating', false, mentor::can_mentor(42, 42, $nogate));

// ===========================================================================
// INVITE PATH — adults-only v1 + 12-mentee cap + 2-mentor cap + role/self
// ===========================================================================

$okopts = [
    'mentee_is_adult'     => true,
    'mentor_is_adult'     => true,
    'mentor_mentee_count' => 3,
    'mentee_mentor_count' => 0,
    'gating_role_check'   => $nogate,
];
check('INV.happy_path_ok', true, mentor::can_invite(20, 10, $okopts)['ok']);
check('INV.happy_path_no_reason', null, mentor::can_invite(20, 10, $okopts)['reason']);

// Adults-only v1 — either party a minor blocks.
$minormentee = ['mentee_is_adult' => false, 'mentor_is_adult' => true, 'gating_role_check' => $nogate];
check('INV.minor_mentee_blocked', false, mentor::can_invite(20, 10, $minormentee)['ok']);
check('INV.minor_mentee_reason', 'adults_only', mentor::can_invite(20, 10, $minormentee)['reason']);
$minormentor = ['mentee_is_adult' => true, 'mentor_is_adult' => false, 'gating_role_check' => $nogate];
check('INV.minor_mentor_reason', 'adults_only', mentor::can_invite(20, 10, $minormentor)['reason']);

// Role-exclusivity surfaces through the invite path.
$gatingopts = [
    'mentee_is_adult' => true, 'mentor_is_adult' => true,
    'mentor_mentee_count' => 0, 'mentee_mentor_count' => 0,
    'gating_role_check' => $gate900,
];
check('INV.gating_role_blocked', false, mentor::can_invite(900, 10, $gatingopts)['ok']);
check('INV.gating_role_reason', 'gating_role', mentor::can_invite(900, 10, $gatingopts)['reason']);
check('INV.self_reason', 'self', mentor::can_invite(10, 10, $okopts)['reason']);

// 12-mentee cap: at 12 the mentor is full; 11 still ok.
$atcap = $okopts; $atcap['mentor_mentee_count'] = 12;
check('INV.mentee_cap_at_12_blocked', false, mentor::can_invite(20, 10, $atcap)['ok']);
check('INV.mentee_cap_reason', 'mentee_cap', mentor::can_invite(20, 10, $atcap)['reason']);
$undercap = $okopts; $undercap['mentor_mentee_count'] = 11;
check('INV.mentee_cap_at_11_ok', true, mentor::can_invite(20, 10, $undercap)['ok']);
check('INV.cap_constant_is_12', 12, mentor::MAX_MENTEES_PER_MENTOR);

// 2-mentor cap (per mentee).
$mentorcap = $okopts; $mentorcap['mentee_mentor_count'] = 2;
check('INV.mentor_cap_at_2_blocked', false, mentor::can_invite(20, 10, $mentorcap)['ok']);
check('INV.mentor_cap_reason', 'mentor_cap', mentor::can_invite(20, 10, $mentorcap)['reason']);
check('INV.mentor_cap_constant_is_2', 2, mentor::MAX_MENTORS_PER_MENTEE);

// Precedence: adults-only checked before caps (a minor at cap reports adults_only).
$minoratcap = ['mentee_is_adult' => false, 'mentor_is_adult' => true,
    'mentor_mentee_count' => 99, 'mentee_mentor_count' => 99, 'gating_role_check' => $nogate];
check('INV.adults_before_cap', 'adults_only', mentor::can_invite(20, 10, $minoratcap)['reason']);

// ===========================================================================
// TERM — default 90 days constant; new_relationship carries the given term
// ===========================================================================

check('TERM.default_90', 90, mentor::TERM_DAYS);
check('TERM.new_carries_renews_at', 20261018, mentor::new_relationship(10, 20, 'coarse', 20260720, 20261018)['renews_at']);

// ===========================================================================
// RETROACTIVE REVOCATION purges pushed shares for the pair (and only that pair)
// ===========================================================================

$shares = [
    ['menteeid' => 10, 'mentorid' => 20, 'shared_on' => 20260801, 'payload' => ['tier' => 'coarse']],
    ['menteeid' => 10, 'mentorid' => 20, 'shared_on' => 20260808, 'payload' => ['tier' => 'coarse']],
    ['menteeid' => 10, 'mentorid' => 30, 'shared_on' => 20260808, 'payload' => ['tier' => 'coarse']], // other mentor.
    ['menteeid' => 11, 'mentorid' => 20, 'shared_on' => 20260808, 'payload' => ['tier' => 'coarse']], // other mentee.
];
$purged = mentor::purge_shares($shares, 10, 20);
check('REVOKE.purges_pair_shares', 2, count($purged));                 // the two 10->20 rows gone.
check('REVOKE.keeps_other_mentor', true, in_array(30, array_column($purged, 'mentorid'), true));
check('REVOKE.keeps_other_mentee', true, in_array(11, array_column($purged, 'menteeid'), true));
check('REVOKE.none_of_purged_pair_remain', 0,
    count(array_filter($purged, fn($s) => $s['menteeid'] === 10 && $s['mentorid'] === 20)));

// ---- Report ----------------------------------------------------------------
$total = $GLOBALS['__pass'] + $GLOBALS['__fail'];
echo "\nlocal_mentor consent + covenant + guards tests\n";
echo str_repeat('-', 58) . "\n";
if ($GLOBALS['__fail'] > 0) {
    echo implode("\n", $GLOBALS['__fails']) . "\n";
}
printf("%d/%d checks passed (%d failed)\n", $GLOBALS['__pass'], $total, $GLOBALS['__fail']);
exit($GLOBALS['__fail'] === 0 ? 0 : 1);
