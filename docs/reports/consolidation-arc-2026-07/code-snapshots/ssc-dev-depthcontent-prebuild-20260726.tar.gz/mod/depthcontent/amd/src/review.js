/**
 * Credit by examination — review mode JavaScript.
 *
 * Handles the three-phase examination flow:
 * Phase 1: Point selection (checkboxes)
 * Phase 2: Quiz generation and navigation
 * Phase 3: Results display and SR state update
 *
 * @module     mod_depthcontent/review
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define(['jquery', 'core/ajax', 'core/notification'], function($, Ajax, Notification) {

    /** Minimum score per point to pass (80%). */
    var PASS_THRESHOLD = 0.8;

    /** Minimum questions per ticked point. */
    var MIN_QUESTIONS_PER_POINT = 2;

    /** All point data keyed by depthcontent id. */
    var pointsMap = {};

    /** The quiz questions array for the current examination. */
    var quizQuestions = [];

    /** Current question index. */
    var currentQuestion = 0;

    /** User answers: index => selected option index or null. */
    var userAnswers = {};

    /** Course id. */
    var courseId = 0;

    /**
     * Shuffle an array in place (Fisher-Yates).
     * @param {Array} arr
     * @return {Array}
     */
    function shuffle(arr) {
        for (var i = arr.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
        return arr;
    }

    /**
     * Generate quiz questions for selected points.
     *
     * For each point, pick at least MIN_QUESTIONS_PER_POINT questions from
     * its quiz_items, preferring a mix of standard and advanced difficulty.
     *
     * @param {Array} selectedIds Array of depthcontent IDs.
     * @return {Array} Array of question objects.
     */
    function generateQuiz(selectedIds) {
        var questions = [];

        selectedIds.forEach(function(pointId) {
            var point = pointsMap[pointId];
            if (!point || !point.quizitems || point.quizitems.length === 0) {
                return;
            }

            var items = point.quizitems.slice();

            // Categorise by difficulty.
            var standard = [];
            var advanced = [];
            var other = [];

            items.forEach(function(item) {
                var diff = (item.difficulty || 'standard').toLowerCase();
                if (diff === 'advanced' || diff === 'hard') {
                    advanced.push(item);
                } else if (diff === 'standard' || diff === 'medium') {
                    standard.push(item);
                } else {
                    other.push(item);
                }
            });

            // Pick questions: try to get a mix.
            var picked = [];
            var needed = Math.max(MIN_QUESTIONS_PER_POINT, Math.min(items.length, 3));

            // Take one from each bucket if available.
            shuffle(standard);
            shuffle(advanced);
            shuffle(other);

            if (standard.length > 0) {
                picked.push(standard.shift());
            }
            if (advanced.length > 0) {
                picked.push(advanced.shift());
            }

            // Fill remaining from all pools.
            var remaining = standard.concat(advanced, other);
            shuffle(remaining);
            while (picked.length < needed && remaining.length > 0) {
                picked.push(remaining.shift());
            }

            // If we still don't have enough, just use what we have (min 1).
            if (picked.length === 0 && items.length > 0) {
                picked.push(items[0]);
            }

            // Tag each question with its parent point.
            picked.forEach(function(item, idx) {
                questions.push({
                    pointId: pointId,
                    pointLabel: point.pointid,
                    pointName: point.name,
                    cmid: point.cmid,
                    questionIndex: idx,
                    item: item
                });
            });
        });

        // Shuffle all questions across points.
        shuffle(questions);

        return questions;
    }

    /**
     * Render a single quiz question into the container.
     * @param {Number} idx
     */
    function renderQuestion(idx) {
        var q = quizQuestions[idx];
        var item = q.item;
        var type = item.type || 'multichoice';
        var existingAnswer = userAnswers[idx];

        var html = '<div class="dc-exam-question" data-idx="' + idx + '">';
        html += '<div class="dc-exam-point-label">' + escapeHtml(q.pointLabel) + ' — ' + escapeHtml(q.pointName) + '</div>';
        html += '<p class="dc-quiz-question">' + escapeHtml(item.question || '') + '</p>';

        if (type === 'multichoice' && item.options) {
            html += '<div class="dc-quiz-options">';
            item.options.forEach(function(opt, oidx) {
                var checked = (existingAnswer === oidx) ? ' checked' : '';
                html += '<label class="dc-quiz-option dc-exam-option" data-oidx="' + oidx + '">';
                html += '<input type="radio" name="dc_exam_q_' + idx + '" value="' + oidx + '"' + checked + '> ';
                html += escapeHtml(opt.text || '');
                html += '</label>';
            });
            html += '</div>';
        } else if (type === 'truefalse') {
            html += '<div class="dc-quiz-options">';
            var checkedTrue = (existingAnswer === 1) ? ' checked' : '';
            var checkedFalse = (existingAnswer === 0) ? ' checked' : '';
            html += '<label class="dc-quiz-option dc-exam-option" data-oidx="1">';
            html += '<input type="radio" name="dc_exam_q_' + idx + '" value="1"' + checkedTrue + '> True';
            html += '</label>';
            html += '<label class="dc-quiz-option dc-exam-option" data-oidx="0">';
            html += '<input type="radio" name="dc_exam_q_' + idx + '" value="0"' + checkedFalse + '> False';
            html += '</label>';
            html += '</div>';
        }

        html += '</div>';

        $('#dc-quiz-container').html(html);

        // Update progress.
        var total = quizQuestions.length;
        $('#dc-quiz-current').text(idx + 1);
        $('#dc-quiz-total').text(total);
        var pct = Math.round(((idx + 1) / total) * 100);
        $('#dc-quiz-progressbar').css('width', pct + '%').attr('aria-valuenow', pct);

        // Navigation state.
        $('#dc-quiz-prev').prop('disabled', idx === 0);
        if (idx === total - 1) {
            $('#dc-quiz-next').hide();
            $('#dc-quiz-finish').show();
        } else {
            $('#dc-quiz-next').show();
            $('#dc-quiz-finish').hide();
        }
    }

    /**
     * Save the current answer from the rendered question.
     */
    function saveCurrentAnswer() {
        var selected = $('input[name="dc_exam_q_' + currentQuestion + '"]:checked');
        if (selected.length > 0) {
            var val = parseInt(selected.val(), 10);
            userAnswers[currentQuestion] = val;
        }
    }

    /**
     * Score the quiz and build per-point results.
     *
     * @return {Object} { points: { pointId: { correct, total, passed, ... } }, overall: { ... } }
     */
    function scoreQuiz() {
        var pointResults = {};

        quizQuestions.forEach(function(q, idx) {
            var pointId = q.pointId;
            if (!pointResults[pointId]) {
                pointResults[pointId] = {
                    pointId: pointId,
                    pointLabel: q.pointLabel,
                    pointName: q.pointName,
                    cmid: q.cmid,
                    correct: 0,
                    total: 0,
                    passed: false,
                    questions: []
                };
            }

            var pr = pointResults[pointId];
            pr.total++;

            var userAnswer = userAnswers[idx];
            var isCorrect = false;
            var item = q.item;
            var type = item.type || 'multichoice';

            if (type === 'multichoice' && item.options && userAnswer !== undefined && userAnswer !== null) {
                isCorrect = !!(item.options[userAnswer] && item.options[userAnswer].correct);
            } else if (type === 'truefalse' && userAnswer !== undefined && userAnswer !== null) {
                var correctVal = item.correct_answer ? 1 : 0;
                isCorrect = (userAnswer === correctVal);
            }

            if (isCorrect) {
                pr.correct++;
            }

            pr.questions.push({
                question: item.question,
                correct: isCorrect,
                userAnswer: userAnswer,
                item: item
            });
        });

        // Determine pass/fail per point.
        var totalPassed = 0;
        var totalPoints = 0;
        Object.keys(pointResults).forEach(function(pid) {
            var pr = pointResults[pid];
            totalPoints++;
            var score = pr.total > 0 ? (pr.correct / pr.total) : 0;
            pr.score = score;
            pr.passed = score >= PASS_THRESHOLD;
            if (pr.passed) {
                totalPassed++;
            }
        });

        return {
            points: pointResults,
            totalPassed: totalPassed,
            totalPoints: totalPoints
        };
    }

    /**
     * Display results (Phase 3).
     * @param {Object} results
     */
    function showResults(results) {
        // Summary.
        var summaryHtml = '<div class="dc-results-stats">';
        summaryHtml += '<div class="dc-stat-card dc-stat-mastered">';
        summaryHtml += '<div class="dc-stat-number">' + results.totalPassed + ' / ' + results.totalPoints + '</div>';
        summaryHtml += '<div class="dc-stat-label">Points mastered</div>';
        summaryHtml += '</div></div>';

        $('#dc-results-summary').html(summaryHtml);

        // Per-point results.
        var listHtml = '';
        Object.keys(results.points).forEach(function(pid) {
            var pr = results.points[pid];
            var pct = Math.round(pr.score * 100);
            var statusClass = pr.passed ? 'dc-result-passed' : 'dc-result-failed';
            var statusText = pr.passed ? 'Passed (' + pct + '%)' : 'Needs review (' + pct + '%)';
            var statusBadge = pr.passed ? 'badge-success' : 'badge-warning';

            listHtml += '<div class="dc-result-point ' + statusClass + '">';
            listHtml += '<div class="dc-result-point-header">';
            listHtml += '<span class="dc-examine-pointid">' + escapeHtml(pr.pointLabel) + '</span> ';
            listHtml += '<span class="dc-examine-name">' + escapeHtml(pr.pointName) + '</span> ';
            listHtml += '<span class="badge ' + statusBadge + '">' + statusText + '</span>';
            listHtml += '</div>';

            // Show individual question results.
            listHtml += '<div class="dc-result-questions">';
            pr.questions.forEach(function(rq) {
                var icon = rq.correct ? '&#10003;' : '&#10007;';
                var cls = rq.correct ? 'dc-rq-correct' : 'dc-rq-incorrect';
                listHtml += '<div class="dc-result-question ' + cls + '">';
                listHtml += '<span class="dc-rq-icon">' + icon + '</span> ';
                listHtml += escapeHtml(rq.question || '');

                // For failed questions, show the correct answer.
                if (!rq.correct && rq.item) {
                    var correctText = getCorrectAnswerText(rq.item);
                    if (correctText) {
                        listHtml += '<div class="dc-rq-answer">Correct answer: ' + escapeHtml(correctText) + '</div>';
                    }
                }

                listHtml += '</div>';
            });
            listHtml += '</div>';

            // For failed points, show a link to the full content.
            if (!pr.passed) {
                var viewUrl = M.cfg.wwwroot + '/mod/depthcontent/view.php?id=' + pr.cmid;
                listHtml += '<div class="dc-result-study-link">';
                listHtml += '<a href="' + viewUrl + '" class="btn btn-sm btn-outline-primary">Study this point</a>';
                listHtml += '</div>';
            }

            listHtml += '</div>';
        });

        $('#dc-results-list').html(listHtml);
    }

    /**
     * Get human-readable correct answer text for a quiz item.
     * @param {Object} item
     * @return {String}
     */
    function getCorrectAnswerText(item) {
        var type = item.type || 'multichoice';
        if (type === 'multichoice' && item.options) {
            for (var i = 0; i < item.options.length; i++) {
                if (item.options[i].correct) {
                    return item.options[i].text || '';
                }
            }
        } else if (type === 'truefalse') {
            return item.correct_answer ? 'True' : 'False';
        }
        return '';
    }

    /**
     * Submit examination results to the server.
     * @param {Object} results
     */
    function submitResults(results) {
        var pointResults = [];
        Object.keys(results.points).forEach(function(pid) {
            var pr = results.points[pid];
            pointResults.push({
                depthcontentid: parseInt(pid, 10),
                correct: pr.correct,
                total: pr.total,
                passed: pr.passed ? 1 : 0
            });
        });

        Ajax.call([{
            methodname: 'mod_depthcontent_submit_review',
            args: {
                courseid: courseId,
                pointresults: JSON.stringify(pointResults)
            },
            done: function() {
                // Results saved successfully.
            },
            fail: function(err) {
                Notification.exception(err);
            }
        }]);
    }

    /**
     * Escape HTML entities.
     * @param {String} str
     * @return {String}
     */
    function escapeHtml(str) {
        if (!str) {
            return '';
        }
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    return {
        /**
         * Initialise the review module.
         * @param {Number} cid Course ID.
         * @param {Array} points Array of point data objects.
         */
        init: function(cid, points) {
            courseId = cid;

            // Build lookup map.
            points.forEach(function(p) {
                pointsMap[p.id] = p;
            });

            // ── Phase 1: Selection ──

            // Set total count.
            var totalCheckable = $('.dc-examine-check:not(:disabled)').length;
            $('#dc-point-total').text(totalCheckable);

            // Update selected count.
            function updateCount() {
                var count = $('.dc-examine-check:checked').length;
                $('#dc-selected-count').text(count);
                $('#dc-start-exam').prop('disabled', count === 0);
            }

            $(document).on('change', '.dc-examine-check', updateCount);

            $('#dc-select-all').on('click', function() {
                $('.dc-examine-check:not(:disabled)').prop('checked', true);
                updateCount();
            });

            $('#dc-select-none').on('click', function() {
                $('.dc-examine-check').prop('checked', false);
                updateCount();
            });

            // Start examination.
            $('#dc-start-exam').on('click', function() {
                var selectedIds = [];
                $('.dc-examine-check:checked').each(function() {
                    selectedIds.push(parseInt($(this).val(), 10));
                });

                if (selectedIds.length === 0) {
                    return;
                }

                // Generate quiz.
                quizQuestions = generateQuiz(selectedIds);
                if (quizQuestions.length === 0) {
                    return;
                }

                userAnswers = {};
                currentQuestion = 0;

                // Switch to Phase 2.
                $('#dc-phase-select').hide();
                $('#dc-phase-quiz').show();
                renderQuestion(0);
            });

            // ── Phase 2: Quiz Navigation ──

            $('#dc-quiz-next').on('click', function() {
                saveCurrentAnswer();
                if (currentQuestion < quizQuestions.length - 1) {
                    currentQuestion++;
                    renderQuestion(currentQuestion);
                }
            });

            $('#dc-quiz-prev').on('click', function() {
                saveCurrentAnswer();
                if (currentQuestion > 0) {
                    currentQuestion--;
                    renderQuestion(currentQuestion);
                }
            });

            // Finish quiz.
            $('#dc-quiz-finish').on('click', function() {
                saveCurrentAnswer();

                // Check for unanswered questions.
                var unanswered = 0;
                for (var i = 0; i < quizQuestions.length; i++) {
                    if (userAnswers[i] === undefined || userAnswers[i] === null) {
                        unanswered++;
                    }
                }

                if (unanswered > 0) {
                    // eslint-disable-next-line no-alert
                    if (!confirm('You have ' + unanswered + ' unanswered question(s). Unanswered questions will be marked incorrect. Continue?')) {
                        return;
                    }
                }

                // Score.
                var results = scoreQuiz();

                // Submit to server.
                submitResults(results);

                // Switch to Phase 3.
                $('#dc-phase-quiz').hide();
                $('#dc-phase-results').show();
                showResults(results);
            });

            // ── Phase 3: Retry ──

            $('#dc-results-retry').on('click', function() {
                // Reset and go back to Phase 1.
                quizQuestions = [];
                userAnswers = {};
                currentQuestion = 0;
                $('#dc-phase-results').hide();
                $('#dc-phase-select').show();
                // Uncheck all.
                $('.dc-examine-check').prop('checked', false);
                updateCount();
            });
        }
    };
});
