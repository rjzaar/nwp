<?php
/**
 * local_feedback — single-item view; mentors can approve/reject + award score.
 */
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/forwarder.php');

require_login();

$id = required_param('id', PARAM_INT);
$context = context_system::instance();

global $DB, $USER, $OUTPUT;

$item = $DB->get_record('local_feedback', ['id' => $id], '*', MUST_EXIST);
$can_review = has_capability('local/feedback:review', $context);
$is_owner = ((int)$item->userid === (int)$USER->id);

if (!$can_review && !$is_owner) {
    throw new moodle_exception('nopermissions', 'error', '', 'view feedback');
}

// ── Handle mentor review submission ──────────────────────────────────────
if ($can_review && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_sesskey();
    $action  = required_param('action', PARAM_ALPHA);
    $comment = optional_param('comment', '', PARAM_TEXT);
    $score   = optional_param('score', null, PARAM_INT);

    $status_map = [
        'approve'    => 'approved',
        'reject'     => 'rejected',
        'implement'  => 'implemented',
        'duplicate'  => 'duplicate',
    ];
    if (!isset($status_map[$action])) {
        throw new moodle_exception('invalidaction');
    }

    $new_status = $status_map[$action];
    $now = time();

    $item->status           = $new_status;
    $item->reviewer_userid  = $USER->id;
    $item->reviewer_comment = $comment;
    $item->reviewed_at      = $now;
    $item->timemodified     = $now;

    // Score: default to admin-configured default for approval/implementation; 0 otherwise.
    $default_score = (int)get_config('local_feedback', 'avc_score_default') ?: 10;
    if (in_array($new_status, ['approved', 'implemented'], true)) {
        $item->avc_score_awarded = $score !== null ? (int)$score : $default_score;
        // Implementation is worth more than just approval — bonus 50%.
        if ($new_status === 'implemented') {
            $item->avc_score_awarded = (int)round($item->avc_score_awarded * 1.5);
        }
    } else {
        $item->avc_score_awarded = 0;
    }

    $DB->update_record('local_feedback', $item);

    // Forward the review event to AVC so it can credit the user's tester-guild score.
    try {
        \local_feedback\forwarder::forward_review($item, (int)$item->avc_score_awarded, $new_status);
    } catch (Throwable $t) {
        debugging('local_feedback forwarder review failed: ' . $t->getMessage(), DEBUG_DEVELOPER);
    }

    redirect(new moodle_url('/local/feedback/view.php', ['id' => $id]),
        get_string('status_' . $new_status, 'local_feedback') . ' · score = ' . (int)$item->avc_score_awarded,
        2);
}

$PAGE->set_url(new moodle_url('/local/feedback/view.php', ['id' => $id]));
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_title(get_string('view_title', 'local_feedback', $id));
$PAGE->set_heading(get_string('view_title', 'local_feedback', $id));

echo $OUTPUT->header();

$type_colors = [
    'suggestion' => '#2E7D32', 'question' => '#1565C0',
    'issue' => '#C62828', 'praise' => '#F9A825',
];
$status_colors = [
    'pending' => '#FFA000', 'approved' => '#2E7D32', 'rejected' => '#C62828',
    'implemented' => '#1565C0', 'duplicate' => '#888',
];
?>
<div style="max-width:820px;margin:20px auto;padding:0 16px;">
    <div style="background:#fff;border-radius:10px;padding:24px 28px;box-shadow:0 1px 3px rgba(0,0,0,.06);margin-bottom:20px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:12px;">
            <div>
                <span style="background:<?php echo $type_colors[$item->type] ?? '#666'; ?>;color:#fff;padding:3px 10px;border-radius:4px;font-size:0.78em;font-weight:600;text-transform:uppercase;letter-spacing:.05em;"><?php echo s($item->type); ?></span>
                <span style="background:<?php echo $status_colors[$item->status] ?? '#888'; ?>;color:#fff;padding:3px 10px;border-radius:4px;font-size:0.78em;font-weight:600;text-transform:uppercase;letter-spacing:.05em;margin-left:6px;"><?php echo s($item->status); ?></span>
            </div>
            <div style="font-size:0.85em;color:#888;">#<?php echo (int)$item->id; ?></div>
        </div>

        <h2 style="color:#222;margin:8px 0 16px;font-size:1.5em;"><?php echo s($item->title); ?></h2>

        <?php if (trim($item->body ?? '') !== ''): ?>
            <div style="background:#fafafa;padding:14px 18px;border-radius:5px;border-left:3px solid #2E7D32;line-height:1.6;color:#333;margin:12px 0;">
                <?php echo nl2br(s($item->body)); ?>
            </div>
        <?php endif; ?>

        <div style="font-size:0.88em;color:#666;line-height:1.7;margin-top:18px;border-top:1px solid #eee;padding-top:12px;">
            <strong>From:</strong> <?php echo s($item->username ?? 'unknown'); ?>
            (user id <?php echo (int)$item->userid; ?>)<br>
            <strong>Submitted:</strong> <?php echo userdate($item->timecreated); ?><br>
            <?php if (!empty($item->target_url)): ?>
                <strong>On page:</strong> <code><?php echo s($item->target_url); ?></code><br>
            <?php endif; ?>
            <?php if (!empty($item->gitlab_issue_url)): ?>
                <strong>GitLab issue:</strong> <a href="<?php echo s($item->gitlab_issue_url); ?>" target="_blank"><?php echo s($item->gitlab_issue_url); ?></a><br>
            <?php endif; ?>
            <?php if (!empty($item->avc_logged_at)): ?>
                <strong>AVC logged:</strong> <?php echo userdate($item->avc_logged_at); ?>
                <?php if ($item->avc_score_awarded > 0): ?>
                    · <strong style="color:#2E7D32;">Score: +<?php echo (int)$item->avc_score_awarded; ?></strong>
                <?php endif; ?>
                <br>
            <?php endif; ?>
            <?php if (!empty($item->reviewed_at)): ?>
                <strong>Reviewed by:</strong> user <?php echo (int)$item->reviewer_userid; ?>
                at <?php echo userdate($item->reviewed_at); ?>
                <?php if (!empty($item->reviewer_comment)): ?>
                    <br><em>"<?php echo s($item->reviewer_comment); ?>"</em>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($can_review): ?>
        <div style="background:#fff;border-radius:10px;padding:24px 28px;box-shadow:0 1px 3px rgba(0,0,0,.06);">
            <h3 style="margin-top:0;color:#2E7D32;">Mentor review</h3>
            <p style="color:#666;font-size:0.92em;">Approve → submitter is credited with the default score on AVC.
                Implemented → 1.5× bonus. Custom score: override below.</p>
            <form method="post" action="">
                <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                <input type="hidden" name="id" value="<?php echo (int)$item->id; ?>">

                <label style="display:block;margin:14px 0 6px;font-weight:500;"><?php echo get_string('action_review_comment', 'local_feedback'); ?></label>
                <textarea name="comment" rows="3" style="width:100%;padding:8px 12px;border:1px solid #e0e0e0;border-radius:4px;font-family:inherit;"><?php echo s($item->reviewer_comment ?? ''); ?></textarea>

                <label style="display:block;margin:14px 0 6px;font-weight:500;">Custom score (optional)</label>
                <input type="number" name="score" min="0" max="1000" placeholder="default = <?php echo (int)get_config('local_feedback', 'avc_score_default') ?: 10; ?>" style="padding:6px 10px;border:1px solid #e0e0e0;border-radius:4px;width:120px;">

                <div style="margin-top:20px;display:flex;gap:8px;flex-wrap:wrap;">
                    <button type="submit" name="action" value="approve" class="btn btn-success" style="background:#2E7D32;border-color:#1B5E20;"><?php echo get_string('action_approve', 'local_feedback'); ?></button>
                    <button type="submit" name="action" value="implement" class="btn btn-primary" style="background:#1565C0;border-color:#0D47A1;"><?php echo get_string('action_implement', 'local_feedback'); ?></button>
                    <button type="submit" name="action" value="reject" class="btn btn-danger"><?php echo get_string('action_reject', 'local_feedback'); ?></button>
                    <button type="submit" name="action" value="duplicate" class="btn btn-secondary"><?php echo get_string('action_dup', 'local_feedback'); ?></button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <p style="margin-top:20px;text-align:center;">
        <a href="<?php echo new moodle_url('/local/feedback/index.php'); ?>">← Back to feedback list</a>
    </p>
</div>
<?php
echo $OUTPUT->footer();
