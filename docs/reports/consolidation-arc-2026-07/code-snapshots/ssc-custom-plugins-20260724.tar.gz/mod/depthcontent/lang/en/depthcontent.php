<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for mod_depthcontent.
 *
 * @package    mod_depthcontent
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['modulename'] = 'Depth Content';
$string['modulenameplural'] = 'Depth Contents';
$string['modulename_help'] = 'The Depth Content module displays a learning point at the user\'s chosen depth level, with inline quiz items and practice actions.';
$string['pluginadministration'] = 'Depth Content administration';
$string['pluginname'] = 'Depth Content';

// Depth levels.
$string['depth_short'] = 'Short';
$string['depth_standard'] = 'Standard';
$string['depth_longer'] = 'Longer';
$string['depth_detailed'] = 'Detailed';
$string['depth_advanced'] = 'Advanced';
$string['depth_scholar'] = 'Scholar';
$string['depth_short_desc'] = 'Key points only (1-2 sentences)';
$string['depth_standard_desc'] = 'Recommended depth (~500 words)';
$string['depth_longer_desc'] = 'More explanation (~1500 words)';
$string['depth_detailed_desc'] = 'Comprehensive treatment (~3000 words)';
$string['depth_advanced_desc'] = 'Formation-level depth (~5000 words)';
$string['depth_scholar_desc'] = 'Primary sources and academic depth';

// UI elements.
$string['godeeper'] = 'Go deeper';
$string['showless'] = 'Show less';
$string['currentdepth'] = 'Current depth: {$a}';
$string['changedepth'] = 'Change depth';
$string['checkyourunderstanding'] = 'Check your understanding';
$string['todayspractice'] = 'Today\'s practice';
$string['habittip'] = 'Habit tip';
$string['correct'] = 'Correct!';
$string['incorrect'] = 'Not quite.';
$string['pointprogress'] = 'Point {$a->current} of {$a->total}';

// User preferences.
$string['preferences'] = 'Learning preferences';
$string['defaultdepth'] = 'Default content depth';
$string['defaultdepth_desc'] = 'Content depth applied to all new learning points.';
$string['videolength'] = 'Preferred video length';
$string['quizstyle'] = 'Quiz placement';
$string['quizstyle_inline'] = 'Inline (in reading flow)';
$string['quizstyle_end'] = 'End of section';
$string['quizcount'] = 'Questions per section';
$string['quizcount_all'] = 'All';

// Review mode.
$string['reviewmode'] = 'Review mode';
$string['reviewmode_desc'] = 'Test your existing knowledge — credit by examination.';
$string['selfassess'] = 'Tick the points you believe you already know:';
$string['testme'] = 'Test me';
$string['passed'] = 'Passed — mastered!';
$string['failed'] = 'Needs review';
$string['mastered'] = 'Mastered';

// Spaced repetition.
$string['reviewdue'] = 'Review due';
$string['nextreview'] = 'Next review: {$a}';
$string['reviewdeck'] = 'Daily review';
$string['noreviewsdue'] = 'No reviews due today. Great work!';
$string['reviewdashboard'] = 'Review Dashboard';
$string['reviewqueue'] = 'Due for review';
$string['startreview'] = 'Start review';
$string['duetoday'] = 'Due today';
$string['upcomingreview'] = 'Coming up this week';
$string['masteryprogress'] = 'Mastery progress';
$string['status_learning'] = 'Learning';
$string['status_review'] = 'In review';
$string['status_mastered'] = 'Mastered';

// Depth preference.
$string['remembermypref'] = 'Remember my preference';
$string['remembermypref_help'] = 'When checked, your depth choice will be applied to all learning points. When unchecked, the choice applies only to this point.';

// Events.
$string['eventcoursemoduleviewed'] = 'Depth content viewed';
$string['eventquizanswered'] = 'Inline quiz answered';
$string['eventdepthchanged'] = 'Depth level changed';

// Privacy.
$string['privacy:metadata:depthcontent_progress'] = 'Tracks user progress through learning points.';
$string['privacy:metadata:depthcontent_quiz_responses'] = 'Stores user responses to inline quiz items.';
$string['privacy:metadata:depthcontent_sr_state'] = 'Stores spaced repetition state for each learning point.';

// Examination mode (credit by examination).
$string['noexaminablepoints'] = 'No examinable learning points found in this course. Points need quiz items to be testable.';
$string['examquestions'] = '{$a} questions';
$string['examresults'] = 'Examination results';
$string['pointsmastered'] = 'Points mastered';
$string['studythispoint'] = 'Study this point';
$string['unansweredwarning'] = 'You have {$a} unanswered question(s). Unanswered questions will be marked incorrect. Continue?';
$string['correctanswer'] = 'Correct answer: {$a}';
$string['needsreview'] = 'Needs review';
$string['scorepercent'] = '{$a}%';

// Notifications.
$string['task_sendreviewreminders'] = 'Send daily review reminders';
$string['messageprovider:reviewreminder'] = 'Daily review reminder';
$string['remindersubject'] = 'You have {$a} learning points due for review';
$string['reminderbody'] = 'You have {$a->count} learning points due for review today (estimated {$a->minutes} minutes). Visit your dashboard to start your daily review.';
$string['reminderbodyhtml'] = '<p>You have <strong>{$a->count}</strong> learning points due for review today (estimated {$a->minutes} minutes).</p><p>Visit your dashboard to start your daily review.</p>';
$string['remindersmall'] = '{$a} points due for review';

$string['depthcontent:view'] = 'View depth content';
$string['depthcontent:addinstance'] = 'Add a new depth content activity';
$string['depthcontent:submitfeedback'] = 'Submit feedback on content slots (S13)';

// S13: Feedback.
$string['feedback:help_improve'] = 'Help improve this';
$string['feedback:level_a_title'] = 'Which video is the best fit?';
$string['feedback:level_b_title'] = 'How well does this video teach the point?';
$string['feedback:pick_one'] = 'Pick the one you think fits best';
$string['feedback:why_optional'] = 'Why? (optional)';
$string['feedback:submit'] = 'Submit';
$string['feedback:thanks'] = 'Thanks — feedback recorded.';
$string['feedback:locked'] = 'This slot is locked by community feedback.';
$string['feedback:report_problem'] = 'Report a problem';
$string['feedback:play'] = 'Play';
$string['feedback:thumbs_up'] = 'Thumbs up';
$string['feedback:thumbs_down'] = 'Thumbs down';
$string['feedback:teaches_yes'] = 'Yes, it teaches the point';
$string['feedback:teaches_partially'] = 'Partially';
$string['feedback:teaches_no'] = 'No, it does not';
$string['feedback:teaches_question'] = 'Does this video teach the point?';

// S13 Phase 3: Level C/D full annotation.
$string['feedback_level_c_tab'] = 'Annotate (C)';
$string['feedback_level_d_tab'] = 'Re-trim (D)';
$string['feedback_level_c_intro'] = 'Score how well this clip fits this slot and flag any authority issues.';
$string['feedback_level_c_slot_fit'] = 'Per-slot fit (0–10)';
$string['feedback_level_c_authority_ok'] = 'Authority citation is accurate';
$string['feedback_level_c_cross_ref'] = 'Cross-reference suggestion';
$string['feedback_level_c_notes'] = 'Notes';
$string['feedback_level_c_submit'] = 'Submit annotation';
$string['feedback_level_d_intro'] = 'Propose a different start/end. Records as a guild suggestion.';
$string['feedback_level_d_trim'] = 'Proposed clip range';
$string['feedback_level_d_start'] = 'Start (s)';
$string['feedback_level_d_end'] = 'End (s)';
$string['feedback_level_d_trim_hint'] = 'Reviewers see your proposed range alongside the rubric candidates.';
$string['feedback_level_d_rationale'] = 'Rationale (required)';
$string['feedback_level_d_submit'] = 'Submit re-trim proposal';

// Privacy (S13).
$string['privacy:metadata:depthcontent_fb_events'] = 'Records user feedback submissions on content slots (level, slot id, timestamp).';
