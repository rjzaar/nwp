<?php
defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook'     => \core\hook\output\before_standard_head_html_generation::class,
        'callback' => \local_feedback\hook_callbacks::class . '::before_head',
    ],
    [
        'hook'     => \core\hook\output\before_footer_html_generation::class,
        'callback' => \local_feedback\hook_callbacks::class . '::before_footer',
    ],
];
