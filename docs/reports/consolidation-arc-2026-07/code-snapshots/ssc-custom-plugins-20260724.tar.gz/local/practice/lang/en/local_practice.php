<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for local_practice.
 *
 * @package    local_practice
 * @copyright  2026 NWP (https://nwpcode.org)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Application';
$string['practice:use'] = 'Use your own Plan of Love';

// Member-facing Plan-of-Love surface.
$string['planoflove'] = 'Plan of Love';
$string['ruleoflife'] = 'Rule of Life';
$string['myplan'] = 'My Plan of Love';
$string['plantitle'] = 'Plan title';
$string['noitems'] = 'Your plan is empty. Checkpoints appear here as you walk your courses.';
$string['tick'] = 'Mark done today';
$string['untick'] = 'Clear today';
$string['streak'] = 'Days engaged';
$string['lastengaged'] = 'Last engaged';
$string['retired'] = 'Retired';
$string['type_task'] = 'Task';
$string['type_skill'] = 'Skill';
$string['type_habit'] = 'Habit';
$string['status_todo'] = 'Not started';
$string['status_started'] = 'Started';
$string['status_consolidated'] = 'Consolidated';
$string['status_done'] = 'Done';
$string['status_active'] = 'Living it';
$string['status_paused'] = 'Paused';
$string['history'] = 'Engagement history';

// Progression-visibility display (3-mode member preference — DISPLAY only; data is always recorded).
$string['progressionview'] = 'Progression view';
$string['progressionview_help'] = 'Choose how much of your own growth you see. All your progress is always kept either way — this only changes what is shown. Encourage me shows your states, milestones, growth and lifetime count; Gentle (recommended) shows milestones and your current state; Keep it quiet hides the progression view so you simply do the next thing.';
$string['pview_full'] = 'Encourage me';
$string['pview_gentle'] = 'Gentle (recommended)';
$string['pview_quiet'] = 'Keep it quiet';
$string['pstate_none'] = 'Not yet begun';
$string['pstate_forming'] = 'Forming';
$string['pstate_held'] = 'Held';
$string['pstate_formed'] = 'Formed';
$string['renewaldue'] = 'Due for renewal';
$string['milestone_begun'] = 'Begun';
$string['milestone_consolidated'] = 'Becoming part of you — kept for a season';
$string['milestone_completed'] = 'Completed';
$string['milestone_formed'] = 'Formed into character';
$string['lifetimecount'] = 'Days kept, all-time';
$string['grace_framing'] = 'Growth in fidelity — by grace. Practice disposes; God gives.';
$string['nudge_never_miss_twice'] = 'A blank day is just a blank — not a broken streak. Come back today; the practice is glad to have you.';

// Anchor plan (implementation intention) + self-connection.
$string['anchorplan'] = 'My anchor';
$string['anchorplan_prompt'] = 'After I… I will… (an anchor helps a practice stick)';
$string['promptself'] = 'How does this connect to your life right now?';

// Privacy (GDPR) metadata strings.
$string['privacy:metadata:local_practice_state'] = 'Per-member state for each practice checkpoint (religious-practice special-category data). Never shared and never exposed to any AI system.';
$string['privacy:metadata:local_practice_state:userid'] = 'The member the state belongs to.';
$string['privacy:metadata:local_practice_state:checkpoint_uid'] = 'The canonical checkpoint identifier.';
$string['privacy:metadata:local_practice_state:status'] = 'The lifecycle status of the checkpoint for this member.';
$string['privacy:metadata:local_practice_state:streak'] = 'The engagement streak/counter.';
$string['privacy:metadata:local_practice_state:last_engaged_at'] = 'When the member last engaged the checkpoint.';
$string['privacy:metadata:local_practice_log'] = 'Append-only log of engagement events (the engaged() signal).';
$string['privacy:metadata:local_practice_log:userid'] = 'The member who engaged.';
$string['privacy:metadata:local_practice_log:checkpoint_uid'] = 'The canonical checkpoint identifier.';
$string['privacy:metadata:local_practice_log:ts'] = 'When the event occurred.';
$string['privacy:metadata:local_practice_log:source'] = 'How the engagement was recorded (manual tick, or a permitted auto source).';
$string['privacy:metadata:local_practice_reflection'] = 'Optional private reflection text. Categorically private; never shared and never AI-exposed.';
$string['privacy:metadata:local_practice_reflection:userid'] = 'The member who wrote the reflection.';
$string['privacy:metadata:local_practice_reflection:checkpoint_uid'] = 'The canonical checkpoint identifier.';
$string['privacy:metadata:local_practice_reflection:body'] = 'The private reflection text.';
$string['privacy:metadata:local_practice_reflection:ts'] = 'When the reflection was written.';
